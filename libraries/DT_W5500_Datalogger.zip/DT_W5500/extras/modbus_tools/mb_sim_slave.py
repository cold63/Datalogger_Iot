#!/usr/bin/env python3
"""
mb_sim_slave.py - 在 PC 上模擬 Modbus TCP Slave，用來測試板子的 Client

用法:
    python tools/mb_sim_slave.py [--port 502] [--unit 1]
    故障注入:
      --delay 2000     每次延遲 2000 ms 才回應 (測逾時)
      --exception 2    一律回例外碼 2 (測例外處理)
      --bad-tid        回應時 TID 加 1 (測 TID 檢查)
      --drop           收到請求就斷線 (測重連)

初始資料: HR0..9 = 100..109, IR0..9 = 200..209
每次讀取範圍包含 HR9 時 HR9 加 1，方便從板子 Serial 看出資料有在更新。
Windows 防火牆需允許 Python 監聽此 port。
"""
import argparse
import socket
import struct
import threading
import time

SIZE = 100
hr = [0] * SIZE
ir = [0] * SIZE
coils = [0] * SIZE
di = [0] * SIZE
lock = threading.Lock()
for i in range(10):
    hr[i] = 100 + i
    ir[i] = 200 + i
    di[i] = i % 2


def exception(fc, code):
    return bytes([fc | 0x80, code])


def pack_bits(bits):
    data = bytearray((len(bits) + 7) // 8)
    for i, b in enumerate(bits):
        if b:
            data[i // 8] |= 1 << (i % 8)
    return bytes([len(data)]) + bytes(data)


LIMITS = {1: 2000, 2: 2000, 3: 125, 4: 125, 15: 1968, 16: 123}


def process(pdu):
    fc = pdu[0]
    if fc not in (1, 2, 3, 4, 5, 6, 15, 16):
        return exception(fc & 0x7F, 1)
    if len(pdu) < 5:
        return exception(fc, 3)
    addr, qty = struct.unpack(">HH", pdu[1:5])   # FC05/06 時 qty 為寫入值
    if fc in LIMITS:
        if not 1 <= qty <= LIMITS[fc]:
            return exception(fc, 3)
        if fc == 15 and (len(pdu) < 6 or pdu[5] != (qty + 7) // 8 or len(pdu) != 6 + pdu[5]):
            return exception(fc, 3)
        if fc == 16 and (len(pdu) < 6 or pdu[5] != qty * 2 or len(pdu) != 6 + pdu[5]):
            return exception(fc, 3)
        if addr + qty > SIZE:
            return exception(fc, 2)
    else:
        if fc == 5 and qty not in (0xFF00, 0):
            return exception(fc, 3)
        if addr >= SIZE:
            return exception(fc, 2)

    with lock:
        if fc == 1:
            return bytes([fc]) + pack_bits(coils[addr:addr + qty])
        if fc == 2:
            return bytes([fc]) + pack_bits(di[addr:addr + qty])
        if fc in (3, 4):
            table = hr if fc == 3 else ir
            resp = bytes([fc, qty * 2]) + struct.pack(">%dH" % qty, *table[addr:addr + qty])
            if fc == 3 and addr <= 9 < addr + qty:
                hr[9] = (hr[9] + 1) & 0xFFFF
            return resp
        if fc == 5:
            coils[addr] = 1 if qty == 0xFF00 else 0
        elif fc == 6:
            hr[addr] = qty
        elif fc == 15:
            for i in range(qty):
                coils[addr + i] = (pdu[6 + i // 8] >> (i % 8)) & 1
        else:
            hr[addr:addr + qty] = struct.unpack(">%dH" % qty, pdu[6:6 + qty * 2])
        return pdu[:5]


def recv_exact(conn, n):
    buf = b""
    while len(buf) < n:
        chunk = conn.recv(n - len(buf))
        if not chunk:
            raise ConnectionError
        buf += chunk
    return buf


def handle(conn, addr, args):
    print("[SIM] connected", addr)
    try:
        while True:
            tid, pid, length, unit = struct.unpack(">HHHB", recv_exact(conn, 7))
            if pid != 0 or not 2 <= length <= 254:
                print("[SIM] bad MBAP, closing")
                break
            pdu = recv_exact(conn, length - 1)
            print("[SIM] req tid=%d unit=%d pdu=%s" % (tid, unit, pdu.hex(" ")))
            if args.drop:
                print("[SIM] --drop: closing")
                break
            if unit not in (args.unit, 0, 0xFF):
                continue
            resp = exception(pdu[0], args.exception) if args.exception else process(pdu)
            if args.delay:
                time.sleep(args.delay / 1000.0)
            if args.bad_tid:
                tid = (tid + 1) & 0xFFFF
            conn.sendall(struct.pack(">HHHB", tid, 0, len(resp) + 1, unit) + resp)
            print("[SIM] rsp tid=%d pdu=%s" % (tid, resp.hex(" ")))
    except (ConnectionError, OSError):
        pass
    finally:
        conn.close()
        print("[SIM] disconnected", addr)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=502)
    ap.add_argument("--unit", type=int, default=1)
    ap.add_argument("--delay", type=int, default=0, help="reply delay in ms")
    ap.add_argument("--exception", type=int, default=0, help="always reply with this exception code")
    ap.add_argument("--bad-tid", action="store_true", help="reply with wrong transaction id")
    ap.add_argument("--drop", action="store_true", help="close connection on request")
    args = ap.parse_args()

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", args.port))
    srv.listen(4)
    srv.settimeout(1.0)  # 讓 Ctrl+C 在 Windows 上能中斷
    print("[SIM] Modbus TCP slave listening on port %d (unit %d)" % (args.port, args.unit))
    try:
        while True:
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            threading.Thread(target=handle, args=(conn, addr, args), daemon=True).start()
    except KeyboardInterrupt:
        print("\n[SIM] stopped")
    finally:
        srv.close()


if __name__ == "__main__":
    main()
