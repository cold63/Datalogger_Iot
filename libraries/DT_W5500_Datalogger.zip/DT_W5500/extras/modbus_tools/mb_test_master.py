#!/usr/bin/env python3
"""
mb_test_master.py - 以 PC 當 Modbus TCP Master，自動測試板子上的 Server

用法:
    python tools/mb_test_master.py 192.168.1.117 [--port 502] [--unit 1] [--quick]
    --quick  略過通訊中斷保護測試 (該項需等待約 12 秒)
    小工具:
    python tools/mb_test_master.py 192.168.1.117 --write-hr 20 777
    python tools/mb_test_master.py 192.168.1.117 --read-hr 20

只用 Python 標準函式庫，不需安裝 pymodbus。
注意：測試會改寫板子的 HR0..21、HR40、Coil0..24 (HR20 會被存入 Flash)。
"""
import argparse
import random
import socket
import struct
import sys
import time

TIMEOUT = 3.0


class Master:
    def __init__(self, host, port, unit):
        self.unit = unit
        self.tid = 0
        self.sock = socket.create_connection((host, port), timeout=TIMEOUT)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    def close(self):
        self.sock.close()

    def frame(self, pdu, unit=None, tid=None):
        if tid is None:
            self.tid = (self.tid + 1) & 0xFFFF
            tid = self.tid
        return struct.pack(">HHHB", tid, 0, len(pdu) + 1, self.unit if unit is None else unit) + pdu

    def recv_exact(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("connection closed")
            buf += chunk
        return buf

    def recv_adu(self):
        """回傳 (tid, unit, pdu)"""
        hdr = self.recv_exact(7)
        tid, pid, length, unit = struct.unpack(">HHHB", hdr)
        if pid != 0:
            raise ValueError("bad PID %d" % pid)
        return tid, unit, self.recv_exact(length - 1)

    def request(self, pdu, unit=None):
        adu = self.frame(pdu, unit)
        self.sock.sendall(adu)
        tid, _, resp = self.recv_adu()
        if tid != self.tid:
            raise ValueError("TID mismatch %d != %d" % (tid, self.tid))
        return resp

    # ---- 功能碼包裝 ----
    def read_bits(self, fc, addr, qty):
        resp = self.request(struct.pack(">BHH", fc, addr, qty))
        if resp[0] & 0x80:
            return resp
        return [(resp[2 + i // 8] >> (i % 8)) & 1 for i in range(qty)]

    def read_regs(self, fc, addr, qty):
        resp = self.request(struct.pack(">BHH", fc, addr, qty))
        if resp[0] & 0x80:
            return resp
        return list(struct.unpack(">%dH" % qty, resp[2:2 + qty * 2]))

    def write_coil(self, addr, on):
        return self.request(struct.pack(">BHH", 5, addr, 0xFF00 if on else 0))

    def write_reg(self, addr, val):
        return self.request(struct.pack(">BHH", 6, addr, val))

    def write_coils(self, addr, bits):
        data = bytearray((len(bits) + 7) // 8)
        for i, b in enumerate(bits):
            if b:
                data[i // 8] |= 1 << (i % 8)
        return self.request(struct.pack(">BHHB", 15, addr, len(bits), len(data)) + bytes(data))

    def write_regs(self, addr, vals):
        return self.request(struct.pack(">BHHB", 16, addr, len(vals), len(vals) * 2) +
                            struct.pack(">%dH" % len(vals), *vals))


results = []


def check(name, ok, detail=""):
    results.append(ok)
    print("[%s] %-36s %s" % ("PASS" if ok else "FAIL", name, detail))


def run(name, fn):
    try:
        fn()
    except Exception as e:  # 測試中任何例外都算失敗，繼續下一項
        check(name, False, "%s: %s" % (type(e).__name__, e))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("host")
    ap.add_argument("--port", type=int, default=502)
    ap.add_argument("--unit", type=int, default=1)
    ap.add_argument("--quick", action="store_true", help="skip the fail-safe test (needs ~12 s)")
    ap.add_argument("--failsafe-wait", type=int, default=12, help="seconds to wait (> MB_FAILSAFE_MS)")
    ap.add_argument("--write-hr", nargs=2, type=int, metavar=("ADDR", "VALUE"), help="write one HR and exit")
    ap.add_argument("--read-hr", type=int, metavar="ADDR", help="read one HR and exit")
    args = ap.parse_args()

    def connect():
        return Master(args.host, args.port, args.unit)

    # 小工具模式 (例如測試斷電保存：寫入 → 等 3 秒 → 重開板子 → 讀回)
    if args.write_hr or args.read_hr is not None:
        m = connect()
        if args.write_hr:
            r = m.write_reg(args.write_hr[0], args.write_hr[1])
            print("HR%d <- %d : %s" % (args.write_hr[0], args.write_hr[1], "OK" if r[0] == 6 else "exception %d" % r[1]))
        if args.read_hr is not None:
            print("HR%d = %d" % (args.read_hr, m.read_regs(3, args.read_hr, 1)[0]))
        m.close()
        return

    def pause():
        time.sleep(0.3)  # 讓板子回收 socket 並重新 listen

    # ---- 1. 讀寫功能碼 ----
    def t_registers():
        m = connect()
        r = m.write_reg(0, 0x1234)
        check("FC06 write HR0", r == struct.pack(">BHH", 6, 0, 0x1234))
        check("FC03 read back HR0", m.read_regs(3, 0, 1) == [0x1234])
        vals = [random.randint(0, 0xFFFF) for _ in range(5)]
        r = m.write_regs(10, vals)
        check("FC16 write HR10..14", r == struct.pack(">BHH", 16, 10, 5))
        check("FC03 read back HR10..14", m.read_regs(3, 10, 5) == vals, str(vals))
        m.close()
    run("registers", t_registers)
    pause()

    def t_coils():
        m = connect()
        m.write_coils(0, [0] * 8)
        r = m.write_coil(3, True)
        check("FC05 coil3 ON", r == struct.pack(">BHH", 5, 3, 0xFF00))
        check("FC01 read coil0..7", m.read_bits(1, 0, 8) == [0, 0, 0, 1, 0, 0, 0, 0])
        bits = [random.randint(0, 1) for _ in range(9)]
        r = m.write_coils(16, bits)
        check("FC15 write coil16..24", r == struct.pack(">BHH", 15, 16, 9))
        check("FC01 read back coil16..24", m.read_bits(1, 16, 9) == bits, str(bits))
        m.close()
    run("coils", t_coils)
    pause()

    def t_inputs():
        m = connect()
        check("FC02 DI0 (network ready)", m.read_bits(2, 0, 1) == [1])
        ir0 = m.read_regs(4, 0, 3)
        time.sleep(2.2)
        ir1 = m.read_regs(4, 0, 3)
        check("FC04 IR0 uptime increasing", ir1[0] > ir0[0], "%d -> %d" % (ir0[0], ir1[0]))
        check("FC04 IR2 sensor 250..269", 250 <= ir1[2] <= 269, str(ir1[2]))
        print("       IR10..19 (copied by client):", m.read_regs(4, 10, 10))
        m.close()
    run("inputs", t_inputs)
    pause()

    # ---- 2. 例外碼 ----
    def t_exceptions():
        m = connect()
        check("EX01 FC 0x07", m.request(b"\x07") == b"\x87\x01")
        check("EX02 FC03 addr 99 qty 2", m.request(struct.pack(">BHH", 3, 99, 2)) == b"\x83\x02")
        check("EX03 FC03 qty 0", m.request(struct.pack(">BHH", 3, 0, 0)) == b"\x83\x03")
        check("EX03 FC05 value 0x1234", m.request(struct.pack(">BHH", 5, 0, 0x1234)) == b"\x85\x03")
        check("EX03 FC16 byte count", m.request(struct.pack(">BHHBH", 16, 0, 2, 2, 1)) == b"\x90\x03")
        check("conn alive after exceptions", m.read_regs(3, 0, 1) == [0x1234])
        m.close()
    run("exceptions", t_exceptions)
    pause()

    # ---- 3. 分段 / 合併封包 ----
    def t_segmented():
        m = connect()
        adu = m.frame(struct.pack(">BHH", 3, 0, 1))
        for b in adu:
            m.sock.sendall(bytes([b]))
            time.sleep(0.02)
        tid, _, resp = m.recv_adu()
        check("segmented (1 byte per send)", tid == m.tid and resp == b"\x03\x02\x12\x34")
        m.close()
    run("segmented", t_segmented)
    pause()

    def t_pipelined():
        m = connect()
        a1 = m.frame(struct.pack(">BHH", 3, 0, 1))
        t1 = m.tid
        a2 = m.frame(struct.pack(">BHH", 4, 0, 1))
        t2 = m.tid
        m.sock.sendall(a1 + a2)
        r1 = m.recv_adu()
        r2 = m.recv_adu()
        check("pipelined 2 requests in 1 packet", r1[0] == t1 and r1[2][0] == 3 and r2[0] == t2 and r2[2][0] == 4)
        m.close()
    run("pipelined", t_pipelined)
    pause()

    # ---- 4. Unit ID ----
    def t_unit():
        m = connect()
        check("unit 0xFF accepted", m.request(struct.pack(">BHH", 3, 0, 1), unit=0xFF)[0] == 3)
        m.sock.sendall(m.frame(struct.pack(">BHH", 3, 0, 1), unit=0x55))
        m.sock.settimeout(1.5)
        try:
            m.recv_adu()
            check("unit 0x55 ignored (no reply)", False, "got a reply")
        except socket.timeout:
            check("unit 0x55 ignored (no reply)", True)
        m.close()
    run("unit id", t_unit)
    pause()

    # ---- 5. 同時連線數：滿線時新連線可進來，閒置最久的被踢掉 ----
    def t_concurrent():
        a, b = connect(), connect()
        ok_a = a.read_regs(3, 0, 1) == [0x1234]
        time.sleep(0.5)
        ok_b = b.read_regs(3, 0, 1) == [0x1234]          # b 比 a 新
        check("2 concurrent connections", ok_a and ok_b)
        time.sleep(0.5)
        c = connect()
        check("3rd connection served", c.read_regs(3, 0, 1) == [0x1234])
        time.sleep(0.3)
        a.sock.settimeout(1.5)
        try:
            a.read_regs(3, 0, 1)
            check("idlest (1st) connection evicted", False, "1st still served")
        except (socket.timeout, ConnectionError, OSError, ValueError):
            check("idlest (1st) connection evicted", True)
        check("2nd connection still served", b.read_regs(3, 0, 1) == [0x1234])
        for m in (a, b, c):
            m.close()
    run("concurrent", t_concurrent)
    pause()

    # ---- 寫入前檢查：HR20 只接受 0..1000 ----
    def t_validate():
        m = connect()
        check("VAL HR20=500 accepted", m.write_reg(20, 500) == struct.pack(">BHH", 6, 20, 500))
        check("VAL HR20=2000 -> EX03", m.request(struct.pack(">BHH", 6, 20, 2000)) == b"\x86\x03")
        check("VAL HR20 still 500", m.read_regs(3, 20, 1) == [500])
        m.write_reg(19, 0)
        check("VAL FC16 one bad -> EX03", m.request(struct.pack(">BHHB3H", 16, 19, 3, 6, 7, 2000, 9)) == b"\x90\x03")
        check("VAL FC16 none written", m.read_regs(3, 19, 3) == [0, 500, m.read_regs(3, 21, 1)[0]])
        m.close()
    run("validate", t_validate)
    pause()

    # ---- 診斷暫存器 IR90..99 ----
    def t_diag():
        m = connect()
        time.sleep(1.2)                                   # 等板子更新一次 (每秒)
        d = m.read_regs(4, 90, 10)
        check("DIAG IR90 clients >= 1", d[0] >= 1, str(d))
        check("DIAG IR91 requests > 0", d[1] > 0)
        check("DIAG IR92 exceptions > 0", d[2] > 0)
        print("       client ok=%d err=%d last=%d connected=%d comm_lost=%d" % (d[5], d[6], d[7], d[8], d[9]))
        m.close()
    run("diag", t_diag)
    pause()

    # ---- Server 回應延遲 (Client 非阻塞：Slave 斷線/逾時也不應拖慢 Server) ----
    def t_latency():
        m = connect()
        worst = 0.0
        end = time.time() + 6.0                           # 涵蓋至少 2 次 Client 輪詢
        while time.time() < end:
            t0 = time.time()
            m.read_regs(3, 0, 1)
            worst = max(worst, time.time() - t0)
            time.sleep(0.05)
        check("server latency < 300 ms (6 s)", worst < 0.3, "worst %.0f ms" % (worst * 1000))
        m.close()
    run("latency", t_latency)
    pause()

    # ---- FC22 / FC23 / FC43 ----
    def t_new_fc():
        m = connect()
        m.write_reg(15, 0x0012)
        r = m.request(struct.pack(">BHHH", 22, 15, 0x00F2, 0x0025))
        check("FC22 mask write echo", r == struct.pack(">BHHH", 22, 15, 0x00F2, 0x0025))
        check("FC22 HR15 = 0x17", m.read_regs(3, 15, 1) == [0x17])
        r = m.request(struct.pack(">BHHHHB2H", 23, 15, 3, 16, 2, 4, 0xAAAA, 0x5555))
        check("FC23 write 16..17 read 15..17", r == struct.pack(">BB3H", 23, 6, 0x17, 0xAAAA, 0x5555), r.hex(" "))
        r = m.request(struct.pack(">BHHHHBH", 23, 20, 1, 20, 1, 2, 2000))
        check("FC23 validate HR20=2000 -> EX03", r == b"\x97\x03")
        r = m.request(bytes([0x2B, 0x0E, 0x01, 0x00]))
        objs, pos = {}, 7
        for _ in range(r[6] if len(r) > 6 else 0):
            oid, n = r[pos], r[pos + 1]
            objs[oid] = r[pos + 2:pos + 2 + n].decode(errors="replace")
            pos += 2 + n
        check("FC43 basic device id", r[:3] == b"\x2b\x0e\x01" and sorted(objs) == [0, 1, 2], str(objs))
        check("EX01 FC43 MEI 0x0D", m.request(bytes([0x2B, 0x0D, 0x01, 0x00])) == b"\xab\x01")
        m.close()
    run("new fc", t_new_fc)
    pause()

    # ---- float (IR3..4 = IR2 / 10，ABCD) ----
    def t_float():
        m = connect()
        ir = m.read_regs(4, 2, 3)                         # 一次讀取，避免兩次讀之間值改變
        f = struct.unpack(">f", struct.pack(">HH", ir[1], ir[2]))[0]
        check("FLOAT IR3..4 == IR2/10", abs(f - ir[0] / 10.0) < 0.01, "IR2=%d float=%.2f" % (ir[0], f))
        m.close()
    run("float", t_float)
    pause()

    # ---- 閘道轉寫：HR40 → 遠端 HR5 → 輪詢回本機 IR15 (需執行 mb_sim_slave.py) ----
    def t_forward():
        m = connect()
        if m.read_bits(2, 1, 1) != [1]:
            print("[SKIP] gateway forward (poll task 0 offline: mb_sim_slave.py running?)")
            m.close()
            return
        val = random.randint(1000, 9999)
        m.write_reg(40, val)
        deadline = time.time() + 6.0
        got = None
        while time.time() < deadline:
            got = m.read_regs(4, 15, 1)[0]
            if got == val:
                break
            time.sleep(0.5)
        check("GATEWAY HR40 -> remote HR5 -> IR15", got == val, "wrote %d, IR15=%s" % (val, got))
        on = m.read_bits(2, 1, 3)
        check("POLL DI1..3 all tasks online", on == [1, 1, 1], str(on))
        m.close()
    run("forward", t_forward)
    pause()

    # ---- 通訊中斷保護 (需等待 MB_FAILSAFE_MS) ----
    def t_failsafe():
        m = connect()
        m.write_coil(0, True)
        check("FAILSAFE coil0 ON before", m.read_bits(1, 0, 1) == [1])
        m.close()
        print("       waiting %d s without requests ..." % args.failsafe_wait)
        time.sleep(args.failsafe_wait)
        m = connect()
        check("FAILSAFE coil0 OFF after timeout", m.read_bits(1, 0, 1) == [0])
        m.close()
    if not args.quick:
        run("failsafe", t_failsafe)
        pause()

    # ---- 6. 不合法 MBAP ----
    def t_bad_mbap():
        m = connect()
        m.sock.sendall(struct.pack(">HHHB", 1, 1, 6, 1) + struct.pack(">BHH", 3, 0, 1))  # PID = 1
        m.sock.settimeout(2.0)
        try:
            data = m.sock.recv(64)
            check("bad PID -> connection closed", data == b"", "got %r" % data)
        except ConnectionError:
            check("bad PID -> connection closed", True, "reset")
        except socket.timeout:
            check("bad PID -> connection closed", False, "still open")
        m.close()
    run("bad mbap", t_bad_mbap)
    pause()

    def t_recovered():
        m = connect()
        check("server accepts new connection", m.read_regs(3, 0, 1) == [0x1234])
        m.close()
    run("recovered", t_recovered)

    passed = sum(results)
    print("\n===== %d/%d passed =====" % (passed, len(results)))
    sys.exit(0 if passed == len(results) else 1)


if __name__ == "__main__":
    main()
