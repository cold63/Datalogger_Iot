/**
 * @file DT_Mqtt.ino
 * @brief MQTT 發布 / 訂閱範例 (DHCP + DNS + 自動重連)。
 *
 * 用 MQTT 工具發布 "LED_ON" / "LED_OFF" 到 w5500/test/control 測試接收。
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

const char* PUB_TOPIC = "w5500/test/status";
const char* SUB_TOPIC = "w5500/test/control";

void onMessage(const char* topic, const uint8_t* payload, uint16_t len) {
    Serial.print("[MQTT] ");
    Serial.print(topic);
    Serial.print(": ");
    Serial.write(payload, len);
    Serial.println();

    if (len == 6 && memcmp(payload, "LED_ON", 6) == 0) Serial.println("[APP] LED ON");
    if (len == 7 && memcmp(payload, "LED_OFF", 7) == 0) Serial.println("[APP] LED OFF");
}

void onMqttState(DT_MqttState_t st) {
    Serial.print("[MQTT] state: ");
    Serial.print(DT_Mqtt_StateName(st));
    if (st == DT_MQTT_RETRY_WAIT) {
        Serial.print(" (");
        Serial.print(DT_ErrName(DT_Mqtt_LastError()));
        Serial.print(")");
    }
    Serial.println();
}

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 MQTT Example ---");

    DT_W5500_Begin(NULL);
    DT_Net_BeginDhcp(mac);

    DT_MqttConfig_t cfg;
    DT_Mqtt_ConfigDefault(&cfg);
    cfg.host = "broker.hivemq.com";
    cfg.port = 1883;
    cfg.client_id = "RTL8720D_W5500_Client";
    DT_Mqtt_Begin(&cfg);

    DT_Mqtt_SetCallback(onMessage);
    DT_Mqtt_SetStateCallback(onMqttState);
    DT_Mqtt_Subscribe(SUB_TOPIC, 0);   // 重連後自動重新訂閱
}

void loop() {
    DT_Net_Loop();
    DT_Mqtt_Loop();

    static uint32_t last = 0;
    if (DT_Mqtt_IsConnected() && millis() - last >= 10000) {
        last = millis();
        char payload[48];
        snprintf(payload, sizeof(payload), "{\"uptime\": %lu}", millis() / 1000);
        Serial.print("[MQTT] Pub: ");
        Serial.println(payload);
        DT_Mqtt_PublishStr(PUB_TOPIC, payload);
    }
}
