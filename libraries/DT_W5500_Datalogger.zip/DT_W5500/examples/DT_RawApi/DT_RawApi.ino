/**
 * @file DT_RawApi.ino
 * @brief 進階：DT_ 初始化 + 原生 ioLibrary socket API 混用範例。
 *
 * 以原生 API 實作 TCP Echo Server (Port 5001)。
 * socket 編號務必透過 DT_Socket_Alloc() 取得，避免與 DT_ 模組衝突。
 */

#include <DT_W5500_Raw.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

const uint16_t PORT = 5001;
int sn = -1;
uint8_t buf[512];

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 Raw API ---");

    DT_W5500_Begin(NULL);
    DT_Net_BeginDhcp(mac);
    DT_Net_WaitReady(30000);
    DT_PrintNetInfo();

    sn = DT_Socket_Alloc();
    Serial.print("Using socket ");
    Serial.println(sn);
}

void loop() {
    DT_Net_Loop();
    if (sn < 0 || !DT_Net_IsReady()) return;

    switch (getSn_SR(sn)) {
    case SOCK_CLOSED:
        socket(sn, Sn_MR_TCP, PORT, 0);
        break;
    case SOCK_INIT:
        listen(sn);
        break;
    case SOCK_ESTABLISHED: {
        uint16_t size = getSn_RX_RSR(sn);
        if (size > 0) {
            if (size > sizeof(buf)) size = sizeof(buf);
            int32_t len = recv(sn, buf, size);
            if (len > 0) send(sn, buf, len);
        }
        break;
    }
    case SOCK_CLOSE_WAIT:
        disconnect(sn);
        break;
    default:
        break;
    }
}
