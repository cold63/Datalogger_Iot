/**
 * @file DT_HttpClient.ino
 * @brief HTTP GET / POST 範例，每 60 秒執行一次。
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

char body[1024];

void doGet() {
    DT_HttpResp_t resp;
    int r = DT_Http_Get("http://httpbin.org/get", body, sizeof(body), &resp);
    Serial.print("[GET] result: ");
    Serial.println(r > 0 ? r : 0);
    if (r < 0) { Serial.println(DT_ErrName(r)); return; }
    Serial.print("[GET] body ");
    Serial.print(resp.body_len);
    Serial.println(resp.truncated ? " bytes (truncated):" : " bytes:");
    Serial.println(body);
}

void doPost() {
    char json[64];
    snprintf(json, sizeof(json), "{\"uptime\":%lu}", millis() / 1000);
    DT_HttpResp_t resp;
    int r = DT_Http_Post("http://httpbin.org/post", "application/json",
                         (const uint8_t*)json, strlen(json), body, sizeof(body), &resp);
    Serial.print("[POST] status: ");
    Serial.println(r > 0 ? r : 0);
    if (r < 0) Serial.println(DT_ErrName(r));
    else Serial.println(body);
}

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 HTTP Client ---");

    DT_W5500_Begin(NULL);
    DT_Net_BeginDhcp(mac);
}

void loop() {
    DT_Net_Loop();
    if (!DT_Net_IsReady()) return;

    static uint32_t last = 0;
    static bool first = true;
    if (first || millis() - last >= 60000) {
        first = false;
        last = millis();
        doGet();
        doPost();
    }
}
