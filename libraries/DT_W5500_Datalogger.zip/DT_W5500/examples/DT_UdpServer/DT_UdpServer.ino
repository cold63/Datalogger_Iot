/**
 * @file DT_UdpServer.ino
 * @brief UDP Echo Server：監聽 Port 6000，回傳收到的資料。
 *
 * 搭配專案中的 udp_client.py (送往 6000)。
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xEE};
uint8_t ip[4]  = {192, 168, 1, 178};
uint8_t sn[4]  = {255, 255, 255, 0};
uint8_t gw[4]  = {192, 168, 1, 1};

const uint16_t LOCAL_PORT = 6000;
int udp = -1;

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 UDP Echo Server ---");

    DT_W5500_Begin(NULL);
    DT_Net_BeginStatic(mac, ip, sn, gw, NULL);
}

void loop() {
    DT_Net_Loop();
    if (!DT_Net_IsReady()) return;

    if (udp < 0) {
        udp = DT_Udp_Begin(LOCAL_PORT);
        if (udp >= 0) {
            Serial.print("Listening on UDP ");
            Serial.println(LOCAL_PORT);
        }
        return;
    }

    uint8_t  buf[256];
    uint8_t  from[4];
    uint16_t port;
    int n = DT_Udp_RecvFrom(udp, buf, sizeof(buf), from, &port);
    if (n > 0) {
        DT_PrintIp("From: ", from);
        DT_Udp_SendTo(udp, from, port, buf, (uint16_t)n);
    }
}
