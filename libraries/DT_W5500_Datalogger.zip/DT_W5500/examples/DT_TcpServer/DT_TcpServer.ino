/**
 * @file DT_TcpServer.ino
 * @brief TCP Echo Server：監聽 Port 5000，回傳收到的資料。
 *
 * PC 端測試：ncat 192.168.1.178 5000
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};
uint8_t ip[4]  = {192, 168, 1, 178};
uint8_t sn[4]  = {255, 255, 255, 0};
uint8_t gw[4]  = {192, 168, 1, 1};

const uint16_t TCP_PORT = 5000;
int server = -1;

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 TCP Echo Server ---");

    DT_W5500_Begin(NULL);
    DT_Net_BeginStatic(mac, ip, sn, gw, NULL);
}

void loop() {
    DT_Net_Loop();
    if (!DT_Net_IsReady()) return;

    if (server < 0) {
        server = DT_TcpServer_Begin(TCP_PORT);
        if (server >= 0) {
            Serial.print("Listening on port ");
            Serial.println(TCP_PORT);
        }
        return;
    }

    static bool had_client = false;
    bool has_client = DT_TcpServer_Poll(server);
    if (has_client && !had_client) {
        uint8_t rip[4];
        uint16_t rport;
        DT_Tcp_GetRemote(server, rip, &rport);
        DT_PrintIp("Client connected: ", rip);
    } else if (!has_client && had_client) {
        Serial.println("Client disconnected.");
    }
    had_client = has_client;
    if (!has_client) return;

    uint8_t buf[512];
    int n = DT_Tcp_Recv(server, buf, sizeof(buf));
    if (n > 0) {
        Serial.print("Echo ");
        Serial.print(n);
        Serial.println(" bytes");
        DT_Tcp_Send(server, buf, (uint16_t)n);
    }
}
