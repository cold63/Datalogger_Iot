/**
 * @file DT_TcpClient.ino
 * @brief TCP Client：連線到 PC 的 TCP Server，每 5 秒送出一筆資料並列印回覆。
 *
 * PC 端可用：ncat -l 5000 -k  或任意 TCP Server 工具。
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

const char* SERVER_HOST = "192.168.1.104";   // 可填 IP 或網域名稱
const uint16_t SERVER_PORT = 5000;

int sock = -1;

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 TCP Client ---");

    DT_W5500_Begin(NULL);
    DT_Net_BeginDhcp(mac);
}

void loop() {
    DT_Net_Loop();
    if (!DT_Net_IsReady()) return;

    static uint32_t last = 0;
    if (millis() - last < 5000) return;
    last = millis();

    if (!DT_Tcp_IsConnected(sock)) {
        DT_Tcp_Close(sock);
        sock = DT_Tcp_Connect(SERVER_HOST, SERVER_PORT);
        if (sock < 0) {
            Serial.print("Connect failed: ");
            Serial.println(DT_ErrName(sock));
            return;
        }
        Serial.println("Connected.");
    }

    char msg[48];
    snprintf(msg, sizeof(msg), "Hello from RTL8720DF, uptime=%lu\r\n", millis() / 1000);
    DT_Tcp_SendStr(sock, msg);

    uint8_t buf[128];
    int n = DT_Tcp_RecvTimeout(sock, buf, sizeof(buf) - 1, 500);
    if (n > 0) {
        buf[n] = '\0';
        Serial.print("Reply: ");
        Serial.println((char*)buf);
    }
}
