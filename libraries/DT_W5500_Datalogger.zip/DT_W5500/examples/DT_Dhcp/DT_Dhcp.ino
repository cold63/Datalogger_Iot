/**
 * @file DT_Dhcp.ino
 * @brief DHCP 自動取得 IP，並示範網路狀態事件回呼。
 *
 * 拔除網線後再插回，DT_Net 會自動重新執行 DHCP。
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xFA};

void onNetEvent(DT_NetState_t state) {
    Serial.print("[NET] ");
    Serial.println(DT_Net_StateName(state));
    if (state == DT_NET_READY) DT_PrintNetInfo();
}

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 DHCP Example ---");

    if (DT_W5500_Begin(NULL) != DT_OK) {
        Serial.println("W5500 not found!");
        while (1) delay(1000);
    }
    DT_Net_SetEventCallback(onNetEvent);
    DT_Net_BeginDhcp(mac);
}

void loop() {
    DT_Net_Loop();   // 非阻塞：處理 Link 偵測、DHCP 與租約更新

    // 在此加入其他應用邏輯 (不要使用長時間 delay)
}
