/*
 * ============================================================================
 * 範例名稱: DT_ModbusTcp — Modbus TCP Server + Client 完整版
 * 目標平台: RTL8720DF (Realtek Ameba) - Datalogger IoT + W5500 擴展板
 * ============================================================================
 *
 * 功能說明:
 *   1. 初始化 W5500 並以 DHCP 或靜態 IP 設定網路 (由 useDHCP 決定)
 *   2. Modbus TCP Server：port 502，最多 2 條連線
 *      支援 FC01/02/03/04/05/06/15/16/22/23/43(MEI 14)
 *   3. Modbus TCP Client 輪詢表：定時讀取遠端 Slave，存入本機 IR / DI
 *      (非阻塞，不影響 Server 回應)
 *   4. 寫入檢查：HR20 (設定值) 只接受 0..1000
 *   5. 通訊中斷保護：Master 超過 FAILSAFE_MS 沒有請求時，Coil0..7 設為 OFF
 *   6. 設定保存：HR20..39 斷電保留 (Preferences / DCT)
 *   7. 閘道範例：Master 寫入本機 HR40 時，轉寫到遠端 Slave 的 HR5
 *
 * Server 資料表 (0-based 位址):
 *   IR0/IR1   開機秒數 (低/高 16 位)       IR2  模擬感測值 x10
 *   IR3..4    模擬感測值 float (ABCD)
 *   IR10..19  遠端 HR0..9 (輪詢項目 0)     IR20..23 遠端 IR0..3 (輪詢項目 1)
 *   DI0       網路 Ready                   DI1..3   輪詢項目 0..2 在線
 *   DI8..15   遠端 DI0..7 (輪詢項目 2)
 *   IR90..99  診斷資訊 (見 updateDiagRegisters())
 *   HR20..39  斷電保存的設定 (HR20 = 設定值)   HR40 轉寫到遠端
 *   Coil / HR 開放給 Master 寫入 (寫入時 Serial 會印出)
 *
 * PC 端測試工具 (Python 標準函式庫)：程式庫 extras/modbus_tools/
 *   python mb_sim_slave.py                 模擬遠端 Slave (slaveIp 填 PC 的 IP)
 *   python mb_test_master.py 192.168.1.117 自動測試本機 Server
 *
 * 通訊架構:
 *   SCADA/PC (Master) <--Modbus TCP--> W5500 <--Bit-bang SPI--> RTL8720DF
 *   RTL8720DF (Master) --Modbus TCP--> 遠端 Slave
 * ============================================================================
 */

/* ============================================================================
 * 程式庫引入區
 * ============================================================================ */
#include <DT_W5500.h>       // W5500 乙太網路程式庫 (含 Modbus TCP)

/* ============================================================================
 * W5500 腳位定義
 *   SCLK=19 MISO=16 MOSI=17 CS=18 RST=10 使用 DT_Config.h 預設值
 *   (DT_W5500_Begin(NULL))；INT 程式庫未定義，於此自行定義
 * ============================================================================ */
#if DT_PIN_RST_DEFAULT != 10
#error DT_W5500/src/DT_Config.h 的 DT_PIN_RST_DEFAULT 須為 10 (舊版程式庫為 11)
#endif

#define W5500_INT   11  // 中斷輸出 (W5500 INTn，低電位有效；DT_W5500 本身不使用)

/* ============================================================================
 * W5500 乙太網路設定 (DHCP / 靜態 IP)
 * ============================================================================ */
//#define useDHCP   // 使用 DHCP；註解此行改用下方靜態 IP 設定

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0x01}; // W5500 MAC 位址 (每台需唯一)

#ifndef useDHCP
uint8_t ip[4]  = {192, 168, 1, 117};  // 靜態 IP 位址
uint8_t sn[4]  = {255, 255, 255, 0};  // 子網路遮罩
uint8_t gw[4]  = {192, 168, 1, 1};    // 預設閘道
uint8_t dns[4] = {8, 8, 8, 8};        // DNS 伺服器
#endif

/* ============================================================================
 * Modbus 資料表 (大小可自訂)
 * ============================================================================ */
#define NUM_COILS   64
#define NUM_DI      64
#define NUM_HR      100
#define NUM_IR      100

uint8_t  mbCoils[DT_MB_BITS_BYTES(NUM_COILS)];  // bit 打包
uint8_t  mbDi[DT_MB_BITS_BYTES(NUM_DI)];
uint16_t mbHr[NUM_HR];
uint16_t mbIr[NUM_IR];

/* ============================================================================
 * Modbus 應用設定
 * ============================================================================ */
//#define MB_SELFTEST       // 開機先執行 PDU 自我測試 (不需網路)
#define USE_MB_CLIENT       // 啟用 Client 輪詢遠端 Slave；不需要時註解

#define MB_UNIT_ID        1     // 本機 Unit ID

uint8_t  slaveIp[4]   = {192, 168, 1, 106};   // 遠端 Slave IP (測試時填 PC 的 IP)
uint16_t slavePort    = 502;                  // 遠端 Slave port
uint8_t  slaveUnitId  = 1;                    // 遠端 Slave Unit ID

const uint32_t DATA_UPDATE_MS = 1000;         // 本機資料更新週期
const uint32_t FAILSAFE_MS    = 10000;        // Master 多久沒請求視為通訊中斷 (0 = 關閉)

/* 輪詢表：{ IP, port, Unit ID, 功能碼, 遠端位址, 數量, 本機位址, 週期 ms } */
const DT_MbPollTask_t pollTasks[] = {
    { {192, 168, 1, 106}, 502, 1, DT_MB_FC_READ_HOLDING,  0, 10, 10, 2000 },  // 遠端 HR0..9 → IR10..19
    { {192, 168, 1, 106}, 502, 1, DT_MB_FC_READ_INPUT,    0,  4, 20, 5000 },  // 遠端 IR0..3 → IR20..23
    { {192, 168, 1, 106}, 502, 1, DT_MB_FC_READ_DISCRETE, 0,  8,  8, 5000 },  // 遠端 DI0..7 → DI8..15
};
#define POLL_STATUS_DI    1     // DI1.. = 各輪詢項目是否在線

#define STORE_HR_START    20    // 斷電保存範圍 HR20..39
#define STORE_HR_COUNT    20

#define SETPOINT_HR       20    // 設定值暫存器 (寫入檢查範例，在保存範圍內)
#define SETPOINT_DEFAULT  500   // 出廠預設值 (沒有保存資料時使用)
#define SETPOINT_MAX      1000  // 設定值上限

#define FORWARD_HR        40    // Master 寫入此 HR 時轉寫到遠端
#define REMOTE_FORWARD_HR 5     // 遠端 Slave 的目標 HR

#define SAFE_COIL_START   0     // 通訊中斷時要關閉的 Coil 範圍
#define SAFE_COIL_COUNT   8

#define DIAG_IR           90    // 診斷資訊起始位址 (IR90..99)

/* ============================================================================
 * 函式: onNetEvent()
 * 功能: 網路狀態事件回呼
 * ============================================================================ */
void onNetEvent(DT_NetState_t state)
{
    Serial.print("[NET] ");
    Serial.println(DT_Net_StateName(state));
    if (state == DT_NET_READY) DT_PrintNetInfo();
}

/* ============================================================================
 * 函式: printResultError()
 * 功能: 印出 Client 錯誤 (例外回應時附上例外碼)
 * ============================================================================ */
void printResultError(int result)
{
    Serial.print(DT_ErrName(result));
    if (DT_Mb_ExceptionCode(result)) {
        Serial.print(" code ");
        Serial.print(DT_Mb_ExceptionCode(result));
    }
    Serial.println();
}

/* ============================================================================
 * 函式: onMbValidate()
 * 功能: Master 寫入前檢查，回傳 0 = 接受，否則回傳例外碼
 * 說明: FC15/16/23 只要有一筆被拒絕，整筆都不寫入
 * ============================================================================ */
uint8_t onMbValidate(DT_MbType_t type, uint16_t addr, uint16_t value)
{
    if (type == DT_MB_TYPE_HOLDING && addr == SETPOINT_HR && value > SETPOINT_MAX)
        return DT_MB_EX_ILLEGAL_VALUE;
    return 0;
}

/* ============================================================================
 * 函式: onMbWrite()
 * 功能: Master 寫入 Coil / Holding Register 後的回呼
 * 說明: 在此依寫入的位址驅動輸出 (例如 Coil0 控制繼電器)
 * ============================================================================ */
void onMbWrite(DT_MbType_t type, uint16_t addr, uint16_t count)
{
    for (uint16_t i = 0; i < count; i++) {
        uint16_t a = addr + i;
        Serial.print(type == DT_MB_TYPE_COIL ? "[MB] Coil" : "[MB] HR");
        Serial.print(a);
        Serial.print(" = ");
        if (type == DT_MB_TYPE_COIL) Serial.println(DT_MbData_GetCoil(a) ? "ON" : "OFF");
        else                         Serial.println(DT_MbData_GetHr(a));

#ifdef USE_MB_CLIENT
        // 閘道範例：轉寫到遠端 Slave (排在下一筆輪詢之前執行)
        if (type == DT_MB_TYPE_HOLDING && a == FORWARD_HR) {
            int r = DT_MbPoll_WriteRegister(slaveIp, slavePort, slaveUnitId, REMOTE_FORWARD_HR, DT_MbData_GetHr(a));
            if (r != DT_OK) { Serial.print("[MB] Forward rejected: "); Serial.println(DT_ErrName(r)); }
        }
#endif
    }
}

/* ============================================================================
 * 函式: onCommLost()
 * 功能: 通訊中斷 / 恢復回呼
 * 說明: 中斷時將輸出設為安全狀態；接實體輸出時在此同步驅動腳位
 * ============================================================================ */
void onCommLost(bool lost)
{
    if (lost) {
        for (uint16_t i = 0; i < SAFE_COIL_COUNT; i++) DT_MbData_SetCoil(SAFE_COIL_START + i, false);
        Serial.println("[MB] Master 通訊中斷，輸出已設為安全狀態");
    } else {
        Serial.println("[MB] Master 通訊恢復");
    }
}

/* ============================================================================
 * 函式: onPollDone()
 * 功能: 輪詢 / 轉寫完成回呼 (資料已由 DT_MbPoll 存入本機資料表)
 * ============================================================================ */
void onPollDone(int task, const DT_MbClientResult_t* r)
{
    if (task == DT_MB_POLL_WRITE_TASK) Serial.print("[MB] Forward write");
    else { Serial.print("[MB] Poll #"); Serial.print(task); }

    if (r->result != DT_OK) {
        Serial.print(" failed: ");
        printResultError(r->result);
        return;
    }
    if (r->fc == DT_MB_FC_READ_HOLDING || r->fc == DT_MB_FC_READ_INPUT) {
        Serial.print(r->fc == DT_MB_FC_READ_HOLDING ? " HR:" : " IR:");
        for (uint16_t i = 0; i < r->qty; i++) { Serial.print(' '); Serial.print(r->regs[i]); }
    } else if (r->fc == DT_MB_FC_READ_COILS || r->fc == DT_MB_FC_READ_DISCRETE) {
        Serial.print(" bits: ");
        for (uint16_t i = 0; i < r->qty; i++) Serial.print(DT_MbClient_Bit(r, i) ? '1' : '0');
    } else {
        Serial.print(" OK");
    }
    Serial.println();
}

/* ============================================================================
 * 函式: logLine()
 * 功能: 提供給 DT_MbSelfTest 的文字輸出
 * ============================================================================ */
void logLine(const char* line)
{
    Serial.println(line);
}

/* ============================================================================
 * 函式: updateLocalData()
 * 功能: 更新 Server 資料表的示範資料
 * ============================================================================ */
void updateLocalData()
{
    uint32_t sec = millis() / 1000;
    DT_MbData_SetIr(0, (uint16_t)(sec & 0xFFFF));           // 開機秒數 低 16 位
    DT_MbData_SetIr(1, (uint16_t)(sec >> 16));              // 開機秒數 高 16 位
    DT_MbData_SetIr(2, (uint16_t)(250 + (sec % 20)));       // 模擬感測值 (例如 25.0~26.9 度 x10)
    DT_MbData_SetIrFloat(3, 25.0f + (sec % 20) * 0.1f);     // 同一個值的 float 版本 (IR3..4)
    DT_MbData_SetDi(0, DT_Net_IsReady());                   // 網路狀態

    for (int i = 0; i < DT_MbPoll_Count(); i++) {           // 輪詢項目在線狀態
        DT_MbPollStatus_t st;
        if (DT_MbPoll_GetStatus(i, &st)) DT_MbData_SetDi(POLL_STATUS_DI + i, st.online);
    }
}

/* ============================================================================
 * 函式: updateDiagRegisters()
 * 功能: 將通訊統計放入 IR90..99，讓 SCADA 監看
 *   IR90 Server 連線數        IR95 Client 成功次數
 *   IR91 Server 請求數        IR96 Client 失敗次數
 *   IR92 Server 例外回覆數    IR97 Client 最後錯誤 (0=OK，其他=-DT_Err_t，100+n=例外碼 n)
 *   IR93 MBAP 格式錯誤數      IR98 Client 已連線 (0/1)
 *   IR94 閒置/滿線斷線數      IR99 Master 通訊中斷 (0/1)
 *   (計數為累計值的低 16 位)
 * ============================================================================ */
void updateDiagRegisters()
{
    DT_MbStats_t s;
    DT_MbClientStats_t c;
    DT_MbServer_GetStats(&s);
    DT_MbClient_GetStats(&c);

    DT_MbData_SetIr(DIAG_IR + 0, s.clients);
    DT_MbData_SetIr(DIAG_IR + 1, (uint16_t)s.requests);
    DT_MbData_SetIr(DIAG_IR + 2, (uint16_t)s.exceptions);
    DT_MbData_SetIr(DIAG_IR + 3, (uint16_t)s.frame_errors);
    DT_MbData_SetIr(DIAG_IR + 4, (uint16_t)(s.idle_drops + s.evictions));
    DT_MbData_SetIr(DIAG_IR + 5, (uint16_t)c.ok);
    DT_MbData_SetIr(DIAG_IR + 6, (uint16_t)c.errors);
    DT_MbData_SetIr(DIAG_IR + 7, (uint16_t)(-c.last_error));
    DT_MbData_SetIr(DIAG_IR + 8, c.connected);
    DT_MbData_SetIr(DIAG_IR + 9, DT_MbServer_CommLost());
}

/* ============================================================================
 * 函式: setup()
 * 功能: 系統初始化設定
 * 說明:
 *   1. 初始化除錯序列埠 (115200 bps)
 *   2. 設定資料表；(選用) PDU 自我測試
 *   3. 放入出廠預設值，再以 Flash 保存的設定覆蓋
 *   4. 初始化 W5500 並設定網路
 *   5. 啟動 Modbus Server / Client 輪詢
 * ============================================================================ */
void setup() {
  Serial.begin(115200);     // 初始化除錯序列埠 (115200 bps)

  DT_MbData_Begin(mbCoils, NUM_COILS, mbDi, NUM_DI, mbHr, NUM_HR, mbIr, NUM_IR);

#ifdef MB_SELFTEST
  DT_MbSelfTest_Run(logLine);   // 使用內部測試資料表，不影響上面的資料表
#endif

  // 設定值：先放出廠預設，Flash 有有效資料時覆蓋
  DT_MbData_SetHr(SETPOINT_HR, SETPOINT_DEFAULT);
  DT_MbStore_Begin(STORE_HR_START, STORE_HR_COUNT);
  if (DT_MbStore_Load() == DT_OK) Serial.println("[STORE] 已載入保存的設定");
  else                            Serial.println("[STORE] 無保存資料，使用出廠預設值");
  Serial.print("[STORE] HR20 (設定值) = ");
  Serial.println(DT_MbData_GetHr(SETPOINT_HR));

  // 初始化 W5500 並設定網路
  if (DT_W5500_Begin(NULL) != DT_OK) Serial.println("W5500 not found!");  // NULL = DT_Config.h 預設腳位
  DT_Net_SetEventCallback(onNetEvent);
#ifdef useDHCP
  DT_Net_BeginDhcp(mac);                    // DHCP 自動取得 IP
#else
  DT_Net_BeginStatic(mac, ip, sn, gw, dns); // 使用靜態 IP
#endif

  // Modbus Server (網路 Ready 後由 DT_MbServer_Loop() 開始監聽)
  DT_MbData_SetValidateCb(onMbValidate);
  DT_MbData_SetWriteCb(onMbWrite);
  DT_MbServer_SetFailsafe(FAILSAFE_MS, onCommLost);
  DT_MbServer_Begin(DT_MB_TCP_PORT, MB_UNIT_ID);

#ifdef USE_MB_CLIENT
  DT_MbPoll_SetCallback(onPollDone);
  for (unsigned i = 0; i < sizeof(pollTasks) / sizeof(pollTasks[0]); i++) {
    if (DT_MbPoll_Add(&pollTasks[i]) < 0) { Serial.print("[MB] Poll task invalid: #"); Serial.println(i); }
  }
#endif
}

/* ============================================================================
 * 函式: loop()
 * 功能: 主程式迴圈
 * ============================================================================ */
void loop() {
  DT_Net_Loop();        // 非阻塞：處理 Link 偵測、DHCP 與租約更新
  DT_MbServer_Loop();   // 非阻塞：處理 Modbus Server 連線與請求
#ifdef USE_MB_CLIENT
  DT_MbPoll_Loop();     // 非阻塞：輪詢表 + Client 狀態機
#endif

  static uint32_t lastData = 0;
  if (millis() - lastData >= DATA_UPDATE_MS) {
    lastData = millis();
    updateLocalData();
    updateDiagRegisters();
  }

  if (DT_MbStore_Loop()) Serial.println("[STORE] 設定已寫入 Flash");   // 值穩定 3 秒後才寫入

  // 在此加入應用邏輯 (不要使用長時間 delay)
}
