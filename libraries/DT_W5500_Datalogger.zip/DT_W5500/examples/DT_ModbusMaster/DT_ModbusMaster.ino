/*
 * ============================================================================
 * 範例名稱: DT_ModbusMaster — Modbus TCP Master (Client)
 * 目標平台: RTL8720DF (Realtek Ameba) - Datalogger IoT + W5500 擴展板
 * ============================================================================
 *
 * 功能說明:
 *   板子當 Modbus TCP Master，定時讀取遠端 Slave (電表、PLC、其他 Slave)
 *   1. 輪詢表：每個項目各自設定 IP / Unit ID / 功能碼 / 位址 / 數量 / 週期
 *      讀回的值存入本機快取 (IR / DI)，並由回呼印出
 *   2. 連續失敗 3 次標記離線，Slave 恢復後自動重連
 *   3. 每 10 秒寫一次遠端 HR6 = 開機秒數 (FC06 示範)
 *   4. Serial 指令 (115200，換行結尾)：
 *        w <addr> <value>   寫遠端 HR (FC06)，例如 w 5 123
 *        c <addr> <0|1>     寫遠端 Coil (FC05)，例如 c 0 1
 *        s                  顯示各輪詢項目狀態
 *   全部非阻塞，loop() 中可加入其他工作
 *
 * PC 端測試 (程式庫 extras/modbus_tools/)：
 *   python mb_sim_slave.py        在 PC 模擬 Slave (slaveIp 填 PC 的 IP)
 *   可加 --delay 2000 / --exception 2 / --drop 測試錯誤處理
 * ============================================================================
 */

#include <DT_W5500.h>       // W5500 乙太網路程式庫 (含 Modbus TCP)

/* ============================================================================
 * 網路設定
 * ============================================================================ */
uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0x02}; // W5500 MAC 位址 (每台需唯一)
uint8_t ip[4]  = {192, 168, 1, 118};  // 靜態 IP 位址
uint8_t sn[4]  = {255, 255, 255, 0};  // 子網路遮罩
uint8_t gw[4]  = {192, 168, 1, 1};    // 預設閘道

/* ============================================================================
 * 遠端 Slave 與輪詢表
 * ============================================================================ */
uint8_t  slaveIp[4]  = {192, 168, 1, 106};   // 遠端 Slave IP (測試時填 PC 的 IP)
uint16_t slavePort   = 502;
uint8_t  slaveUnitId = 1;

/* { IP, port, Unit ID, 功能碼, 遠端位址, 數量, 本機快取位址, 週期 ms } */
const DT_MbPollTask_t pollTasks[] = {
    { {192, 168, 1, 106}, 502, 1, DT_MB_FC_READ_HOLDING,  0, 10,  0, 1000 },  // 遠端 HR0..9 → 快取 IR0..9
    { {192, 168, 1, 106}, 502, 1, DT_MB_FC_READ_INPUT,    0,  4, 10, 5000 },  // 遠端 IR0..3 → 快取 IR10..13
    { {192, 168, 1, 106}, 502, 1, DT_MB_FC_READ_DISCRETE, 0,  8,  0, 5000 },  // 遠端 DI0..7 → 快取 DI0..7
};
#define TASK_COUNT  (sizeof(pollTasks) / sizeof(pollTasks[0]))

/* 本機快取：只需要 IR 與 DI (Master 不提供 Server，Coils / HR 傳 NULL) */
#define NUM_DI      16
#define NUM_IR      32
uint8_t  cacheDi[DT_MB_BITS_BYTES(NUM_DI)];
uint16_t cacheIr[NUM_IR];

const uint32_t DEMO_WRITE_MS = 10000;   // 示範寫入週期
#define DEMO_WRITE_HR   6               // 示範寫入的遠端 HR

bool lastOnline[TASK_COUNT];            // 用來偵測在線狀態改變

/* ============================================================================
 * 函式: printResultError()
 * 功能: 印出錯誤名稱 (例外回應時附上例外碼)
 * ============================================================================ */
void printResultError(int result)
{
    Serial.print(DT_ErrName(result));
    if (DT_Mb_ExceptionCode(result)) {
        Serial.print(" code ");
        Serial.print(DT_Mb_ExceptionCode(result));
    }
    Serial.println();
}

/* ============================================================================
 * 函式: onPollDone()
 * 功能: 每筆輪詢 / 寫入完成時呼叫 (讀回的值已存入快取)
 * ============================================================================ */
void onPollDone(int task, const DT_MbClientResult_t* r)
{
    if (task == DT_MB_POLL_WRITE_TASK) {
        Serial.print("[MB] Write FC");
        Serial.print(r->fc);
        Serial.print(" addr ");
        Serial.print(r->addr);
        Serial.print(": ");
        if (r->result == DT_OK) Serial.println("OK");
        else                    printResultError(r->result);
        return;
    }

    if (r->result != DT_OK) {
        Serial.print("[MB] Poll #");
        Serial.print(task);
        Serial.print(" failed: ");
        printResultError(r->result);
        return;
    }
    Serial.print("[MB] Poll #");
    Serial.print(task);
    if (r->fc == DT_MB_FC_READ_HOLDING || r->fc == DT_MB_FC_READ_INPUT) {
        Serial.print(r->fc == DT_MB_FC_READ_HOLDING ? " HR:" : " IR:");
        for (uint16_t i = 0; i < r->qty; i++) { Serial.print(' '); Serial.print(r->regs[i]); }
    } else {
        Serial.print(" bits: ");
        for (uint16_t i = 0; i < r->qty; i++) Serial.print(DT_MbClient_Bit(r, i) ? '1' : '0');
    }
    Serial.println();
}

/* ============================================================================
 * 函式: checkOnline()
 * 功能: 輪詢項目在線 / 離線改變時印出
 * ============================================================================ */
void checkOnline()
{
    for (unsigned i = 0; i < TASK_COUNT; i++) {
        DT_MbPollStatus_t st;
        if (!DT_MbPoll_GetStatus(i, &st) || st.online == lastOnline[i]) continue;
        lastOnline[i] = st.online;
        Serial.print("[MB] Task #");
        Serial.print(i);
        Serial.println(st.online ? " online" : " OFFLINE");
    }
}

/* ============================================================================
 * 函式: printStatus()
 * 功能: 顯示各輪詢項目狀態 (Serial 指令 s)
 * ============================================================================ */
void printStatus()
{
    for (unsigned i = 0; i < TASK_COUNT; i++) {
        DT_MbPollStatus_t st;
        if (!DT_MbPoll_GetStatus(i, &st)) continue;
        Serial.print("  #");  Serial.print(i);
        Serial.print(st.online ? " online " : " offline");
        Serial.print(" ok=");   Serial.print(st.ok);
        Serial.print(" err=");  Serial.print(st.errors);
        Serial.print(" last="); Serial.println(DT_ErrName(st.last_result));
    }
}

/* ============================================================================
 * 函式: handleSerial()
 * 功能: 解析 Serial 指令 (w / c / s)
 * ============================================================================ */
void handleSerial()
{
    static char line[32];
    static uint8_t len = 0;
    while (Serial.available()) {
        char ch = (char)Serial.read();
        if (ch != '\n' && ch != '\r') {
            if (len < sizeof(line) - 1) line[len++] = ch;
            continue;
        }
        if (len == 0) continue;
        line[len] = '\0';
        len = 0;

        char cmd = 0;
        long addr = 0, val = 0;
        int n = sscanf(line, "%c %ld %ld", &cmd, &addr, &val);
        int r = DT_ERR_PARAM;
        if (cmd == 's') { printStatus(); continue; }
        if (n == 3 && cmd == 'w')
            r = DT_MbPoll_WriteRegister(slaveIp, slavePort, slaveUnitId, (uint16_t)addr, (uint16_t)val);
        else if (n == 3 && cmd == 'c')
            r = DT_MbPoll_WriteCoil(slaveIp, slavePort, slaveUnitId, (uint16_t)addr, val != 0);
        if (r == DT_OK) Serial.println("[CMD] queued");
        else { Serial.print("[CMD] "); Serial.print(DT_ErrName(r)); Serial.println("  (w <addr> <val> | c <addr> <0|1> | s)"); }
    }
}

void setup() {
  Serial.begin(115200);

  // 本機快取 (輪詢結果存放處)
  DT_MbData_Begin(NULL, 0, cacheDi, NUM_DI, NULL, 0, cacheIr, NUM_IR);

  if (DT_W5500_Begin(NULL) != DT_OK) Serial.println("W5500 not found!");
  DT_Net_BeginStatic(mac, ip, sn, gw, NULL);

  DT_MbPoll_SetCallback(onPollDone);
  for (unsigned i = 0; i < TASK_COUNT; i++) {
    if (DT_MbPoll_Add(&pollTasks[i]) < 0) { Serial.print("[MB] Poll task invalid: #"); Serial.println(i); }
  }
  Serial.println("[MB] Modbus TCP Master  (commands: w <addr> <val> | c <addr> <0|1> | s)");
}

void loop() {
  DT_Net_Loop();        // 網路管理 (必要)
  DT_MbPoll_Loop();     // 輪詢表 + Client 狀態機 (非阻塞)

  // 定時示範寫入：遠端 HR6 = 開機秒數
  static uint32_t lastWrite = 0;
  if (DT_Net_IsReady() && millis() - lastWrite >= DEMO_WRITE_MS) {
    lastWrite = millis();
    DT_MbPoll_WriteRegister(slaveIp, slavePort, slaveUnitId, DEMO_WRITE_HR, (uint16_t)(millis() / 1000));
  }

  checkOnline();
  handleSerial();

  // 在此加入應用邏輯，例如使用快取值：DT_MbData_GetIr(0) = 遠端 HR0
}
