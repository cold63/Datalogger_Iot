/**
 * @file DT_UdpClient.ino
 * @brief UDP Client：每 5 秒送訊息到 PC，並列印回覆。
 *
 * 搭配專案中的 udp_server.py (監聽 5000)。
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xEE};

uint8_t  target_ip[4] = {192, 168, 1, 104};   // PC IP
const uint16_t TARGET_PORT = 5000;
const uint16_t LOCAL_PORT  = 6000;

int udp = -1;

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 UDP Client ---");

    DT_W5500_Begin(NULL);
    DT_Net_BeginDhcp(mac);
}

void loop() {
    DT_Net_Loop();
    if (!DT_Net_IsReady()) return;

    if (udp < 0) {
        udp = DT_Udp_Begin(LOCAL_PORT);
        return;
    }

    static uint32_t last = 0;
    if (millis() - last >= 5000) {
        last = millis();
        const char* msg = "Hello from RTL8720DF!";
        int r = DT_Udp_SendTo(udp, target_ip, TARGET_PORT, (const uint8_t*)msg, strlen(msg));
        Serial.print("Send: ");
        Serial.println(r > 0 ? "OK" : DT_ErrName(r));
    }

    uint8_t  buf[128];
    uint8_t  from[4];
    uint16_t port;
    int n = DT_Udp_RecvFrom(udp, buf, sizeof(buf) - 1, from, &port);
    if (n > 0) {
        buf[n] = '\0';
        Serial.print("Reply: ");
        Serial.println((char*)buf);
    }
}
