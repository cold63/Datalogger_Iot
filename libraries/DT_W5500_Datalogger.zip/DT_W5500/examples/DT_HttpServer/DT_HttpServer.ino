/**
 * @file DT_HttpServer.ino
 * @brief 簡易 Web Server：狀態網頁、JSON API 與 LED 控制。
 *
 * 瀏覽器開啟 http://<板子 IP>/ 即可看到狀態頁。
 *   GET /             狀態網頁 (每 2 秒自動更新)
 *   GET /api/status   JSON 狀態
 *   GET /led/on       LED 開
 *   GET /led/off      LED 關
 *
 * 使用 2 個 socket 同時監聽 Port 80，瀏覽器同時發出多個請求 (例如 favicon) 時不會互相阻塞。
 * 每個請求回應後即關閉連線 (Connection: close)。
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

#define HTTP_PORT       80
#define SERVER_SOCKETS  2
#define REQ_BUF_SIZE    512
#define REQ_TIMEOUT_MS  3000

#ifdef LED_BUILTIN
#define LED_PIN LED_BUILTIN
#else
#define LED_PIN 13
#endif

typedef struct {
    int      sock;
    bool     active;                // client connected
    uint16_t len;
    uint32_t since;
    char     buf[REQ_BUF_SIZE];
} HttpConn;

HttpConn conns[SERVER_SOCKETS];
bool led_on = false;

const char INDEX_HTML[] =
    "<!DOCTYPE html><html><head><meta charset='utf-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>DT_W5500</title>"
    "<style>body{font-family:sans-serif;max-width:420px;margin:24px auto;padding:0 16px}"
    "td{padding:4px 12px 4px 0}button{font-size:16px;padding:8px 20px;margin-right:8px}</style>"
    "</head><body><h2>RTL8720DF + W5500</h2><table>"
    "<tr><td>IP</td><td id='ip'>-</td></tr>"
    "<tr><td>Uptime</td><td id='up'>-</td></tr>"
    "<tr><td>LED</td><td id='led'>-</td></tr></table><p>"
    "<button onclick=\"go('/led/on')\">LED ON</button>"
    "<button onclick=\"go('/led/off')\">LED OFF</button></p>"
    "<script>"
    "function show(j){ip.textContent=j.ip;up.textContent=j.uptime+' s';led.textContent=j.led?'ON':'OFF';}"
    "function go(u){fetch(u).then(r=>r.json()).then(show);}"
    "go('/api/status');setInterval(()=>go('/api/status'),2000);"
    "</script></body></html>";

/* ===== Response helpers ===== */

void sendResponse(int sock, int code, const char* status, const char* type, const char* body) {
    char hdr[160];
    snprintf(hdr, sizeof(hdr),
             "HTTP/1.1 %d %s\r\n"
             "Content-Type: %s\r\n"
             "Content-Length: %u\r\n"
             "Cache-Control: no-store\r\n"
             "Connection: close\r\n\r\n",
             code, status, type, (unsigned)strlen(body));
    DT_Tcp_SendStr(sock, hdr);
    DT_Tcp_SendStr(sock, body);
}

void sendStatusJson(int sock) {
    uint8_t ip[4];
    char ipstr[16], json[96];
    DT_Net_GetLocalIp(ip);
    DT_IpToStr(ip, ipstr);
    snprintf(json, sizeof(json), "{\"ip\":\"%s\",\"uptime\":%lu,\"led\":%s}",
             ipstr, millis() / 1000, led_on ? "true" : "false");
    sendResponse(sock, 200, "OK", "application/json", json);
}

void setLed(bool on) {
    led_on = on;
    digitalWrite(LED_PIN, on ? HIGH : LOW);
}

/* ===== Request handling ===== */

void handleRequest(HttpConn* c) {
    // Request line: "GET /path HTTP/1.1"
    char method[8] = {0}, path[64] = {0};
    sscanf(c->buf, "%7s %63s", method, path);
    char* q = strchr(path, '?');        // ignore query string
    if (q) *q = '\0';

    Serial.print("[HTTP] ");
    Serial.print(method);
    Serial.print(" ");
    Serial.println(path);

    if (strcmp(method, "GET") != 0) {
        sendResponse(c->sock, 405, "Method Not Allowed", "text/plain", "Method Not Allowed");
    } else if (strcmp(path, "/") == 0 || strcmp(path, "/index.html") == 0) {
        sendResponse(c->sock, 200, "OK", "text/html; charset=utf-8", INDEX_HTML);
    } else if (strcmp(path, "/api/status") == 0) {
        sendStatusJson(c->sock);
    } else if (strcmp(path, "/led/on") == 0) {
        setLed(true);
        sendStatusJson(c->sock);
    } else if (strcmp(path, "/led/off") == 0) {
        setLed(false);
        sendStatusJson(c->sock);
    } else {
        sendResponse(c->sock, 404, "Not Found", "text/plain", "Not Found");
    }
}

void finishClient(HttpConn* c) {
    DT_TcpServer_DropClient(c->sock);   // close and listen again
    c->active = false;
    c->len = 0;
}

// Non-blocking: collect the request header across loop() calls
void serviceConn(HttpConn* c) {
    if (!DT_TcpServer_Poll(c->sock)) {
        c->active = false;
        c->len = 0;
        return;
    }
    if (!c->active) {
        c->active = true;
        c->len = 0;
        c->buf[0] = '\0';
        c->since = millis();
    }

    int n = DT_Tcp_Recv(c->sock, (uint8_t*)c->buf + c->len, REQ_BUF_SIZE - 1 - c->len);
    if (n > 0) {
        c->len += n;
        c->buf[c->len] = '\0';
    }

    if (strstr(c->buf, "\r\n\r\n")) {            // header complete (body ignored)
        handleRequest(c);
        finishClient(c);
    } else if (c->len >= REQ_BUF_SIZE - 1) {
        sendResponse(c->sock, 431, "Request Header Fields Too Large", "text/plain", "Too Large");
        finishClient(c);
    } else if (millis() - c->since > REQ_TIMEOUT_MS) {
        finishClient(c);                         // idle client
    }
}

/* ===== Main ===== */

void onNetEvent(DT_NetState_t state) {
    Serial.print("[NET] ");
    Serial.println(DT_Net_StateName(state));
    if (state == DT_NET_READY) {
        uint8_t ip[4];
        DT_Net_GetLocalIp(ip);
        char ipstr[16];
        DT_IpToStr(ip, ipstr);
        Serial.print("Open http://");
        Serial.print(ipstr);
        Serial.println("/");
    }
}

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 HTTP Server ---");

    pinMode(LED_PIN, OUTPUT);
    setLed(false);

    if (DT_W5500_Begin(NULL) != DT_OK) {
        Serial.println("W5500 not found!");
        while (1) delay(1000);
    }
    DT_Net_SetEventCallback(onNetEvent);
    DT_Net_BeginDhcp(mac);

    for (int i = 0; i < SERVER_SOCKETS; i++) conns[i].sock = -1;
}

void loop() {
    DT_Net_Loop();
    if (!DT_Net_IsReady()) return;

    for (int i = 0; i < SERVER_SOCKETS; i++) {
        HttpConn* c = &conns[i];
        if (c->sock < 0) {
            c->sock = DT_TcpServer_Begin(HTTP_PORT);   // multiple sockets may listen on the same port
            c->active = false;
            c->len = 0;
            continue;
        }
        serviceConn(c);
    }
}
