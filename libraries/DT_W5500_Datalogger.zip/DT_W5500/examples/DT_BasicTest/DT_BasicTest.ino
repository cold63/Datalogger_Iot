/**
 * @file DT_BasicTest.ino
 * @brief W5500 基本連線測試：晶片偵測、PHY Link、靜態 IP 設定。
 *
 * 完成後可從 PC 執行 ping 192.168.1.178 確認連線。
 */

#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};
uint8_t ip[4]  = {192, 168, 1, 178};
uint8_t sn[4]  = {255, 255, 255, 0};
uint8_t gw[4]  = {192, 168, 1, 1};
uint8_t dns[4] = {8, 8, 8, 8};

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 Basic Test ---");

    // 預設腳位 SCLK=19 MISO=16 MOSI=17 CS=18 RST=11；自訂腳位可傳入 DT_Pins_t
    int r = DT_W5500_Begin(NULL);
    Serial.print("Chip version: 0x");
    Serial.println(DT_W5500_GetVersion(), HEX);
    if (r != DT_OK) {
        Serial.print("W5500 init failed: ");
        Serial.println(DT_ErrName(r));
        while (1) delay(1000);
    }

    DT_Net_BeginStatic(mac, ip, sn, gw, dns);
    r = DT_Net_WaitReady(10000);
    if (r != DT_OK) {
        Serial.print("Network not ready: ");
        Serial.println(DT_ErrName(r));
    }
    DT_PrintNetInfo();
}

void loop() {
    DT_Net_Loop();

    static uint32_t last = 0;
    if (millis() - last >= 5000) {
        last = millis();
        Serial.print("Link: ");
        Serial.print(DT_W5500_IsLinkUp() ? "UP" : "DOWN");
        Serial.print("  Net: ");
        Serial.println(DT_Net_StateName(DT_Net_GetState()));
    }
}
