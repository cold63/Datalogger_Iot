/**
 * @file DT_MqttTls.ino
 * @brief MQTTS (port 8883) 範例，可選擇靜態 IP 或 DHCP。
 *
 * 預設不驗證 Broker 憑證；需要時將 Root CA 填入 ROOT_CA 並設 USE_CA 為 1。
 * 雙向認證 (mTLS) 可再填 tls.client_cert / tls.client_key (PEM 字串)。
 */

#include <DT_W5500.h>

#define USE_DHCP 1
#define USE_CA   0

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};
#if !USE_DHCP
uint8_t ip[4]  = {192, 168, 1, 178};
uint8_t sn[4]  = {255, 255, 255, 0};
uint8_t gw[4]  = {192, 168, 1, 1};
uint8_t dns[4] = {8, 8, 8, 8};
#endif

#if USE_CA
const char ROOT_CA[] =
    "-----BEGIN CERTIFICATE-----\n"
    "...\n"
    "-----END CERTIFICATE-----\n";
#endif

const char* PUB_TOPIC = "w5500/test/status";
const char* SUB_TOPIC = "w5500/test/control";

DT_TlsConfig_t tls;   // 必須在連線期間保持有效 (全域變數)

void onMessage(const char* topic, const uint8_t* payload, uint16_t len) {
    Serial.print("[MQTT] ");
    Serial.print(topic);
    Serial.print(": ");
    Serial.write(payload, len);
    Serial.println();
}

void onMqttState(DT_MqttState_t st) {
    Serial.print("[MQTT] state: ");
    Serial.println(DT_Mqtt_StateName(st));
    if (st == DT_MQTT_CONNECTING) Serial.println("[TLS] Handshake (10-30s)...");
    if (st == DT_MQTT_RETRY_WAIT) {
        Serial.print("[MQTT] error: ");
        Serial.print(DT_ErrName(DT_Mqtt_LastError()));
        Serial.print("  mbedtls=");
        Serial.println(DT_Tls_LastError());
    }
}

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 MQTT over TLS ---");

    DT_W5500_Begin(NULL);
#if USE_DHCP
    DT_Net_BeginDhcp(mac);
#else
    DT_Net_BeginStatic(mac, ip, sn, gw, dns);
#endif

    DT_Tls_ConfigDefault(&tls);
#if USE_CA
    tls.ca_cert = ROOT_CA;
#endif

    DT_MqttConfig_t cfg;
    DT_Mqtt_ConfigDefault(&cfg);
    cfg.host = "broker.hivemq.com";
    cfg.port = 8883;
    cfg.client_id = "RTL8720D_W5500_TLS";
    cfg.use_tls = true;
    cfg.tls = &tls;
    DT_Mqtt_Begin(&cfg);

    DT_Mqtt_SetCallback(onMessage);
    DT_Mqtt_SetStateCallback(onMqttState);
    DT_Mqtt_Subscribe(SUB_TOPIC, 0);
}

void loop() {
    DT_Net_Loop();
    DT_Mqtt_Loop();

    static uint32_t last = 0;
    if (DT_Mqtt_IsConnected() && millis() - last >= 10000) {
        last = millis();
        char payload[48];
        snprintf(payload, sizeof(payload), "{\"uptime\": %lu}", millis() / 1000);
        Serial.print("[MQTT] Pub: ");
        Serial.println(payload);
        DT_Mqtt_PublishStr(PUB_TOPIC, payload);
    }
}
