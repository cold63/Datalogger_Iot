/**
 * @file DT_HttpsClient.ino
 * @brief HTTPS GET 範例，並以串流 callback 處理大型回應。
 *
 * 預設不驗證伺服器憑證。要驗證時，將伺服器的 Root CA (PEM) 填入 ROOT_CA
 * 並把 USE_CA 設為 1（需正確系統時間）。
 * Bit-bang SPI 下 TLS 握手約 10~30 秒。
 */

#include <DT_W5500.h>

#define USE_CA 0

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

#if USE_CA
const char ROOT_CA[] =
    "-----BEGIN CERTIFICATE-----\n"
    "...\n"
    "-----END CERTIFICATE-----\n";
#endif

DT_TlsConfig_t tls;
uint32_t total = 0;

// Body 串流處理：不需要大型緩衝區
void onBody(const uint8_t* data, uint16_t len) {
    total += len;
    Serial.write(data, len);
}

void setup() {
    Serial.begin(115200);
    while (!Serial) delay(10);
    Serial.println("\n--- DT_W5500 HTTPS Client ---");

    DT_W5500_Begin(NULL);
    DT_Net_BeginDhcp(mac);

    DT_Tls_ConfigDefault(&tls);
#if USE_CA
    tls.ca_cert = ROOT_CA;
#endif
}

void loop() {
    DT_Net_Loop();
    if (!DT_Net_IsReady()) return;

    static uint32_t last = 0;
    static bool first = true;
    if (!first && millis() - last < 60000) return;
    first = false;

    DT_HttpReq_t req;
    DT_Http_ReqDefault(&req);
    req.url = "https://www.howsmyssl.com/a/check";
    req.tls = &tls;
    req.body_cb = onBody;

    DT_HttpResp_t resp;
    total = 0;
    Serial.println("[HTTPS] Requesting (TLS handshake may take a while)...");
    int r = DT_Http_Request(&req, &resp);
    Serial.println();
    if (r < 0) {
        Serial.print("[HTTPS] Failed: ");
        Serial.print(DT_ErrName(r));
        Serial.print("  mbedtls=");
        Serial.println(DT_Tls_LastError());
    } else {
        Serial.print("[HTTPS] Status ");
        Serial.print(r);
        Serial.print(", ");
        Serial.print(total);
        Serial.println(" bytes");
    }
    last = millis();
}
