/*
 * ============================================================================
 * 範例名稱: DT_ModbusSlave — Modbus TCP Slave (Server)
 * 目標平台: RTL8720DF (Realtek Ameba) - Datalogger IoT + W5500 擴展板
 * ============================================================================
 *
 * 功能說明:
 *   板子當 Modbus TCP Slave，讓 SCADA / HMI / PC 讀寫資料表
 *   1. Server：port 502，最多 2 條連線，連線滿時踢掉閒置最久的一條
 *      支援 FC01/02/03/04/05/06/15/16/22/23/43(MEI 14)
 *   2. 寫入檢查：HR20 (設定值) 只接受 0..1000
 *   3. 通訊中斷保護：Master 超過 FAILSAFE_MS 沒有請求時，Coil0..7 設為 OFF
 *   4. 設定保存：HR20..39 斷電保留 (Preferences / DCT)
 *
 * 資料表 (0-based 位址):
 *   IR0/IR1   開機秒數 (低/高 16 位)   IR2  模擬感測值 x10
 *   IR3..4    模擬感測值 float (ABCD)  DI0  網路 Ready
 *   IR90..94  診斷：連線數 / 請求數 / 例外數 / 格式錯誤數 / 斷線數
 *   HR20..39  斷電保存的設定 (HR20 = 設定值)
 *   Coil0..7  輸出 (通訊中斷時自動 OFF)
 *
 * PC 端測試 (程式庫 extras/modbus_tools/)：
 *   python mb_test_master.py 192.168.1.117   (輪詢/閘道相關項目會自動 SKIP)
 *   也可用 QModMaster / Modbus Poll 等工具，40001 對應 HR0
 * ============================================================================
 */

#include <DT_W5500.h>       // W5500 乙太網路程式庫 (含 Modbus TCP)

/* ============================================================================
 * 網路設定
 * ============================================================================ */
uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0x01}; // W5500 MAC 位址 (每台需唯一)
uint8_t ip[4]  = {192, 168, 1, 117};  // 靜態 IP 位址
uint8_t sn[4]  = {255, 255, 255, 0};  // 子網路遮罩
uint8_t gw[4]  = {192, 168, 1, 1};    // 預設閘道

/* ============================================================================
 * Modbus 資料表 (大小可自訂)
 * ============================================================================ */
#define NUM_COILS   32
#define NUM_DI      16
#define NUM_HR      100
#define NUM_IR      100

uint8_t  mbCoils[DT_MB_BITS_BYTES(NUM_COILS)];
uint8_t  mbDi[DT_MB_BITS_BYTES(NUM_DI)];
uint16_t mbHr[NUM_HR];
uint16_t mbIr[NUM_IR];

#define MB_UNIT_ID        1
const uint32_t FAILSAFE_MS = 10000;   // Master 多久沒請求視為通訊中斷 (0 = 關閉)

#define STORE_HR_START    20          // 斷電保存範圍 HR20..39
#define STORE_HR_COUNT    20
#define SETPOINT_HR       20          // 設定值
#define SETPOINT_DEFAULT  500
#define SETPOINT_MAX      1000

#define SAFE_COIL_START   0           // 通訊中斷時要關閉的 Coil
#define SAFE_COIL_COUNT   8
#define DIAG_IR           90

/* ============================================================================
 * 函式: onMbValidate()
 * 功能: Master 寫入前檢查，回傳 0 = 接受，否則回傳例外碼
 * ============================================================================ */
uint8_t onMbValidate(DT_MbType_t type, uint16_t addr, uint16_t value)
{
    if (type == DT_MB_TYPE_HOLDING && addr == SETPOINT_HR && value > SETPOINT_MAX)
        return DT_MB_EX_ILLEGAL_VALUE;
    return 0;
}

/* ============================================================================
 * 函式: onMbWrite()
 * 功能: Master 寫入後的回呼；在此驅動實體輸出 (例如 Coil0 控制繼電器)
 * ============================================================================ */
void onMbWrite(DT_MbType_t type, uint16_t addr, uint16_t count)
{
    for (uint16_t i = 0; i < count; i++) {
        Serial.print(type == DT_MB_TYPE_COIL ? "[MB] Coil" : "[MB] HR");
        Serial.print(addr + i);
        Serial.print(" = ");
        if (type == DT_MB_TYPE_COIL) Serial.println(DT_MbData_GetCoil(addr + i) ? "ON" : "OFF");
        else                         Serial.println(DT_MbData_GetHr(addr + i));
    }
}

/* ============================================================================
 * 函式: onCommLost()
 * 功能: 通訊中斷時將輸出設為安全狀態
 * ============================================================================ */
void onCommLost(bool lost)
{
    if (lost) {
        for (uint16_t i = 0; i < SAFE_COIL_COUNT; i++) DT_MbData_SetCoil(SAFE_COIL_START + i, false);
        Serial.println("[MB] Master 通訊中斷，輸出已設為安全狀態");
    } else {
        Serial.println("[MB] Master 通訊恢復");
    }
}

/* ============================================================================
 * 函式: updateData()
 * 功能: 每秒更新量測值與診斷資訊
 * ============================================================================ */
void updateData()
{
    uint32_t sec = millis() / 1000;
    DT_MbData_SetIr(0, (uint16_t)(sec & 0xFFFF));
    DT_MbData_SetIr(1, (uint16_t)(sec >> 16));
    DT_MbData_SetIr(2, (uint16_t)(250 + (sec % 20)));       // 模擬感測值 x10
    DT_MbData_SetIrFloat(3, 25.0f + (sec % 20) * 0.1f);     // float 版本
    DT_MbData_SetDi(0, DT_Net_IsReady());

    DT_MbStats_t s;
    DT_MbServer_GetStats(&s);
    DT_MbData_SetIr(DIAG_IR + 0, s.clients);
    DT_MbData_SetIr(DIAG_IR + 1, (uint16_t)s.requests);
    DT_MbData_SetIr(DIAG_IR + 2, (uint16_t)s.exceptions);
    DT_MbData_SetIr(DIAG_IR + 3, (uint16_t)s.frame_errors);
    DT_MbData_SetIr(DIAG_IR + 4, (uint16_t)(s.idle_drops + s.evictions));
}

void setup() {
  Serial.begin(115200);

  // 資料表與出廠預設值，再以 Flash 保存的設定覆蓋
  DT_MbData_Begin(mbCoils, NUM_COILS, mbDi, NUM_DI, mbHr, NUM_HR, mbIr, NUM_IR);
  DT_MbData_SetHr(SETPOINT_HR, SETPOINT_DEFAULT);
  DT_MbStore_Begin(STORE_HR_START, STORE_HR_COUNT);
  Serial.println(DT_MbStore_Load() == DT_OK ? "[STORE] 已載入保存的設定" : "[STORE] 使用出廠預設值");

  // 網路
  if (DT_W5500_Begin(NULL) != DT_OK) Serial.println("W5500 not found!");
  DT_Net_BeginStatic(mac, ip, sn, gw, NULL);

  // Modbus Server
  DT_MbData_SetValidateCb(onMbValidate);
  DT_MbData_SetWriteCb(onMbWrite);
  DT_MbServer_SetFailsafe(FAILSAFE_MS, onCommLost);
  DT_MbServer_Begin(DT_MB_TCP_PORT, MB_UNIT_ID);
  Serial.println("[MB] Modbus TCP Slave on port 502");
}

void loop() {
  DT_Net_Loop();        // 網路管理 (必要)
  DT_MbServer_Loop();   // Modbus Server (非阻塞)

  static uint32_t last = 0;
  if (millis() - last >= 1000) {
    last = millis();
    updateData();
  }

  if (DT_MbStore_Loop()) Serial.println("[STORE] 設定已寫入 Flash");
}
