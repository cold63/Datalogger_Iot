/**
 * @file DT_Http.cpp
 * @brief HTTP/1.1 client with chunked transfer decoding.
 */

#include <stdarg.h>
#include "DT_Internal.h"
#include "DT_Tcp.h"
#include "DT_Tls.h"
#include "DT_Http.h"

#define RD_TIMEOUT  -2
#define RD_CLOSED   -1

static const DT_TlsConfig_t* s_defTls = NULL;

/* ===== URL ===== */

typedef struct {
    bool        https;
    char        host[64];
    uint16_t    port;
    const char* path;       // points into url
} Url;

static int parse_url(const char* url, Url* u) {
    if (!url) return DT_ERR_URL;
    const char* p;
    if (strncmp(url, "http://", 7) == 0)       { u->https = false; u->port = 80;  p = url + 7; }
    else if (strncmp(url, "https://", 8) == 0) { u->https = true;  u->port = 443; p = url + 8; }
    else return DT_ERR_URL;

    const char* hend = p;
    while (*hend && *hend != ':' && *hend != '/' && *hend != '?') hend++;
    size_t hl = hend - p;
    if (hl == 0 || hl >= sizeof(u->host)) return DT_ERR_URL;
    memcpy(u->host, p, hl);
    u->host[hl] = '\0';

    p = hend;
    if (*p == ':') {
        uint32_t port = 0;
        p++;
        if (*p < '0' || *p > '9') return DT_ERR_URL;
        while (*p >= '0' && *p <= '9') {
            port = port * 10 + (*p++ - '0');
            if (port > 65535) return DT_ERR_URL;
        }
        if (port == 0) return DT_ERR_URL;
        u->port = (uint16_t)port;
    }
    u->path = (*p == '/' || *p == '?') ? p : "/";
    return DT_OK;
}

/* ===== Connection + buffered reader ===== */

typedef struct {
    bool     tls;
    int      h;
    uint32_t timeout;
    uint8_t  buf[256];
    uint16_t pos, len;
} Conn;

static int conn_send(Conn* c, const uint8_t* data, uint16_t len) {
    return c->tls ? DT_Tls_Send(c->h, data, len) : DT_Tcp_Send(c->h, data, len);
}

static void conn_close(Conn* c) {
    if (c->h < 0) return;
    if (c->tls) DT_Tls_Close(c->h); else DT_Tcp_Close(c->h);
    c->h = -1;
}

// Refill the read buffer; returns > 0, RD_CLOSED or RD_TIMEOUT
static int conn_fill(Conn* c) {
    uint32_t start = millis();
    while (true) {
        int r = c->tls ? DT_Tls_Recv(c->h, c->buf, sizeof(c->buf))
                       : DT_Tcp_Recv(c->h, c->buf, sizeof(c->buf));
        if (r > 0) { c->pos = 0; c->len = (uint16_t)r; return r; }
        if (r < 0) return RD_CLOSED;
        if (DT_Elapsed(start) >= c->timeout) return RD_TIMEOUT;
        delay(1);
    }
}

static int conn_getc(Conn* c) {
    if (c->pos >= c->len) {
        int r = conn_fill(c);
        if (r < 0) return r;
    }
    return c->buf[c->pos++];
}

// Read one line without CR/LF; long lines are truncated. Returns length or RD_*.
static int read_line(Conn* c, char* line, int size) {
    int n = 0;
    while (true) {
        int ch = conn_getc(c);
        if (ch < 0) return (ch == RD_CLOSED && n > 0) ? n : ch;
        if (ch == '\n') break;
        if (ch == '\r') continue;
        if (n < size - 1) line[n++] = (char)ch;
    }
    line[n] = '\0';
    return n;
}

/* ===== Body sink ===== */

typedef struct {
    const DT_HttpReq_t* req;
    DT_HttpResp_t*      resp;
    uint16_t            used;
} Sink;

static void sink_put(Sink* s, const uint8_t* data, uint16_t len) {
    s->resp->body_len += len;
    if (s->req->body_cb) s->req->body_cb(data, len);
    if (s->req->resp_buf && s->req->resp_buf_size > 1) {
        uint16_t room = s->req->resp_buf_size - 1 - s->used;
        uint16_t n = (len < room) ? len : room;
        memcpy(s->req->resp_buf + s->used, data, n);
        s->used += n;
        s->req->resp_buf[s->used] = '\0';
        if (n < len) s->resp->truncated = true;
    }
}

// Copy up to 'remain' bytes from the connection to the sink (remain = 0xFFFFFFFF: until close)
static int pump(Conn* c, Sink* s, uint32_t remain) {
    while (remain > 0) {
        if (c->pos >= c->len) {
            int r = conn_fill(c);
            if (r == RD_CLOSED) return (remain == 0xFFFFFFFF) ? DT_OK : DT_ERR_CLOSED;
            if (r == RD_TIMEOUT) return DT_ERR_TIMEOUT;
        }
        uint16_t n = c->len - c->pos;
        if (remain != 0xFFFFFFFF && n > remain) n = (uint16_t)remain;
        sink_put(s, c->buf + c->pos, n);
        c->pos += n;
        if (remain != 0xFFFFFFFF) remain -= n;
    }
    return DT_OK;
}

static bool header_is(const char* line, const char* name, const char** value) {
    size_t nl = strlen(name);
    for (size_t i = 0; i < nl; i++) {   // header names are case-insensitive
        if (tolower((unsigned char)line[i]) != tolower((unsigned char)name[i])) return false;
    }
    if (line[nl] != ':') return false;
    const char* v = line + nl + 1;
    while (*v == ' ' || *v == '\t') v++;
    *value = v;
    return true;
}

static int read_response(Conn* c, const DT_HttpReq_t* req, DT_HttpResp_t* resp) {
    char line[DT_HTTP_LINE_MAX];
    Sink sink = { req, resp, 0 };
    if (req->resp_buf && req->resp_buf_size) req->resp_buf[0] = '\0';

    // Status line, skipping 1xx interim responses
    do {
        int n = read_line(c, line, sizeof(line));
        if (n == RD_TIMEOUT) return DT_ERR_TIMEOUT;
        if (n < 0) return DT_ERR_CLOSED;
        if (strncmp(line, "HTTP/1.", 7) != 0 || strlen(line) < 12) return DT_ERR_HTTP;
        resp->status = atoi(line + 9);
        if (resp->status >= 100 && resp->status < 200) {
            while ((n = read_line(c, line, sizeof(line))) > 0) {}   // drop interim headers
            if (n < 0) return DT_ERR_HTTP;
        }
    } while (resp->status >= 100 && resp->status < 200);

    // Headers
    while (true) {
        int n = read_line(c, line, sizeof(line));
        if (n < 0) return (n == RD_TIMEOUT) ? DT_ERR_TIMEOUT : DT_ERR_HTTP;
        if (n == 0) break;
        const char* v;
        if (header_is(line, "Content-Length", &v)) resp->content_length = strtoul(v, NULL, 10);
        else if (header_is(line, "Transfer-Encoding", &v) && strstr(v, "chunked")) resp->chunked = true;
    }

    bool no_body = (strcmp(req->method, "HEAD") == 0) || resp->status == 204 || resp->status == 304;
    if (no_body) return resp->status;

    int r;
    if (resp->chunked) {
        while (true) {
            int n = read_line(c, line, sizeof(line));
            if (n < 0) return (n == RD_TIMEOUT) ? DT_ERR_TIMEOUT : DT_ERR_HTTP;
            if (n == 0) continue;                         // CRLF after previous chunk
            uint32_t size = strtoul(line, NULL, 16);      // ignores ";ext"
            if (size == 0) {
                while ((n = read_line(c, line, sizeof(line))) > 0) {}   // trailers
                break;
            }
            if ((r = pump(c, &sink, size)) != DT_OK) return r;
        }
    } else if (resp->content_length != 0xFFFFFFFF) {
        if ((r = pump(c, &sink, resp->content_length)) != DT_OK) return r;
    } else {
        if ((r = pump(c, &sink, 0xFFFFFFFF)) != DT_OK) return r;
    }
    return resp->status;
}

/* ===== Public API ===== */

// Append formatted text to a DT_HTTP_REQ_BUF sized buffer; false if it does not fit
static bool hdr_append(char* hdr, int* n, const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int w = vsnprintf(hdr + *n, DT_HTTP_REQ_BUF - *n, fmt, ap);
    va_end(ap);
    if (w < 0 || *n + w >= DT_HTTP_REQ_BUF) return false;
    *n += w;
    return true;
}

void DT_Http_ReqDefault(DT_HttpReq_t* req) {
    if (!req) return;
    memset(req, 0, sizeof(*req));
    req->method = "GET";
}

void DT_Http_SetDefaultTls(const DT_TlsConfig_t* cfg) { s_defTls = cfg; }

int DT_Http_Request(const DT_HttpReq_t* req, DT_HttpResp_t* resp) {
    if (!req || !req->method) return DT_ERR_PARAM;
    DT_HttpResp_t dummy;
    if (!resp) resp = &dummy;
    memset(resp, 0, sizeof(*resp));
    resp->content_length = 0xFFFFFFFF;

    Url u;
    int r = parse_url(req->url, &u);
    if (r != DT_OK) return r;

    // Build request header
    char hdr[DT_HTTP_REQ_BUF];
    int n = 0;
    bool def_port = (u.https && u.port == 443) || (!u.https && u.port == 80);
    if (!hdr_append(hdr, &n, "%s %s HTTP/1.1\r\n", req->method, u.path)) return DT_ERR_PARAM;
    if (def_port) {
        if (!hdr_append(hdr, &n, "Host: %s\r\n", u.host)) return DT_ERR_PARAM;
    } else {
        if (!hdr_append(hdr, &n, "Host: %s:%u\r\n", u.host, u.port)) return DT_ERR_PARAM;
    }
    if (!hdr_append(hdr, &n, "User-Agent: DT_W5500\r\nConnection: close\r\n")) return DT_ERR_PARAM;
    if (req->body && req->body_len) {
        if (!hdr_append(hdr, &n, "Content-Type: %s\r\nContent-Length: %u\r\n",
                        req->content_type ? req->content_type : "application/octet-stream",
                        req->body_len)) return DT_ERR_PARAM;
    }
    if (req->headers && !hdr_append(hdr, &n, "%s", req->headers)) return DT_ERR_PARAM;
    if (!hdr_append(hdr, &n, "\r\n")) return DT_ERR_PARAM;   // too long: increase DT_HTTP_REQ_BUF

    // Connect
    Conn c;
    c.tls = u.https;
    c.timeout = req->timeout_ms ? req->timeout_ms : DT_HTTP_TIMEOUT_MS;
    c.pos = c.len = 0;
    c.h = u.https ? DT_Tls_Connect(u.host, u.port, req->tls ? req->tls : s_defTls)
                  : DT_Tcp_Connect(u.host, u.port);
    if (c.h < 0) return c.h;

    // Send
    r = conn_send(&c, (const uint8_t*)hdr, (uint16_t)n);
    if (r >= 0 && req->body && req->body_len) r = conn_send(&c, req->body, req->body_len);
    if (r < 0) { conn_close(&c); return r; }

    r = read_response(&c, req, resp);
    conn_close(&c);
    return r;
}

int DT_Http_Get(const char* url, char* buf, uint16_t buf_size, DT_HttpResp_t* resp) {
    DT_HttpReq_t req;
    DT_Http_ReqDefault(&req);
    req.url = url;
    req.resp_buf = buf;
    req.resp_buf_size = buf_size;
    return DT_Http_Request(&req, resp);
}

int DT_Http_Post(const char* url, const char* content_type, const uint8_t* body, uint16_t body_len,
                 char* buf, uint16_t buf_size, DT_HttpResp_t* resp) {
    DT_HttpReq_t req;
    DT_Http_ReqDefault(&req);
    req.method = "POST";
    req.url = url;
    req.content_type = content_type;
    req.body = body;
    req.body_len = body_len;
    req.resp_buf = buf;
    req.resp_buf_size = buf_size;
    return DT_Http_Request(&req, resp);
}
