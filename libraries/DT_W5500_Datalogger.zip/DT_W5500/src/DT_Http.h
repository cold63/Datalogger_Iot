/**
 * @file DT_Http.h
 * @brief Blocking HTTP/1.1 client for http:// and https:// URLs.
 *
 * 支援 Content-Length、chunked 與「讀到連線關閉」三種回應格式。
 * 回應內容可寫入緩衝區 (自動 NUL 結尾) 或透過 body_cb 串流處理大型資料。
 */

#ifndef _DT_HTTP_H_
#define _DT_HTTP_H_

#include "DT_Types.h"
#include "DT_Tls.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int      status;            // HTTP status code, e.g. 200
    uint32_t content_length;    // from header, 0xFFFFFFFF if absent
    uint32_t body_len;          // total body bytes received
    bool     chunked;
    bool     truncated;         // body did not fit in resp_buf
} DT_HttpResp_t;

typedef void (*DT_HttpBodyCb_t)(const uint8_t* data, uint16_t len);

typedef struct {
    const char*     method;         // "GET", "POST", "PUT", "DELETE", "HEAD"
    const char*     url;            // http://host[:port][/path] or https://...
    const char*     headers;        // extra lines, each ending with "\r\n" (optional)
    const char*     content_type;   // for body, default "application/octet-stream"
    const uint8_t*  body;
    uint16_t        body_len;
    char*           resp_buf;       // receives body, NUL-terminated (optional)
    uint16_t        resp_buf_size;
    DT_HttpBodyCb_t body_cb;        // streaming body callback (optional)
    const DT_TlsConfig_t* tls;      // for https, NULL = DT_Http_SetDefaultTls() value
    uint32_t        timeout_ms;     // idle timeout, 0 = DT_HTTP_TIMEOUT_MS
} DT_HttpReq_t;

void DT_Http_ReqDefault(DT_HttpReq_t* req);

/** @return HTTP status code (> 0) or DT_Err_t */
int  DT_Http_Request(const DT_HttpReq_t* req, DT_HttpResp_t* resp);

/** @brief GET into buf. resp may be NULL. @return status code or DT_Err_t */
int  DT_Http_Get(const char* url, char* buf, uint16_t buf_size, DT_HttpResp_t* resp);

/** @brief POST body into buf. @return status code or DT_Err_t */
int  DT_Http_Post(const char* url, const char* content_type, const uint8_t* body, uint16_t body_len,
                  char* buf, uint16_t buf_size, DT_HttpResp_t* resp);

/** @brief TLS settings used for https:// when the request does not give one. */
void DT_Http_SetDefaultTls(const DT_TlsConfig_t* cfg);

#ifdef __cplusplus
}
#endif

#endif /* _DT_HTTP_H_ */
