/**
 * @file DT_MbSelfTest.h
 * @brief DT_MbPdu 板上自我測試 (不需網路與外部裝置)。
 *
 * 測試期間使用內部測試資料表，結束後還原 sketch 的資料表、寫入回呼與檢查回呼，
 * 可在 setup() 任何位置呼叫。FC43 測試以 DT_Config.h 的預設裝置識別字串為準，
 * 若先呼叫了 DT_MbPdu_SetDeviceId() 修改 ProductCode，該項會失敗。
 */

#ifndef _DT_MB_SELFTEST_H_
#define _DT_MB_SELFTEST_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @brief 輸出一行文字 (由 sketch 提供，例如呼叫 Serial.println) */
typedef void (*DT_MbLogFn_t)(const char* line);

/** @brief 執行全部測試案例，回傳失敗數 (0 = 全部通過) */
int DT_MbSelfTest_Run(DT_MbLogFn_t log);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MB_SELFTEST_H_ */
