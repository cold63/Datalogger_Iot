/**
 * @file DT_Tls.cpp
 * @brief MbedTLS <-> W5500 socket bridge.
 */

#include "DT_Internal.h"
#include "DT_Core.h"
#include "DT_Tcp.h"
#include "DT_Tls.h"

#include "mbedtls/ssl.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/x509_crt.h"
#include "mbedtls/pk.h"
#include "mbedtls/error.h"

// Random source from AmebaD SDK (lib_arduino.a), mbedtls f_rng compatible
extern "C" int rtw_get_random_bytes_f_rng(void* p_rng, unsigned char* output, size_t output_size);

typedef struct {
    int                 sock;
    bool                hasCa;
    bool                hasCli;
    mbedtls_ssl_context ssl;
    mbedtls_ssl_config  conf;
    mbedtls_x509_crt    ca;
    mbedtls_x509_crt    cli;
    mbedtls_pk_context  key;
} TlsSession;

static TlsSession* s_sess[DT_TLS_MAX_SESSIONS];
static int         s_lastErr = 0;

static TlsSession* get(int h) {
    if (h < 0 || h >= DT_TLS_MAX_SESSIONS) return NULL;
    return s_sess[h];
}

/* ===== BIO callbacks ===== */

static int bio_send(void* ctx, const unsigned char* buf, size_t len) {
    TlsSession* s = (TlsSession*)ctx;
    if (len > 0xFFFF) len = 0xFFFF;
    int32_t r = send((uint8_t)s->sock, (uint8_t*)buf, (uint16_t)len);
    if (r < 0) return MBEDTLS_ERR_NET_SEND_FAILED;
    if (r == 0) return MBEDTLS_ERR_SSL_WANT_WRITE;
    return (int)r;
}

static int bio_recv(void* ctx, unsigned char* buf, size_t len) {
    TlsSession* s = (TlsSession*)ctx;
    uint8_t sn = (uint8_t)s->sock;
    uint16_t avail = getSn_RX_RSR(sn);
    if (avail == 0) {
        return (getSn_SR(sn) == SOCK_ESTABLISHED) ? MBEDTLS_ERR_SSL_WANT_READ
                                                  : MBEDTLS_ERR_NET_CONN_RESET;
    }
    if (len > avail) len = avail;
    int32_t r = recv(sn, buf, (uint16_t)len);
    if (r < 0) return MBEDTLS_ERR_NET_RECV_FAILED;
    return (int)r;
}

/* ===== Session lifecycle ===== */

static void free_session(int h) {
    TlsSession* s = s_sess[h];
    if (!s) return;
    mbedtls_ssl_free(&s->ssl);
    mbedtls_ssl_config_free(&s->conf);
    mbedtls_x509_crt_free(&s->ca);
    mbedtls_x509_crt_free(&s->cli);
    mbedtls_pk_free(&s->key);
    if (s->sock >= 0) DT_Tcp_Close(s->sock);
    free(s);
    s_sess[h] = NULL;
}

void DT_Tls_ConfigDefault(DT_TlsConfig_t* cfg) {
    if (!cfg) return;
    memset(cfg, 0, sizeof(*cfg));
}

int DT_Tls_Connect(const char* host, uint16_t port, const DT_TlsConfig_t* cfg) {
    if (!host || port == 0) return DT_ERR_PARAM;
    DT_TlsConfig_t defcfg;
    if (!cfg) { DT_Tls_ConfigDefault(&defcfg); cfg = &defcfg; }

    int h = -1;
    for (int i = 0; i < DT_TLS_MAX_SESSIONS; i++) {
        if (!s_sess[i]) { h = i; break; }
    }
    if (h < 0) return DT_ERR_NO_SOCKET;

    TlsSession* s = (TlsSession*)calloc(1, sizeof(TlsSession));
    if (!s) return DT_ERR_NO_MEM;
    s->sock = -1;
    s_sess[h] = s;
    mbedtls_ssl_init(&s->ssl);
    mbedtls_ssl_config_init(&s->conf);
    mbedtls_x509_crt_init(&s->ca);
    mbedtls_x509_crt_init(&s->cli);
    mbedtls_pk_init(&s->key);

    int ret;
    s_lastErr = 0;

    if ((ret = mbedtls_ssl_config_defaults(&s->conf, MBEDTLS_SSL_IS_CLIENT,
                                           MBEDTLS_SSL_TRANSPORT_STREAM,
                                           MBEDTLS_SSL_PRESET_DEFAULT)) != 0) goto tls_fail;
    mbedtls_ssl_conf_rng(&s->conf, rtw_get_random_bytes_f_rng, NULL);

    if (cfg->ca_cert) {
        if ((ret = mbedtls_x509_crt_parse(&s->ca, (const unsigned char*)cfg->ca_cert,
                                          strlen(cfg->ca_cert) + 1)) != 0) goto tls_fail;
        s->hasCa = true;
        mbedtls_ssl_conf_ca_chain(&s->conf, &s->ca, NULL);
        mbedtls_ssl_conf_authmode(&s->conf, MBEDTLS_SSL_VERIFY_REQUIRED);
    } else {
        mbedtls_ssl_conf_authmode(&s->conf, MBEDTLS_SSL_VERIFY_NONE);
    }

    if (cfg->client_cert && cfg->client_key) {
        if ((ret = mbedtls_x509_crt_parse(&s->cli, (const unsigned char*)cfg->client_cert,
                                          strlen(cfg->client_cert) + 1)) != 0) goto tls_fail;
        if ((ret = mbedtls_pk_parse_key(&s->key, (const unsigned char*)cfg->client_key,
                                        strlen(cfg->client_key) + 1, NULL, 0)) != 0) goto tls_fail;
        if ((ret = mbedtls_ssl_conf_own_cert(&s->conf, &s->cli, &s->key)) != 0) goto tls_fail;
        s->hasCli = true;
    }

    if ((ret = mbedtls_ssl_setup(&s->ssl, &s->conf)) != 0) goto tls_fail;
    if ((ret = mbedtls_ssl_set_hostname(&s->ssl, cfg->sni_host ? cfg->sni_host : host)) != 0) goto tls_fail;

    {
        int sock = DT_Tcp_Connect(host, port);
        if (sock < 0) {
            free_session(h);
            return sock;
        }
        s->sock = sock;
    }
    mbedtls_ssl_set_bio(&s->ssl, s, bio_send, bio_recv, NULL);

    {
        uint32_t timeout = cfg->handshake_timeout_ms ? cfg->handshake_timeout_ms
                                                     : DT_TLS_HANDSHAKE_TIMEOUT_MS;
        uint32_t start = millis();
        while ((ret = mbedtls_ssl_handshake(&s->ssl)) != 0) {
            if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE) goto tls_fail;
            if (DT_Elapsed(start) >= timeout) {
                free_session(h);
                return DT_ERR_TIMEOUT;
            }
            delay(1);
        }
    }
    return h;

tls_fail:
    s_lastErr = ret;
    free_session(h);
    return DT_ERR_TLS;
}

int DT_Tls_Send(int h, const uint8_t* data, uint16_t len) {
    TlsSession* s = get(h);
    if (!s || (!data && len)) return DT_ERR_PARAM;
    uint16_t sent = 0;
    uint32_t start = millis();
    while (sent < len) {
        int r = mbedtls_ssl_write(&s->ssl, data + sent, len - sent);
        if (r > 0) { sent += r; continue; }
        if (r != MBEDTLS_ERR_SSL_WANT_WRITE && r != MBEDTLS_ERR_SSL_WANT_READ) {
            s_lastErr = r;
            return DT_ERR_CLOSED;
        }
        if (DT_Elapsed(start) >= DT_TCP_CONNECT_TIMEOUT_MS) return DT_ERR_TIMEOUT;
        delay(1);
    }
    return len;
}

int DT_Tls_SendStr(int h, const char* str) {
    if (!str) return DT_ERR_PARAM;
    return DT_Tls_Send(h, (const uint8_t*)str, (uint16_t)strlen(str));
}

int DT_Tls_Available(int h) {
    TlsSession* s = get(h);
    if (!s) return 0;
    int n = (int)mbedtls_ssl_get_bytes_avail(&s->ssl);
    if (n > 0) return n;
    return getSn_RX_RSR((uint8_t)s->sock);
}

int DT_Tls_Recv(int h, uint8_t* buf, uint16_t len) {
    TlsSession* s = get(h);
    if (!s || !buf) return DT_ERR_PARAM;
    int r = mbedtls_ssl_read(&s->ssl, buf, len);
    if (r > 0) return r;
    if (r == MBEDTLS_ERR_SSL_WANT_READ || r == MBEDTLS_ERR_SSL_WANT_WRITE) return 0;
    if (r == 0 || r == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || r == MBEDTLS_ERR_NET_CONN_RESET) {
        return DT_ERR_CLOSED;
    }
    s_lastErr = r;
    return DT_ERR_TLS;
}

int DT_Tls_RecvTimeout(int h, uint8_t* buf, uint16_t len, uint32_t timeout_ms) {
    uint16_t got = 0;
    uint32_t start = millis();
    while (got < len) {
        int r = DT_Tls_Recv(h, buf + got, len - got);
        if (r < 0) return got ? got : r;
        if (r > 0) { got += r; continue; }
        if (DT_Elapsed(start) >= timeout_ms) break;
        delay(1);
    }
    return got;
}

bool DT_Tls_IsConnected(int h) {
    TlsSession* s = get(h);
    if (!s) return false;
    if (mbedtls_ssl_get_bytes_avail(&s->ssl) > 0) return true;
    return DT_Tcp_IsConnected(s->sock);
}

void DT_Tls_Close(int h) {
    TlsSession* s = get(h);
    if (!s) return;
    if (s->sock >= 0 && getSn_SR((uint8_t)s->sock) == SOCK_ESTABLISHED) {
        mbedtls_ssl_close_notify(&s->ssl);
    }
    free_session(h);
}

int DT_Tls_LastError(void) { return s_lastErr; }

uint32_t DT_Tls_VerifyResult(int h) {
    TlsSession* s = get(h);
    if (!s) return 0xFFFFFFFF;
    return mbedtls_ssl_get_verify_result(&s->ssl);
}
