/**
 * @file DT_Config.h
 * @brief DT_W5500 compile-time configuration.
 *
 * Arduino IDE 無法替 Library 傳入 -D 參數，如需調整請直接修改此檔。
 */

#ifndef _DT_CONFIG_H_
#define _DT_CONFIG_H_

/* ===== Default pins (RTL8720DF PCB) ===== */
#ifndef DT_PIN_SCLK_DEFAULT
#define DT_PIN_SCLK_DEFAULT     19
#endif
#ifndef DT_PIN_MISO_DEFAULT
#define DT_PIN_MISO_DEFAULT     16
#endif
#ifndef DT_PIN_MOSI_DEFAULT
#define DT_PIN_MOSI_DEFAULT     17
#endif
#ifndef DT_PIN_CS_DEFAULT
#define DT_PIN_CS_DEFAULT       18
#endif
#ifndef DT_PIN_RST_DEFAULT
#define DT_PIN_RST_DEFAULT      10
#endif

/* ===== Bit-bang SPI timing ===== */
#ifndef DT_SPI_HALF_PERIOD_US
#define DT_SPI_HALF_PERIOD_US   1       // SCLK half period (us)
#endif
#ifndef DT_SPI_CS_SETUP_US
#define DT_SPI_CS_SETUP_US      5       // CS stabilize time (us)
#endif

/* ===== Socket allocation (W5500 has 8 hardware sockets) ===== */
#ifndef DT_SOCK_DHCP
#define DT_SOCK_DHCP            7       // reserved for DHCP
#endif
#ifndef DT_SOCK_DNS
#define DT_SOCK_DNS             6       // reserved for DNS
#endif
#define DT_SOCK_APP_MAX         6       // sockets 0..5 are allocated dynamically

/* ===== Network manager ===== */
#ifndef DT_NET_LINK_CHECK_MS
#define DT_NET_LINK_CHECK_MS    1000    // PHY link polling period
#endif
#ifndef DT_NET_RETRY_MS
#define DT_NET_RETRY_MS         10000   // wait time after DHCP failure
#endif

/* ===== DNS ===== */
#ifndef DT_DNS_TIMEOUT_MS
#define DT_DNS_TIMEOUT_MS       3000
#endif
#ifndef DT_DNS_RETRY
#define DT_DNS_RETRY            2
#endif

/* ===== TCP ===== */
#ifndef DT_TCP_CONNECT_TIMEOUT_MS
#define DT_TCP_CONNECT_TIMEOUT_MS 10000
#endif

/* ===== TLS ===== */
#ifndef DT_TLS_MAX_SESSIONS
#define DT_TLS_MAX_SESSIONS     2
#endif
#ifndef DT_TLS_HANDSHAKE_TIMEOUT_MS
#define DT_TLS_HANDSHAKE_TIMEOUT_MS 60000   // bit-bang SPI handshake is slow
#endif

/* ===== MQTT ===== */
#ifndef DT_MQTT_BUF_SIZE
#define DT_MQTT_BUF_SIZE        512     // send / receive buffer each
#endif
#ifndef DT_MQTT_MAX_SUBS
#define DT_MQTT_MAX_SUBS        5
#endif
#ifndef DT_MQTT_TOPIC_MAX
#define DT_MQTT_TOPIC_MAX       64
#endif
#ifndef DT_MQTT_CMD_TIMEOUT_MS
#define DT_MQTT_CMD_TIMEOUT_MS  10000
#endif
#ifndef DT_MQTT_RECONNECT_MS
#define DT_MQTT_RECONNECT_MS    5000
#endif

/* ===== HTTP ===== */
#ifndef DT_HTTP_TIMEOUT_MS
#define DT_HTTP_TIMEOUT_MS      15000
#endif
#ifndef DT_HTTP_LINE_MAX
#define DT_HTTP_LINE_MAX        256     // max header line length kept
#endif
#ifndef DT_HTTP_REQ_BUF
#define DT_HTTP_REQ_BUF         512     // request header buffer
#endif

/* ===== Modbus TCP ===== */
#ifndef DT_MB_SERVER_MAX_CONN
#define DT_MB_SERVER_MAX_CONN   2       // concurrent Master connections (1 socket each)
#endif
#ifndef DT_MB_SERVER_SPARE
#define DT_MB_SERVER_SPARE      1       // spare listen socket: accept when full, evict the idlest (0 = refuse)
#endif
#ifndef DT_MB_SERVER_IDLE_MS
#define DT_MB_SERVER_IDLE_MS    60000   // drop idle client (0 = never)
#endif
#ifndef DT_MB_KEEPALIVE_S
#define DT_MB_KEEPALIVE_S       10      // TCP keepalive interval, multiple of 5 (0 = off)
#endif
#ifndef DT_MB_REPLY_BAD_UID
#define DT_MB_REPLY_BAD_UID     0       // 1 = reply EX0B on unit id mismatch, 0 = ignore
#endif
#ifndef DT_MB_CLIENT_CONNECT_MS
#define DT_MB_CLIENT_CONNECT_MS 3000    // non-blocking connect timeout
#endif
#ifndef DT_MB_CLIENT_TIMEOUT_MS
#define DT_MB_CLIENT_TIMEOUT_MS 1000    // response timeout
#endif
#ifndef DT_MB_CLIENT_RETRY_MS
#define DT_MB_CLIENT_RETRY_MS   5000    // wait after a failed connect
#endif
#ifndef DT_MB_POLL_MAX_TASKS
#define DT_MB_POLL_MAX_TASKS    8
#endif
#ifndef DT_MB_POLL_OFFLINE_FAILS
#define DT_MB_POLL_OFFLINE_FAILS 3      // consecutive failures before a task is offline
#endif
#ifndef DT_MB_STORE_DELAY_MS
#define DT_MB_STORE_DELAY_MS    3000    // value must be stable this long before it is saved
#endif

/* Device identification (FC43 / MEI 14), changeable at run time with DT_MbPdu_SetDeviceId() */
#ifndef DT_MB_DEVID_VENDOR
#define DT_MB_DEVID_VENDOR          "makdev.net"
#endif
#ifndef DT_MB_DEVID_PRODUCT_CODE
#define DT_MB_DEVID_PRODUCT_CODE    "DT-W5500-MBTCP"
#endif
#ifndef DT_MB_DEVID_REVISION
#define DT_MB_DEVID_REVISION        "1.1.0"
#endif
#ifndef DT_MB_DEVID_VENDOR_URL
#define DT_MB_DEVID_VENDOR_URL      "https://www.makdev.net"
#endif
#ifndef DT_MB_DEVID_PRODUCT_NAME
#define DT_MB_DEVID_PRODUCT_NAME    "Datalogger IoT Modbus TCP"
#endif
#ifndef DT_MB_DEVID_MODEL_NAME
#define DT_MB_DEVID_MODEL_NAME      "RTL8720DF + W5500"
#endif

#endif /* _DT_CONFIG_H_ */
