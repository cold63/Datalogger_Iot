/**
 * @file DT_MbCommon.h
 * @brief Modbus TCP 共用定義：功能碼、例外碼、MBAP 編解碼、32 位元 / float 轉換。
 *
 * 錯誤碼沿用 DT_Err_t；例外回應編為 DT_ERR_MB_EXCEPTION - 例外碼，
 * 可用 DT_Mb_ExceptionCode() 取出例外碼、DT_ErrName() 轉成文字。
 */

#ifndef _DT_MB_COMMON_H_
#define _DT_MB_COMMON_H_

#include "DT_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ===== 功能碼 ===== */
#define DT_MB_FC_READ_COILS             0x01
#define DT_MB_FC_READ_DISCRETE          0x02
#define DT_MB_FC_READ_HOLDING           0x03
#define DT_MB_FC_READ_INPUT             0x04
#define DT_MB_FC_WRITE_COIL             0x05
#define DT_MB_FC_WRITE_REGISTER         0x06
#define DT_MB_FC_WRITE_COILS            0x0F
#define DT_MB_FC_WRITE_REGISTERS        0x10
#define DT_MB_FC_MASK_WRITE_REGISTER    0x16
#define DT_MB_FC_READ_WRITE_REGISTERS   0x17
#define DT_MB_FC_DEVICE_ID              0x2B    // MEI type 0x0E: Read Device Identification
#define DT_MB_MEI_DEVICE_ID             0x0E

/* ===== 例外碼 ===== */
#define DT_MB_EX_ILLEGAL_FUNCTION       0x01
#define DT_MB_EX_ILLEGAL_ADDRESS        0x02
#define DT_MB_EX_ILLEGAL_VALUE          0x03
#define DT_MB_EX_DEVICE_FAILURE         0x04
#define DT_MB_EX_GATEWAY_NO_RESPONSE    0x0B

/* ===== 數量上限 (規範) ===== */
#define DT_MB_MAX_READ_BITS             2000
#define DT_MB_MAX_READ_REGS             125
#define DT_MB_MAX_WRITE_BITS            1968
#define DT_MB_MAX_WRITE_REGS            123
#define DT_MB_MAX_RW_WRITE_REGS         121     // FC23 寫入部分

#define DT_MB_TCP_PORT                  502
#define DT_MB_MBAP_LEN                  7       // TID(2) PID(2) LEN(2) UID(1)
#define DT_MB_PDU_MAX                   253
#define DT_MB_ADU_MAX                   (DT_MB_MBAP_LEN + DT_MB_PDU_MAX)

/** @brief MBAP 表頭 */
typedef struct {
    uint16_t tid;       // Transaction ID
    uint16_t pid;       // Protocol ID (必須為 0)
    uint16_t len;       // 後續長度 (UID + PDU)
    uint8_t  uid;       // Unit ID
} DT_MbMbap_t;

/**
 * @brief 32 位元值在兩個暫存器中的排列 (A = 最高位元組)
 *   ABCD: r[0]=AB r[1]=CD (big-endian，最常見)   CDAB: r[0]=CD r[1]=AB (word swap)
 *   BADC: r[0]=BA r[1]=DC (byte swap)             DCBA: r[0]=DC r[1]=BA (little-endian)
 */
typedef enum {
    DT_MB_ORDER_ABCD = 0,
    DT_MB_ORDER_CDAB,
    DT_MB_ORDER_BADC,
    DT_MB_ORDER_DCBA
} DT_MbOrder_t;

uint16_t DT_Mb_GetU16(const uint8_t* p);            // big-endian
void     DT_Mb_PutU16(uint8_t* p, uint16_t v);

/** @brief 解析 MBAP 表頭，true = 合法 (PID==0 且 2 <= LEN <= 254) */
bool DT_Mb_MbapParse(const uint8_t* buf, uint16_t len, DT_MbMbap_t* hdr);

/** @brief 寫入 MBAP 表頭 (7 bytes)，LEN = pdu_len + 1 */
void DT_Mb_MbapBuild(uint8_t* buf, uint16_t tid, uint8_t uid, uint16_t pdu_len);

uint32_t DT_Mb_RegsToU32(const uint16_t r[2], DT_MbOrder_t order);
void     DT_Mb_U32ToRegs(uint32_t v, uint16_t r[2], DT_MbOrder_t order);
float    DT_Mb_RegsToFloat(const uint16_t r[2], DT_MbOrder_t order);
void     DT_Mb_FloatToRegs(float v, uint16_t r[2], DT_MbOrder_t order);

/** @brief 由錯誤碼取出例外碼，非例外回應回傳 0 */
int DT_Mb_ExceptionCode(int err);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MB_COMMON_H_ */
