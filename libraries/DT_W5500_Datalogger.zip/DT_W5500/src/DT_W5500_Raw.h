/**
 * @file DT_W5500_Raw.h
 * @brief Optional access to the native WIZnet ioLibrary / Paho API.
 *
 * 進階用途：直接使用 socket()/send()/recv()/getSn_SR() 等原生 API。
 *  - 請先以 DT_W5500_Begin() 初始化晶片（SPI HAL 由 DT_W5500 提供）。
 *  - 自行使用的 socket 請以 DT_Socket_Alloc()/DT_Socket_Free() 取得與釋放，
 *    避免與 DT_ 模組衝突；socket 6 (DNS) 與 7 (DHCP) 保留給 Library。
 *  - socket.h 定義了 connect/sendto/recvfrom 巨集與 close/send/recv 全域函式，
 *    可能與 lwIP (WiFi) 衝突，請勿在同一檔案同時 include WiFi 相關標頭。
 *  - ioLibrary DNS_run() 需要外部 1 秒計時 (DNS_time_handler)，否則可能卡住；
 *    建議改用 DT_Dns_Resolve()。
 */

#ifndef _DT_W5500_RAW_H_
#define _DT_W5500_RAW_H_

#include "DT_W5500.h"

#ifdef __cplusplus
extern "C" {
#endif
#include "utility/ioLibrary/Ethernet/wizchip_conf.h"
#include "utility/ioLibrary/Ethernet/socket.h"
#include "utility/ioLibrary/Internet/DHCP/dhcp.h"
#include "utility/ioLibrary/Internet/DNS/dns.h"
#include "utility/ioLibrary/Internet/MQTT/MQTTClient.h"
#ifdef __cplusplus
}
#endif

#endif /* _DT_W5500_RAW_H_ */
