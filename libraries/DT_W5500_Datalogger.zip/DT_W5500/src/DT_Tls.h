/**
 * @file DT_Tls.h
 * @brief TLS client sessions (AmebaD built-in MbedTLS over W5500 TCP sockets).
 *
 * 注意：
 *  - ca_cert 為 NULL 時不驗證伺服器憑證（僅加密，無法防中間人攻擊）。
 *  - 啟用憑證驗證時，系統時間需正確，否則憑證有效期檢查可能失敗。
 *  - Bit-bang SPI 下 TLS 握手約需 10~30 秒。
 */

#ifndef _DT_TLS_H_
#define _DT_TLS_H_

#include "DT_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    const char* ca_cert;            // PEM root CA, NULL = skip server verification
    const char* client_cert;        // PEM client certificate (mutual TLS), optional
    const char* client_key;         // PEM client private key, optional
    const char* sni_host;           // SNI / verify name, NULL = use host argument
    uint32_t    handshake_timeout_ms; // 0 = DT_TLS_HANDSHAKE_TIMEOUT_MS
} DT_TlsConfig_t;

/** @brief Fill cfg with defaults (no verification). */
void DT_Tls_ConfigDefault(DT_TlsConfig_t* cfg);

/**
 * @brief TCP connect + TLS handshake (blocking).
 * @param cfg NULL = defaults
 * @return session handle (>= 0) or DT_Err_t
 */
int  DT_Tls_Connect(const char* host, uint16_t port, const DT_TlsConfig_t* cfg);

/** @brief Write all bytes. @return len or DT_Err_t */
int  DT_Tls_Send(int h, const uint8_t* data, uint16_t len);
int  DT_Tls_SendStr(int h, const char* str);

/** @brief Non-zero when DT_Tls_Recv() may return data (decrypted or raw bytes pending). */
int  DT_Tls_Available(int h);

/** @brief Non-blocking read. @return bytes (0 if none) or DT_Err_t (DT_ERR_CLOSED on close) */
int  DT_Tls_Recv(int h, uint8_t* buf, uint16_t len);

/** @brief Read until len bytes or timeout. */
int  DT_Tls_RecvTimeout(int h, uint8_t* buf, uint16_t len, uint32_t timeout_ms);

bool DT_Tls_IsConnected(int h);

/** @brief Send close_notify, close socket and free all TLS memory. */
void DT_Tls_Close(int h);

/** @brief Last raw MbedTLS error code (negative), 0 if none. */
int  DT_Tls_LastError(void);

/** @brief Server certificate verification flags of the last handshake (0 = OK). */
uint32_t DT_Tls_VerifyResult(int h);

#ifdef __cplusplus
}
#endif

#endif /* _DT_TLS_H_ */
