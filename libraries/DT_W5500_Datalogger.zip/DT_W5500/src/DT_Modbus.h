/**
 * @file DT_Modbus.h
 * @brief Modbus TCP 總標頭 (由 DT_W5500.h 引入)。
 *
 * Modules:
 *   DT_MbCommon   - 功能碼、例外碼、MBAP、32 位元 / float 轉換
 *   DT_MbData     - Server 資料表 (陣列由 sketch 提供)、寫入檢查 / 寫入回呼
 *   DT_MbPdu      - 請求處理 FC01/02/03/04/05/06/15/16/22/23/43
 *   DT_MbServer   - Modbus TCP Server (Slave)
 *   DT_MbClient   - Modbus TCP Client (Master)，非阻塞
 *   DT_MbPoll     - Client 輪詢表 (多台 Slave)
 *   DT_MbStore    - HR 斷電保存 (Preferences / DCT)
 *   DT_MbSelfTest - 板上自我測試
 */

#ifndef _DT_MODBUS_H_
#define _DT_MODBUS_H_

#include "DT_MbCommon.h"
#include "DT_MbData.h"
#include "DT_MbPdu.h"
#include "DT_MbServer.h"
#include "DT_MbClient.h"
#include "DT_MbPoll.h"
#include "DT_MbStore.h"
#include "DT_MbSelfTest.h"

#endif /* _DT_MODBUS_H_ */
