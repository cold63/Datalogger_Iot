/**
 * @file DT_MbPoll.cpp
 * @brief Client 輪詢表實作。
 */

#include <Arduino.h>
#include <string.h>
#include "DT_Config.h"
#include "DT_MbPoll.h"
#include "DT_MbData.h"

typedef struct {
    DT_MbPollTask_t   cfg;
    DT_MbPollStatus_t st;
    uint32_t         due_ms;        // 下次執行時間
} poll_entry_t;

/* 單筆寫入 */
typedef struct {
    bool     pending;
    uint8_t  ip[4];
    uint16_t port;
    uint8_t  unit_id;
    uint8_t  fc;                    // 05 / 06 / 16
    uint16_t addr;
    uint16_t qty;
    uint16_t vals[DT_MB_MAX_WRITE_REGS];
} poll_write_t;

static poll_entry_t s_tasks[DT_MB_POLL_MAX_TASKS];
static int          s_count   = 0;
static int          s_next    = 0;      // 輪流起點
static int          s_active  = -2;     // 進行中的項目 (-2 = 無，DT_MB_POLL_WRITE_TASK = 單筆寫入)
static poll_write_t s_write;
static DT_MbPollCb_t s_cb      = 0;
static bool         s_hooked  = false;

/* 時間比較 (可跨越 millis() 溢位) */
static bool time_reached(uint32_t now, uint32_t due) { return (int32_t)(now - due) >= 0; }

static bool connect_error(int r) { return r == DT_ERR_CONNECT || r == DT_ERR_NO_SOCKET; }

/* Client 完成回呼 */
static void on_client_done(const DT_MbClientResult_t* r)
{
    int task = s_active;
    s_active = -2;

    if (task >= 0 && task < s_count) {
        poll_entry_t* e   = &s_tasks[task];
        uint32_t      now = millis();
        e->st.last_result = r->result;
        if (r->result == DT_OK) {
            e->st.ok++;
            e->st.fails  = 0;
            e->st.online = true;
            for (uint16_t i = 0; i < r->qty; i++) {
                if (r->fc == DT_MB_FC_READ_HOLDING || r->fc == DT_MB_FC_READ_INPUT)
                    DT_MbData_SetIr(e->cfg.local_addr + i, r->regs[i]);
                else
                    DT_MbData_SetDi(e->cfg.local_addr + i, DT_MbClient_Bit(r, i));
            }
            e->due_ms = now + e->cfg.period_ms;
        } else {
            e->st.errors++;
            if (e->st.fails < 255) e->st.fails++;
            if (e->st.fails >= DT_MB_POLL_OFFLINE_FAILS) e->st.online = false;
            uint32_t wait = e->cfg.period_ms;
            if (connect_error(r->result) && wait < DT_MB_CLIENT_RETRY_MS) wait = DT_MB_CLIENT_RETRY_MS;
            e->due_ms = now + wait;
        }
    } else if (task == DT_MB_POLL_WRITE_TASK) {
        s_write.pending = false;
    }
    if (s_cb) s_cb(task, r);
}

static void hook_client(void)
{
    if (!s_hooked) {
        DT_MbClient_SetCallback(on_client_done);
        s_hooked = true;
    }
}

int DT_MbPoll_Add(const DT_MbPollTask_t* task)
{
    if (!task || s_count >= DT_MB_POLL_MAX_TASKS || task->port == 0 || task->period_ms == 0) return DT_ERR_PARAM;
    bool regs = task->fc == DT_MB_FC_READ_HOLDING || task->fc == DT_MB_FC_READ_INPUT;
    bool bits = task->fc == DT_MB_FC_READ_COILS || task->fc == DT_MB_FC_READ_DISCRETE;
    if (!regs && !bits) return DT_ERR_PARAM;
    if (!DT_MbData_InRange(regs ? DT_MB_TYPE_INPUT : DT_MB_TYPE_DISCRETE, task->local_addr, task->qty)) return DT_ERR_PARAM;
    if (task->qty > (regs ? DT_MB_MAX_READ_REGS : DT_MB_MAX_READ_BITS)) return DT_ERR_PARAM;

    poll_entry_t* e = &s_tasks[s_count];
    memset(e, 0, sizeof(*e));
    e->cfg    = *task;
    e->due_ms = millis() + (uint32_t)s_count * 200;   // 錯開各項目的第一次執行
    hook_client();
    return s_count++;
}

void DT_MbPoll_Clear(void)
{
    s_count = 0;
    s_next  = 0;
}

void DT_MbPoll_SetCallback(DT_MbPollCb_t cb) { s_cb = cb; }
int  DT_MbPoll_Count(void)                   { return s_count; }

bool DT_MbPoll_GetStatus(int task, DT_MbPollStatus_t* st)
{
    if (task < 0 || task >= s_count || !st) return false;
    *st = s_tasks[task].st;
    return true;
}

static int start_write(void)
{
    DT_MbClient_SetTarget(s_write.ip, s_write.port, s_write.unit_id);
    switch (s_write.fc) {
    case DT_MB_FC_WRITE_COIL:      return DT_MbClient_WriteCoil(s_write.addr, s_write.vals[0] != 0);
    case DT_MB_FC_WRITE_REGISTER:  return DT_MbClient_WriteRegister(s_write.addr, s_write.vals[0]);
    default:                    return DT_MbClient_WriteRegisters(s_write.addr, s_write.qty, s_write.vals);
    }
}

static int start_task(poll_entry_t* e)
{
    DT_MbClient_SetTarget(e->cfg.ip, e->cfg.port, e->cfg.unit_id);
    switch (e->cfg.fc) {
    case DT_MB_FC_READ_COILS:    return DT_MbClient_ReadCoils(e->cfg.addr, e->cfg.qty);
    case DT_MB_FC_READ_DISCRETE: return DT_MbClient_ReadDiscrete(e->cfg.addr, e->cfg.qty);
    case DT_MB_FC_READ_HOLDING:  return DT_MbClient_ReadHolding(e->cfg.addr, e->cfg.qty);
    default:                  return DT_MbClient_ReadInput(e->cfg.addr, e->cfg.qty);
    }
}

void DT_MbPoll_Loop(void)
{
    DT_MbClient_Loop();
    if (DT_MbClient_Busy() || s_active != -2) return;

    // 單筆寫入優先
    if (s_write.pending) {
        s_active = DT_MB_POLL_WRITE_TASK;
        if (start_write() != DT_OK) { s_active = -2; s_write.pending = false; }
        return;
    }

    // 找下一個到期的項目 (輪流，避免某一項一直佔用)
    uint32_t now = millis();
    for (int n = 0; n < s_count; n++) {
        int i = (s_next + n) % s_count;
        poll_entry_t* e = &s_tasks[i];
        if (!time_reached(now, e->due_ms)) continue;
        s_next   = (i + 1) % s_count;
        s_active = i;
        if (start_task(e) != DT_OK) {       // 不應發生 (參數已在 add 時檢查)
            s_active = -2;
            e->due_ms = now + e->cfg.period_ms;
        }
        return;
    }
}

static int queue_write(const uint8_t ip[4], uint16_t port, uint8_t unit_id, uint8_t fc,
                       uint16_t addr, uint16_t qty, const uint16_t* vals)
{
    if (s_write.pending) return DT_ERR_BUSY;
    if (!ip || port == 0 || !vals || qty < 1 || qty > DT_MB_MAX_WRITE_REGS) return DT_ERR_PARAM;
    memcpy(s_write.ip, ip, 4);
    s_write.port    = port;
    s_write.unit_id = unit_id;
    s_write.fc      = fc;
    s_write.addr    = addr;
    s_write.qty     = qty;
    memcpy(s_write.vals, vals, qty * sizeof(uint16_t));
    s_write.pending = true;
    hook_client();
    return DT_OK;
}

int DT_MbPoll_WriteCoil(const uint8_t ip[4], uint16_t port, uint8_t unit_id, uint16_t addr, bool val)
{
    uint16_t v = val ? 1 : 0;
    return queue_write(ip, port, unit_id, DT_MB_FC_WRITE_COIL, addr, 1, &v);
}

int DT_MbPoll_WriteRegister(const uint8_t ip[4], uint16_t port, uint8_t unit_id, uint16_t addr, uint16_t val)
{
    return queue_write(ip, port, unit_id, DT_MB_FC_WRITE_REGISTER, addr, 1, &val);
}

int DT_MbPoll_WriteRegisters(const uint8_t ip[4], uint16_t port, uint8_t unit_id,
                            uint16_t addr, uint16_t qty, const uint16_t* vals)
{
    return queue_write(ip, port, unit_id, DT_MB_FC_WRITE_REGISTERS, addr, qty, vals);
}
