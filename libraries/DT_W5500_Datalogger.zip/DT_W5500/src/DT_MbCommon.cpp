/**
 * @file DT_MbCommon.cpp
 * @brief Modbus TCP 共用函式。
 */

#include <string.h>
#include "DT_MbCommon.h"

uint16_t DT_Mb_GetU16(const uint8_t* p) {
    return (uint16_t)((p[0] << 8) | p[1]);
}

void DT_Mb_PutU16(uint8_t* p, uint16_t v) {
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)(v & 0xFF);
}

bool DT_Mb_MbapParse(const uint8_t* buf, uint16_t len, DT_MbMbap_t* hdr) {
    if (len < DT_MB_MBAP_LEN) return false;
    hdr->tid = DT_Mb_GetU16(buf);
    hdr->pid = DT_Mb_GetU16(buf + 2);
    hdr->len = DT_Mb_GetU16(buf + 4);
    hdr->uid = buf[6];
    // LEN = UID(1) + PDU(1..253)
    return hdr->pid == 0 && hdr->len >= 2 && hdr->len <= DT_MB_PDU_MAX + 1;
}

void DT_Mb_MbapBuild(uint8_t* buf, uint16_t tid, uint8_t uid, uint16_t pdu_len) {
    DT_Mb_PutU16(buf, tid);
    DT_Mb_PutU16(buf + 2, 0);
    DT_Mb_PutU16(buf + 4, (uint16_t)(pdu_len + 1));
    buf[6] = uid;
}

static uint16_t swap_bytes(uint16_t v) { return (uint16_t)((v << 8) | (v >> 8)); }

uint32_t DT_Mb_RegsToU32(const uint16_t r[2], DT_MbOrder_t order) {
    uint16_t hi = r[0], lo = r[1];
    if (order == DT_MB_ORDER_CDAB || order == DT_MB_ORDER_DCBA) { hi = r[1]; lo = r[0]; }
    if (order == DT_MB_ORDER_BADC || order == DT_MB_ORDER_DCBA) { hi = swap_bytes(hi); lo = swap_bytes(lo); }
    return ((uint32_t)hi << 16) | lo;
}

void DT_Mb_U32ToRegs(uint32_t v, uint16_t r[2], DT_MbOrder_t order) {
    uint16_t hi = (uint16_t)(v >> 16), lo = (uint16_t)v;
    if (order == DT_MB_ORDER_BADC || order == DT_MB_ORDER_DCBA) { hi = swap_bytes(hi); lo = swap_bytes(lo); }
    if (order == DT_MB_ORDER_CDAB || order == DT_MB_ORDER_DCBA) { r[0] = lo; r[1] = hi; }
    else                                                        { r[0] = hi; r[1] = lo; }
}

float DT_Mb_RegsToFloat(const uint16_t r[2], DT_MbOrder_t order) {
    uint32_t u = DT_Mb_RegsToU32(r, order);
    float f;
    memcpy(&f, &u, sizeof(f));      // IEEE 754 單精度
    return f;
}

void DT_Mb_FloatToRegs(float v, uint16_t r[2], DT_MbOrder_t order) {
    uint32_t u;
    memcpy(&u, &v, sizeof(u));
    DT_Mb_U32ToRegs(u, r, order);
}

int DT_Mb_ExceptionCode(int err) {
    return (err <= DT_ERR_MB_EXCEPTION) ? (DT_ERR_MB_EXCEPTION - err) : 0;
}
