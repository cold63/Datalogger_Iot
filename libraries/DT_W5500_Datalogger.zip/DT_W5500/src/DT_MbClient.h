/**
 * @file DT_MbClient.h
 * @brief Modbus TCP Client (Master)，非阻塞。
 *
 *  - DT_MbClient_ReadXxx() / WriteXxx() 只是排入請求並立即返回
 *    (DT_OK = 已排入，DT_ERR_BUSY = 上一筆尚未完成，DT_ERR_PARAM = 參數錯誤)
 *  - DT_MbClient_Loop() 須在 loop() 持續呼叫，負責連線、送出、等待回應
 *  - 請求完成 (成功或失敗) 時由 DT_MbClient_Loop() 呼叫完成回呼
 *  - 連線失敗後 DT_MB_CLIENT_RETRY_MS 內的請求直接以 DT_ERR_CONNECT 完成
 *  - 輪詢多台 Slave 請改用 DT_MbPoll (它會接管完成回呼)
 * 佔用 socket：1 個 (連線期間)。
 */

#ifndef _DT_MB_CLIENT_H_
#define _DT_MB_CLIENT_H_

#include "DT_MbCommon.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @brief 請求結果 (只在完成回呼內有效) */
typedef struct {
    uint8_t         fc;         // 功能碼
    uint16_t        addr;       // 起始位址
    uint16_t        qty;        // 數量
    int             result;     // DT_OK 或負值錯誤碼 (例外: DT_ERR_MB_EXCEPTION - 例外碼)
    const uint16_t* regs;       // FC03/04 讀回的暫存器
    const uint8_t*  bits;       // FC01/02 讀回的位元 (打包)，用 DT_MbClient_Bit() 取值
} DT_MbClientResult_t;

typedef void (*DT_MbClientCb_t)(const DT_MbClientResult_t* r);

/** @brief 統計資料 */
typedef struct {
    uint32_t ok;            // 成功次數
    uint32_t errors;        // 失敗次數
    int      last_error;    // 最後一次結果 (DT_OK 或錯誤碼)
    bool     connected;
} DT_MbClientStats_t;

/** @brief 設定目標 Slave；目標改變時會關閉既有連線 */
void DT_MbClient_SetTarget(const uint8_t ip[4], uint16_t port, uint8_t unit_id);
void DT_MbClient_SetCallback(DT_MbClientCb_t cb);

/** @brief 驅動狀態機，須在 loop() 持續呼叫 */
void DT_MbClient_Loop(void);

int DT_MbClient_ReadCoils(uint16_t addr, uint16_t qty);                  // FC01
int DT_MbClient_ReadDiscrete(uint16_t addr, uint16_t qty);               // FC02
int DT_MbClient_ReadHolding(uint16_t addr, uint16_t qty);                // FC03
int DT_MbClient_ReadInput(uint16_t addr, uint16_t qty);                  // FC04
int DT_MbClient_WriteCoil(uint16_t addr, bool val);                      // FC05
int DT_MbClient_WriteRegister(uint16_t addr, uint16_t val);              // FC06
int DT_MbClient_WriteCoils(uint16_t addr, uint16_t qty, const bool* vals);          // FC15
int DT_MbClient_WriteRegisters(uint16_t addr, uint16_t qty, const uint16_t* vals);  // FC16

bool DT_MbClient_Busy(void);                                    // 是否有請求進行中
bool DT_MbClient_Bit(const DT_MbClientResult_t* r, uint16_t i); // 取 FC01/02 結果的第 i 個位元

/** @brief 主動關閉連線 (進行中的請求以 DT_ERR_CLOSED 完成) */
void DT_MbClient_Close(void);

void DT_MbClient_GetStats(DT_MbClientStats_t* st);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MB_CLIENT_H_ */
