/**
 * @file DT_MbStore.h
 * @brief 將一段 Holding Register 保存到 Flash (AmebaD DCT / Preferences)，斷電後保留。
 *
 * 使用方式：
 *   setup(): 先放出廠預設值 → DT_MbStore_Begin(20, 20) → DT_MbStore_Load()
 *   loop():  DT_MbStore_Loop()  — 值改變且穩定 DT_MB_STORE_DELAY_MS 後才寫入，值沒變不寫
 *
 *  - 儲存在 Preferences namespace "dt_mb"，key "hr" (DCT 區，有備份機制)，
 *    不直接寫 Flash 位址，不會與 BLE / WiFi / OTA 衝突
 *  - 與 sketch 自己的 Preferences 共用 DCT 的 6 個 namespace 中的 1 個
 *  - 一次最多保存 DT_MB_STORE_MAX_REGS (64) 個暫存器 (DCT 單一值上限 132 bytes)
 *  - 保存範圍 (start / count) 改變時，舊資料視為無效
 */

#ifndef _DT_MB_STORE_H_
#define _DT_MB_STORE_H_

#include "DT_MbCommon.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DT_MB_STORE_MAX_REGS    64

/** @brief 設定保存範圍 HR[hr_start .. hr_start+hr_count)，回傳 DT_OK / DT_ERR_PARAM / DT_ERR */
int  DT_MbStore_Begin(uint16_t hr_start, uint16_t hr_count);

/** @brief 從 Flash 還原到資料表，回傳 DT_OK；無有效資料時回傳 DT_ERR 並保留目前的值 */
int  DT_MbStore_Load(void);

/** @brief 檢查是否需要保存，回傳 true 表示這次有寫入 Flash */
bool DT_MbStore_Loop(void);

/** @brief 立即保存目前的值 */
int  DT_MbStore_Save(void);

/** @brief 清除保存的資料 (恢復出廠值，重開機後生效) */
int  DT_MbStore_Erase(void);

/** @brief 開機以來寫入 Flash 的次數 */
uint32_t DT_MbStore_WriteCount(void);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MB_STORE_H_ */
