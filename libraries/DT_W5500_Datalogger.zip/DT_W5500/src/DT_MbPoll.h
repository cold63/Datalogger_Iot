/**
 * @file DT_MbPoll.h
 * @brief Modbus Client 輪詢表：依週期讀取多台 Slave，結果自動存入本機資料表。
 *
 *  - FC03/04 讀回的暫存器存入本機 IR[local_addr..]，FC01/02 的位元存入 DI[local_addr..]
 *    (本機資料表由 DT_MbData_Begin() 設定；只需要回呼時 local 範圍仍須在資料表內)
 *  - 連續失敗 DT_MB_POLL_OFFLINE_FAILS 次視為離線；連線失敗時延後 DT_MB_CLIENT_RETRY_MS 再試
 *  - 單筆寫入 (DT_MbPoll_WriteXxx) 排在下一筆輪詢之前執行
 *  - DT_MbPoll_Loop() 內部會呼叫 DT_MbClient_Loop()，loop() 只需呼叫 DT_MbPoll_Loop()
 *  - 使用 DT_MbClient 的單一 socket：不同 Slave 之間切換時會重新連線
 *  - 會接管 DT_MbClient 的完成回呼，請改用 DT_MbPoll_SetCallback()
 */

#ifndef _DT_MB_POLL_H_
#define _DT_MB_POLL_H_

#include "DT_MbCommon.h"
#include "DT_MbClient.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DT_MB_POLL_WRITE_TASK  (-1)    // 完成回呼中代表單筆寫入

/** @brief 輪詢項目 */
typedef struct {
    uint8_t  ip[4];         // Slave IP
    uint16_t port;          // Slave port
    uint8_t  unit_id;       // Slave Unit ID
    uint8_t  fc;            // DT_MB_FC_READ_COILS / DISCRETE / HOLDING / INPUT
    uint16_t addr;          // 遠端起始位址
    uint16_t qty;           // 數量
    uint16_t local_addr;    // 存入本機的起始位址 (IR 或 DI)
    uint32_t period_ms;     // 輪詢週期
} DT_MbPollTask_t;

/** @brief 輪詢項目狀態 */
typedef struct {
    bool     online;        // 最近一次成功且未連續失敗
    uint8_t  fails;         // 連續失敗次數
    int      last_result;   // 最後一次結果
    uint32_t ok;
    uint32_t errors;
} DT_MbPollStatus_t;

/** @brief 每筆請求完成時呼叫 (task = 項目索引，或 DT_MB_POLL_WRITE_TASK) */
typedef void (*DT_MbPollCb_t)(int task, const DT_MbClientResult_t* r);

/** @brief 新增輪詢項目 (內容會複製)，回傳索引或 DT_ERR_PARAM (參數錯誤/表已滿) */
int  DT_MbPoll_Add(const DT_MbPollTask_t* task);
void DT_MbPoll_Clear(void);
void DT_MbPoll_SetCallback(DT_MbPollCb_t cb);

/** @brief 須在 loop() 持續呼叫 (已包含 DT_MbClient_Loop()) */
void DT_MbPoll_Loop(void);

int  DT_MbPoll_Count(void);
bool DT_MbPoll_GetStatus(int task, DT_MbPollStatus_t* st);

/** @brief 單筆寫入：上一筆寫入尚未完成時回傳 DT_ERR_BUSY */
int DT_MbPoll_WriteCoil(const uint8_t ip[4], uint16_t port, uint8_t unit_id, uint16_t addr, bool val);
int DT_MbPoll_WriteRegister(const uint8_t ip[4], uint16_t port, uint8_t unit_id, uint16_t addr, uint16_t val);
int DT_MbPoll_WriteRegisters(const uint8_t ip[4], uint16_t port, uint8_t unit_id,
                             uint16_t addr, uint16_t qty, const uint16_t* vals);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MB_POLL_H_ */
