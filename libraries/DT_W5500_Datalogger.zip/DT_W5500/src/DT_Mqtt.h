/**
 * @file DT_Mqtt.h
 * @brief MQTT 3.1.1 client (Paho embedded) over TCP or TLS, with auto reconnect.
 *
 * 使用方式：
 *   setup(): DT_Mqtt_ConfigDefault(&cfg); 填入 host/port/client_id; DT_Mqtt_Begin(&cfg);
 *            DT_Mqtt_SetCallback(cb); DT_Mqtt_Subscribe("topic", 0);
 *   loop():  DT_Net_Loop(); DT_Mqtt_Loop();
 * 訂閱清單會保存在 Library 內，重連後自動重新訂閱。
 */

#ifndef _DT_MQTT_H_
#define _DT_MQTT_H_

#include "DT_Types.h"
#include "DT_Tls.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    DT_MQTT_IDLE = 0,       // DT_Mqtt_Begin() not called / stopped
    DT_MQTT_WAIT_NET,       // waiting for DT_Net READY
    DT_MQTT_CONNECTING,     // next DT_Mqtt_Loop() will connect (blocking)
    DT_MQTT_CONNECTED,
    DT_MQTT_RETRY_WAIT      // connection failed / lost, waiting reconnect_ms
} DT_MqttState_t;

typedef struct {
    const char* host;           // broker host name or IP string
    uint16_t    port;           // 1883 / 8883
    const char* client_id;
    const char* username;       // NULL = none
    const char* password;       // NULL = none
    uint16_t    keepalive_s;    // default 60
    bool        clean_session;  // default true
    uint8_t     mqtt_version;   // 3 = 3.1, 4 = 3.1.1 (default)
    bool        use_tls;
    const DT_TlsConfig_t* tls;  // NULL = TLS without server verification
    const char* will_topic;     // NULL = no last will
    const char* will_msg;
    uint8_t     will_qos;
    bool        will_retain;
    uint32_t    reconnect_ms;   // default DT_MQTT_RECONNECT_MS
    uint32_t    cmd_timeout_ms; // default DT_MQTT_CMD_TIMEOUT_MS
} DT_MqttConfig_t;

/** @brief Received message. topic is NUL-terminated (truncated to DT_MQTT_TOPIC_MAX-1). */
typedef void (*DT_MqttMsgCb_t)(const char* topic, const uint8_t* payload, uint16_t len);
typedef void (*DT_MqttStateCb_t)(DT_MqttState_t state);

void DT_Mqtt_ConfigDefault(DT_MqttConfig_t* cfg);

/** @brief Store configuration (strings are copied). Connection starts from DT_Mqtt_Loop(). */
int  DT_Mqtt_Begin(const DT_MqttConfig_t* cfg);

void DT_Mqtt_SetCallback(DT_MqttMsgCb_t cb);
void DT_Mqtt_SetStateCallback(DT_MqttStateCb_t cb);

/** @brief Add to the subscription list; subscribes now if connected. */
int  DT_Mqtt_Subscribe(const char* topic, uint8_t qos);
int  DT_Mqtt_Unsubscribe(const char* topic);

/** @brief Publish (blocks for PUBACK/PUBCOMP when qos > 0). */
int  DT_Mqtt_Publish(const char* topic, const uint8_t* payload, uint16_t len, uint8_t qos, bool retain);
int  DT_Mqtt_PublishStr(const char* topic, const char* msg);

/** @brief Connect / reconnect, process incoming packets and keepalive. Call from loop(). */
void DT_Mqtt_Loop(void);

bool           DT_Mqtt_IsConnected(void);
DT_MqttState_t DT_Mqtt_GetState(void);
const char*    DT_Mqtt_StateName(DT_MqttState_t state);

/** @brief Result of the last connect attempt (DT_Err_t or MQTT CONNACK code > 0). */
int  DT_Mqtt_LastError(void);

/** @brief Send DISCONNECT and stop auto reconnect. DT_Mqtt_Begin() again to restart. */
void DT_Mqtt_Disconnect(void);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MQTT_H_ */
