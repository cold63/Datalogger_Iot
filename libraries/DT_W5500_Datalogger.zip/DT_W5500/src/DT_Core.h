/**
 * @file DT_Core.h
 * @brief W5500 chip init, bit-bang SPI HAL, network registers, socket pool.
 */

#ifndef _DT_CORE_H_
#define _DT_CORE_H_

#include "DT_Config.h"
#include "DT_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Default wiring from DT_Config.h. */
#define DT_PINS_DEFAULT { DT_PIN_SCLK_DEFAULT, DT_PIN_MISO_DEFAULT, DT_PIN_MOSI_DEFAULT, \
                          DT_PIN_CS_DEFAULT, DT_PIN_RST_DEFAULT }

/**
 * @brief Initialize pins, reset the chip and register the SPI HAL.
 * @param pins wiring, NULL = DT_PINS_DEFAULT
 * @return DT_OK, or DT_ERR_CHIP if the W5500 version register does not read 0x04
 */
int DT_W5500_Begin(const DT_Pins_t* pins);

/**
 * @brief Same as DT_W5500_Begin() with per-socket buffer sizes in KB.
 * @param tx_kb / rx_kb 8 entries, total of each must be <= 16. NULL = 2KB each.
 */
int DT_W5500_BeginEx(const DT_Pins_t* pins, const uint8_t tx_kb[8], const uint8_t rx_kb[8]);

void    DT_W5500_HwReset(void);
uint8_t DT_W5500_GetVersion(void);          // 0x04 for W5500
bool    DT_W5500_IsLinkUp(void);

void DT_W5500_SetNetInfo(const DT_NetInfo_t* info);
void DT_W5500_GetNetInfo(DT_NetInfo_t* info);
void DT_W5500_SetMac(const uint8_t mac[6]);
void DT_W5500_GetMac(uint8_t mac[6]);
void DT_W5500_SetPing(bool enable);         // respond to ICMP echo (default on)

/**
 * @brief TCP retransmission settings (affects connect/send timeout).
 * @param timeout_ms retry interval, max 6553 ms
 * @param count retry count
 */
void DT_W5500_SetRetry(uint16_t timeout_ms, uint8_t count);

/* ===== Hardware socket pool ===== */
int      DT_Socket_Alloc(void);             // returns 0..5 or DT_ERR_NO_SOCKET
void     DT_Socket_Free(int sn);            // closes and releases the socket
uint16_t DT_Socket_LocalPort(void);         // next ephemeral port (49152..65535)

/* ===== Utilities ===== */
void DT_IpToStr(const uint8_t ip[4], char out[16]);
bool DT_StrToIp(const char* str, uint8_t ip[4]);
void DT_PrintIp(const char* label, const uint8_t ip[4]);   // prints to Serial
void DT_PrintNetInfo(void);                                 // prints to Serial

#ifdef __cplusplus
}
#endif

#endif /* _DT_CORE_H_ */
