/**
 * @file DT_Core.cpp
 * @brief W5500 driver core (bit-bang SPI based on PAA3905 style).
 */

#include "DT_Internal.h"
#include "DT_Core.h"
#include "DT_Net.h"

static DT_Pins_t s_pins = DT_PINS_DEFAULT;
static bool      s_sockUsed[DT_SOCK_APP_MAX];
static uint16_t  s_nextPort = 0;

/* ===== Port layer for ioLibrary ===== */

extern "C" unsigned long DT_Port_Millis(void) { return millis(); }
extern "C" void DT_Port_DelayMs(uint32_t ms) { delay(ms); }

/* ===== Bit-banging SPI ===== */

#define dly1u   delayMicroseconds(DT_SPI_HALF_PERIOD_US)

// Transfer 8 bits (full duplex, mode 0, MSB first)
static uint8_t tr8b(uint8_t data) {
    uint8_t received = 0;
    uint8_t bitmap = 0x80;
    for (int i = 0; i < 8; i++) {
        digitalWrite(s_pins.mosi, (bitmap & data) ? HIGH : LOW);
        dly1u; digitalWrite(s_pins.sclk, HIGH);
        if (digitalRead(s_pins.miso)) received |= bitmap;
        dly1u; digitalWrite(s_pins.sclk, LOW);
        bitmap >>= 1;
    }
    return received;
}

/* ===== WIZnet HAL callbacks ===== */

static void hal_cs_select(void) {
    digitalWrite(s_pins.cs, LOW);
    delayMicroseconds(DT_SPI_CS_SETUP_US);
}

static void hal_cs_deselect(void) {
    delayMicroseconds(DT_SPI_CS_SETUP_US);
    digitalWrite(s_pins.cs, HIGH);
}

static uint8_t hal_read_byte(void) { return tr8b(0x00); }
static void hal_write_byte(uint8_t wb) { tr8b(wb); }

static void hal_read_burst(uint8_t* pBuf, uint16_t len) {
    for (uint16_t i = 0; i < len; i++) pBuf[i] = tr8b(0x00);
}

static void hal_write_burst(uint8_t* pBuf, uint16_t len) {
    for (uint16_t i = 0; i < len; i++) tr8b(pBuf[i]);
}

static void hal_critical_enter(void) { noInterrupts(); }
static void hal_critical_exit(void) { interrupts(); }

/* ===== Initialization ===== */

void DT_W5500_HwReset(void) {
    pinMode(s_pins.rst, OUTPUT);
    digitalWrite(s_pins.rst, LOW);
    delay(10);
    digitalWrite(s_pins.rst, HIGH);
    delay(200);
}

int DT_W5500_Begin(const DT_Pins_t* pins) {
    return DT_W5500_BeginEx(pins, NULL, NULL);
}

int DT_W5500_BeginEx(const DT_Pins_t* pins, const uint8_t tx_kb[8], const uint8_t rx_kb[8]) {
    if (pins) s_pins = *pins;

    pinMode(s_pins.cs, OUTPUT);
    digitalWrite(s_pins.cs, HIGH);
    pinMode(s_pins.sclk, OUTPUT);
    digitalWrite(s_pins.sclk, LOW);
    pinMode(s_pins.mosi, OUTPUT);
    digitalWrite(s_pins.mosi, LOW);
    pinMode(s_pins.miso, INPUT);

    DT_W5500_HwReset();

    reg_wizchip_cris_cbfunc(hal_critical_enter, hal_critical_exit);
    reg_wizchip_cs_cbfunc(hal_cs_select, hal_cs_deselect);
    reg_wizchip_spi_cbfunc(hal_read_byte, hal_write_byte);
    reg_wizchip_spiburst_cbfunc(hal_read_burst, hal_write_burst);

    if (getVERSIONR() != 0x04) return DT_ERR_CHIP;

    // Software reset first: it restores buffer sizes to default, so it must
    // happen before wizchip_init() applies the requested sizes.
    setMR(MR_RST);
    delay(10);
    uint32_t start = millis();
    while (getMR() & MR_RST) {
        if (DT_Elapsed(start) > 1000) return DT_ERR_CHIP;
    }

    uint8_t def[8] = {2, 2, 2, 2, 2, 2, 2, 2};
    uint8_t tx[8], rx[8];
    memcpy(tx, tx_kb ? tx_kb : def, 8);
    memcpy(rx, rx_kb ? rx_kb : def, 8);
    if (wizchip_init(tx, rx) != 0) return DT_ERR_PARAM;

    setMR(0x00);   // normal mode, ping response enabled

    memset(s_sockUsed, 0, sizeof(s_sockUsed));
    s_nextPort = 49152 + (uint16_t)(micros() % 16000);
    return DT_OK;
}

uint8_t DT_W5500_GetVersion(void) { return getVERSIONR(); }

bool DT_W5500_IsLinkUp(void) { return wizphy_getphylink() == PHY_LINK_ON; }

/* ===== Network registers ===== */

void DT_W5500_SetNetInfo(const DT_NetInfo_t* info) {
    if (!info) return;
    wiz_NetInfo ni;
    memcpy(ni.mac, info->mac, 6);
    memcpy(ni.ip, info->ip, 4);
    memcpy(ni.sn, info->sn, 4);
    memcpy(ni.gw, info->gw, 4);
    memcpy(ni.dns, info->dns, 4);
    ni.dhcp = (dhcp_mode)info->dhcp;
    wizchip_setnetinfo(&ni);
}

void DT_W5500_GetNetInfo(DT_NetInfo_t* info) {
    if (!info) return;
    wiz_NetInfo ni;
    wizchip_getnetinfo(&ni);
    memcpy(info->mac, ni.mac, 6);
    memcpy(info->ip, ni.ip, 4);
    memcpy(info->sn, ni.sn, 4);
    memcpy(info->gw, ni.gw, 4);
    // W5500 has no DNS register; ioLibrary keeps it in RAM, DT_Net keeps the live value
    DT_Net_GetDnsServer(info->dns);
    info->dhcp = (uint8_t)ni.dhcp;
}

void DT_W5500_SetMac(const uint8_t mac[6]) { setSHAR((uint8_t*)mac); }
void DT_W5500_GetMac(uint8_t mac[6]) { getSHAR(mac); }

void DT_W5500_SetPing(bool enable) {
    uint8_t mr = getMR();
    if (enable) mr &= ~MR_PB; else mr |= MR_PB;
    setMR(mr);
}

void DT_W5500_SetRetry(uint16_t timeout_ms, uint8_t count) {
    uint32_t rtr = (uint32_t)timeout_ms * 10;   // unit: 100us
    if (rtr > 0xFFFF) rtr = 0xFFFF;
    setRTR((uint16_t)rtr);
    setRCR(count);
}

/* ===== Socket pool ===== */

int DT_Socket_Alloc(void) {
    for (int i = 0; i < DT_SOCK_APP_MAX; i++) {
        if (!s_sockUsed[i]) {
            s_sockUsed[i] = true;
            close((uint8_t)i);
            return i;
        }
    }
    return DT_ERR_NO_SOCKET;
}

void DT_Socket_Free(int sn) {
    if (sn < 0 || sn >= DT_SOCK_APP_MAX) return;
    close((uint8_t)sn);
    s_sockUsed[sn] = false;
}

bool DT_Socket_IsValid(int sn) {
    return sn >= 0 && sn < DT_SOCK_APP_MAX && s_sockUsed[sn];
}

uint16_t DT_Socket_LocalPort(void) {
    if (s_nextPort < 49152) s_nextPort = 49152;
    uint16_t p = s_nextPort++;
    if (s_nextPort == 0) s_nextPort = 49152;   // wrapped past 65535
    return p;
}

/* ===== Utilities ===== */

void DT_IpToStr(const uint8_t ip[4], char out[16]) {
    snprintf(out, 16, "%u.%u.%u.%u", ip[0], ip[1], ip[2], ip[3]);
}

bool DT_StrToIp(const char* str, uint8_t ip[4]) {
    if (!str) return false;
    uint8_t tmp[4];
    for (int i = 0; i < 4; i++) {
        if (*str < '0' || *str > '9') return false;
        uint16_t v = 0;
        int digits = 0;
        while (*str >= '0' && *str <= '9') {
            v = v * 10 + (*str++ - '0');
            if (++digits > 3 || v > 255) return false;
        }
        tmp[i] = (uint8_t)v;
        if (i < 3) {
            if (*str != '.') return false;
            str++;
        }
    }
    if (*str != '\0') return false;
    memcpy(ip, tmp, 4);
    return true;
}

void DT_PrintIp(const char* label, const uint8_t ip[4]) {
    char buf[16];
    DT_IpToStr(ip, buf);
    if (label) Serial.print(label);
    Serial.println(buf);
}

void DT_PrintNetInfo(void) {
    DT_NetInfo_t ni;
    DT_W5500_GetNetInfo(&ni);
    char mac[18];
    snprintf(mac, sizeof(mac), "%02X:%02X:%02X:%02X:%02X:%02X",
             ni.mac[0], ni.mac[1], ni.mac[2], ni.mac[3], ni.mac[4], ni.mac[5]);
    Serial.print("MAC : "); Serial.println(mac);
    DT_PrintIp("IP  : ", ni.ip);
    DT_PrintIp("SN  : ", ni.sn);
    DT_PrintIp("GW  : ", ni.gw);
    DT_PrintIp("DNS : ", ni.dns);
}

const char* DT_ErrName(int err) {
    if (err <= DT_ERR_MB_EXCEPTION) return "ERR_MB_EXCEPTION";   // 例外碼見 DT_Mb_ExceptionCode()
    switch (err) {
    case DT_OK:            return "OK";
    case DT_ERR:           return "ERR";
    case DT_ERR_PARAM:     return "ERR_PARAM";
    case DT_ERR_CHIP:      return "ERR_CHIP";
    case DT_ERR_NO_LINK:   return "ERR_NO_LINK";
    case DT_ERR_NOT_READY: return "ERR_NOT_READY";
    case DT_ERR_TIMEOUT:   return "ERR_TIMEOUT";
    case DT_ERR_NO_SOCKET: return "ERR_NO_SOCKET";
    case DT_ERR_SOCKET:    return "ERR_SOCKET";
    case DT_ERR_DNS:       return "ERR_DNS";
    case DT_ERR_CONNECT:   return "ERR_CONNECT";
    case DT_ERR_TLS:       return "ERR_TLS";
    case DT_ERR_MQTT:      return "ERR_MQTT";
    case DT_ERR_HTTP:      return "ERR_HTTP";
    case DT_ERR_NO_MEM:    return "ERR_NO_MEM";
    case DT_ERR_CLOSED:    return "ERR_CLOSED";
    case DT_ERR_URL:       return "ERR_URL";
    case DT_ERR_MODBUS:    return "ERR_MODBUS";
    case DT_ERR_BUSY:      return "ERR_BUSY";
    default:               return (err > 0) ? "OK" : "ERR_UNKNOWN";
    }
}
