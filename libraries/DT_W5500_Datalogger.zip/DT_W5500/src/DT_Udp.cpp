/**
 * @file DT_Udp.cpp
 * @brief UDP wrapper over ioLibrary sockets.
 */

#include "DT_Internal.h"
#include "DT_Core.h"
#include "DT_Net.h"
#include "DT_Dns.h"
#include "DT_Udp.h"

int DT_Udp_Begin(uint16_t local_port) {
    if (!DT_Net_IsReady()) return DT_ERR_NOT_READY;
    int sn = DT_Socket_Alloc();
    if (sn < 0) return sn;
    if (local_port == 0) local_port = DT_Socket_LocalPort();
    if (socket((uint8_t)sn, Sn_MR_UDP, local_port, 0) != sn) {
        DT_Socket_Free(sn);
        return DT_ERR_SOCKET;
    }
    return sn;
}

int DT_Udp_SendTo(int sock, const uint8_t ip[4], uint16_t port, const uint8_t* data, uint16_t len) {
    if (!DT_Socket_IsValid(sock) || !ip || port == 0 || !data || len == 0) return DT_ERR_PARAM;
    int32_t r = sendto_W5x00((uint8_t)sock, (uint8_t*)data, len, (uint8_t*)ip, port);
    if (r == SOCKERR_TIMEOUT) return DT_ERR_TIMEOUT;   // ARP failed: host unreachable
    return (r < 0) ? DT_ERR_SOCKET : (int)r;
}

int DT_Udp_SendToHost(int sock, const char* host, uint16_t port, const uint8_t* data, uint16_t len) {
    uint8_t ip[4];
    int r = DT_Dns_Resolve(host, ip);
    if (r != DT_OK) return r;
    return DT_Udp_SendTo(sock, ip, port, data, len);
}

bool DT_Udp_Available(int sock) {
    if (!DT_Socket_IsValid(sock)) return false;
    return getSn_RX_RSR((uint8_t)sock) > 0;
}

int DT_Udp_RecvFrom(int sock, uint8_t* buf, uint16_t len, uint8_t ip[4], uint16_t* port) {
    if (!DT_Socket_IsValid(sock) || !buf || len == 0) return DT_ERR_PARAM;
    if (getSn_RX_RSR((uint8_t)sock) == 0) return 0;
    uint8_t  from[4];
    uint16_t from_port;
    int32_t r = recvfrom_W5x00((uint8_t)sock, buf, len, from, &from_port);
    if (r < 0) return DT_ERR_SOCKET;
    if (ip) memcpy(ip, from, 4);
    if (port) *port = from_port;
    return (int)r;
}

void DT_Udp_Close(int sock) {
    DT_Socket_Free(sock);
}
