/**
 * @file DT_MbData.cpp
 * @brief Modbus Server 資料表實作 (陣列由 sketch 提供)。
 */

#include <string.h>
#include "DT_MbData.h"

static DT_MbTables_t     s_t;               // 未 Begin 時全為 NULL / 0
static DT_MbWriteCb_t    s_write_cb    = 0;
static DT_MbValidateCb_t s_validate_cb = 0;
static DT_MbOrder_t      s_order       = DT_MB_ORDER_ABCD;

static void bit_set(uint8_t* arr, uint16_t addr, bool val) {
    if (val) arr[addr >> 3] |=  (uint8_t)(1 << (addr & 7));
    else     arr[addr >> 3] &= (uint8_t)~(1 << (addr & 7));
}

static bool bit_get(const uint8_t* arr, uint16_t addr) {
    return (arr[addr >> 3] >> (addr & 7)) & 1;
}

void DT_MbData_Begin(uint8_t* coils, uint16_t num_coils, uint8_t* di, uint16_t num_di,
                     uint16_t* hr, uint16_t num_hr, uint16_t* ir, uint16_t num_ir) {
    s_t.coils = coils; s_t.num_coils = coils ? num_coils : 0;
    s_t.di    = di;    s_t.num_di    = di    ? num_di    : 0;
    s_t.hr    = hr;    s_t.num_hr    = hr    ? num_hr    : 0;
    s_t.ir    = ir;    s_t.num_ir    = ir    ? num_ir    : 0;
}

void DT_MbData_GetTables(DT_MbTables_t* t)       { if (t) *t = s_t; }
void DT_MbData_SetTables(const DT_MbTables_t* t) { if (t) DT_MbData_Begin(t->coils, t->num_coils, t->di, t->num_di,
                                                                          t->hr, t->num_hr, t->ir, t->num_ir); }

void DT_MbData_SetCoil(uint16_t addr, bool val) { if (addr < s_t.num_coils) bit_set(s_t.coils, addr, val); }
bool DT_MbData_GetCoil(uint16_t addr)           { return addr < s_t.num_coils && bit_get(s_t.coils, addr); }
void DT_MbData_SetDi(uint16_t addr, bool val)   { if (addr < s_t.num_di) bit_set(s_t.di, addr, val); }
bool DT_MbData_GetDi(uint16_t addr)             { return addr < s_t.num_di && bit_get(s_t.di, addr); }

void     DT_MbData_SetHr(uint16_t addr, uint16_t val) { if (addr < s_t.num_hr) s_t.hr[addr] = val; }
uint16_t DT_MbData_GetHr(uint16_t addr)               { return addr < s_t.num_hr ? s_t.hr[addr] : 0; }
void     DT_MbData_SetIr(uint16_t addr, uint16_t val) { if (addr < s_t.num_ir) s_t.ir[addr] = val; }
uint16_t DT_MbData_GetIr(uint16_t addr)               { return addr < s_t.num_ir ? s_t.ir[addr] : 0; }

/* ---- 32 位元 / float ---- */
void DT_MbData_SetWordOrder(DT_MbOrder_t order) { s_order = order; }

static void set_pair(uint16_t* table, uint16_t size, uint16_t addr, uint32_t val) {
    uint16_t r[2];
    if ((uint32_t)addr + 2 > size) return;
    DT_Mb_U32ToRegs(val, r, s_order);
    table[addr]     = r[0];
    table[addr + 1] = r[1];
}

static uint32_t get_pair(const uint16_t* table, uint16_t size, uint16_t addr) {
    if ((uint32_t)addr + 2 > size) return 0;
    return DT_Mb_RegsToU32(&table[addr], s_order);
}

static uint32_t float_bits(float v)    { uint32_t u; memcpy(&u, &v, 4); return u; }
static float    bits_float(uint32_t u) { float v; memcpy(&v, &u, 4); return v; }

void     DT_MbData_SetHrU32(uint16_t addr, uint32_t val) { set_pair(s_t.hr, s_t.num_hr, addr, val); }
uint32_t DT_MbData_GetHrU32(uint16_t addr)               { return get_pair(s_t.hr, s_t.num_hr, addr); }
void     DT_MbData_SetIrU32(uint16_t addr, uint32_t val) { set_pair(s_t.ir, s_t.num_ir, addr, val); }
uint32_t DT_MbData_GetIrU32(uint16_t addr)               { return get_pair(s_t.ir, s_t.num_ir, addr); }
void     DT_MbData_SetHrFloat(uint16_t addr, float val)  { set_pair(s_t.hr, s_t.num_hr, addr, float_bits(val)); }
float    DT_MbData_GetHrFloat(uint16_t addr)             { return bits_float(get_pair(s_t.hr, s_t.num_hr, addr)); }
void     DT_MbData_SetIrFloat(uint16_t addr, float val)  { set_pair(s_t.ir, s_t.num_ir, addr, float_bits(val)); }
float    DT_MbData_GetIrFloat(uint16_t addr)             { return bits_float(get_pair(s_t.ir, s_t.num_ir, addr)); }

bool DT_MbData_InRange(DT_MbType_t type, uint16_t addr, uint16_t count) {
    uint32_t size;
    switch (type) {
    case DT_MB_TYPE_COIL:     size = s_t.num_coils; break;
    case DT_MB_TYPE_DISCRETE: size = s_t.num_di;    break;
    case DT_MB_TYPE_HOLDING:  size = s_t.num_hr;    break;
    case DT_MB_TYPE_INPUT:    size = s_t.num_ir;    break;
    default:                  return false;
    }
    return count > 0 && (uint32_t)addr + count <= size;    // 32 位元避免溢位
}

void              DT_MbData_SetWriteCb(DT_MbWriteCb_t cb)       { s_write_cb = cb; }
DT_MbWriteCb_t    DT_MbData_GetWriteCb(void)                    { return s_write_cb; }
void              DT_MbData_SetValidateCb(DT_MbValidateCb_t cb) { s_validate_cb = cb; }
DT_MbValidateCb_t DT_MbData_GetValidateCb(void)                 { return s_validate_cb; }

void DT_MbData_NotifyWrite(DT_MbType_t type, uint16_t addr, uint16_t count) {
    if (s_write_cb) s_write_cb(type, addr, count);
}

uint8_t DT_MbData_Validate(DT_MbType_t type, uint16_t addr, uint16_t value) {
    return s_validate_cb ? s_validate_cb(type, addr, value) : 0;
}

void DT_MbData_Clear(void) {
    if (s_t.coils) memset(s_t.coils, 0, DT_MB_BITS_BYTES(s_t.num_coils));
    if (s_t.di)    memset(s_t.di, 0, DT_MB_BITS_BYTES(s_t.num_di));
    if (s_t.hr)    memset(s_t.hr, 0, s_t.num_hr * sizeof(uint16_t));
    if (s_t.ir)    memset(s_t.ir, 0, s_t.num_ir * sizeof(uint16_t));
}
