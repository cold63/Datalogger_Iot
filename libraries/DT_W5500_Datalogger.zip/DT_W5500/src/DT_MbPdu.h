/**
 * @file DT_MbPdu.h
 * @brief Modbus Server PDU 處理 (純邏輯，不碰網路)。
 *
 * 支援 FC01/02/03/04/05/06/15/16/22/23 與 FC43 (MEI 14 裝置識別)。
 * 一般不需直接呼叫，DT_MbServer 會使用；也可用於 Modbus RTU 等其他傳輸層。
 */

#ifndef _DT_MB_PDU_H_
#define _DT_MB_PDU_H_

#include "DT_MbCommon.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 裝置識別物件 id (FC43) */
#define DT_MB_DEVID_VENDOR_NAME     0x00
#define DT_MB_DEVID_PRODUCT         0x01
#define DT_MB_DEVID_REV             0x02
#define DT_MB_DEVID_URL             0x03
#define DT_MB_DEVID_NAME            0x04
#define DT_MB_DEVID_MODEL           0x05
#define DT_MB_DEVID_COUNT           6

/**
 * @brief 處理一筆請求 PDU (功能碼 + 資料)，產生回應 PDU
 * @param resp 回應緩衝 (至少 DT_MB_PDU_MAX bytes)
 * @return 回應 PDU 長度；例外回應為 2 bytes (fc|0x80, 例外碼)
 */
int DT_MbPdu_Process(const uint8_t* req, uint16_t req_len, uint8_t* resp);

/**
 * @brief 修改裝置識別字串 (預設值見 DT_Config.h 的 DT_MB_DEVID_*)
 * @param id  DT_MB_DEVID_VENDOR_NAME .. DT_MB_DEVID_MODEL
 * @param str 字串須保持有效 (建議用字串常數或全域變數)，超過 48 字元會截斷
 */
int DT_MbPdu_SetDeviceId(uint8_t id, const char* str);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MB_PDU_H_ */
