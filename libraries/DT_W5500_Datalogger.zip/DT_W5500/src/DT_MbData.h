/**
 * @file DT_MbData.h
 * @brief Modbus Server 資料表 (Coils / Discrete Inputs / Holding / Input Registers)。
 *
 * 資料表陣列由 sketch 宣告 (大小自訂)，在 setup() 中以 DT_MbData_Begin() 交給程式庫：
 *
 *   uint8_t  coils[DT_MB_BITS_BYTES(64)];   // bit 打包，64 個 Coil
 *   uint8_t  di[DT_MB_BITS_BYTES(64)];
 *   uint16_t hr[100];
 *   uint16_t ir[100];
 *   DT_MbData_Begin(coils, 64, di, 64, hr, 100, ir, 100);
 *
 * 位址為 0-based 協定位址；超出範圍的 Set 會被忽略、Get 回傳 0，
 * Master 存取超出範圍的位址回覆 EX02。不需要的資料表可傳 NULL, 0。
 */

#ifndef _DT_MB_DATA_H_
#define _DT_MB_DATA_H_

#include "DT_MbCommon.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @brief bit 資料表 (Coils / DI) 需要的 bytes 數 */
#define DT_MB_BITS_BYTES(n)     (((n) + 7) / 8)

/** @brief 資料表種類 */
typedef enum {
    DT_MB_TYPE_COIL = 0,
    DT_MB_TYPE_DISCRETE,
    DT_MB_TYPE_HOLDING,
    DT_MB_TYPE_INPUT
} DT_MbType_t;

/** @brief 資料表設定 (DT_MbData_GetTables / SetTables 用) */
typedef struct {
    uint8_t*  coils;  uint16_t num_coils;
    uint8_t*  di;     uint16_t num_di;
    uint16_t* hr;     uint16_t num_hr;
    uint16_t* ir;     uint16_t num_ir;
} DT_MbTables_t;

/** @brief Master 寫入成功後呼叫：type 為 COIL 或 HOLDING */
typedef void (*DT_MbWriteCb_t)(DT_MbType_t type, uint16_t addr, uint16_t count);

/**
 * @brief Master 寫入前逐筆檢查 (寫入資料表之前呼叫)
 * @param value Coil 為 0/1，HR 為暫存器值
 * @return 0 = 接受；非 0 = 拒絕並回覆此例外碼 (通常為 DT_MB_EX_ILLEGAL_VALUE)
 * 多筆寫入 (FC15/16/23) 只要有一筆被拒絕，整筆都不寫入
 */
typedef uint8_t (*DT_MbValidateCb_t)(DT_MbType_t type, uint16_t addr, uint16_t value);

void DT_MbData_Begin(uint8_t* coils, uint16_t num_coils, uint8_t* di, uint16_t num_di,
                     uint16_t* hr, uint16_t num_hr, uint16_t* ir, uint16_t num_ir);
void DT_MbData_GetTables(DT_MbTables_t* t);
void DT_MbData_SetTables(const DT_MbTables_t* t);

void     DT_MbData_SetCoil(uint16_t addr, bool val);
bool     DT_MbData_GetCoil(uint16_t addr);
void     DT_MbData_SetDi(uint16_t addr, bool val);
bool     DT_MbData_GetDi(uint16_t addr);
void     DT_MbData_SetHr(uint16_t addr, uint16_t val);
uint16_t DT_MbData_GetHr(uint16_t addr);
void     DT_MbData_SetIr(uint16_t addr, uint16_t val);
uint16_t DT_MbData_GetIr(uint16_t addr);

/* 32 位元 / float：佔 addr、addr+1 兩個暫存器，排列由 DT_MbData_SetWordOrder() 決定 (預設 ABCD) */
void     DT_MbData_SetWordOrder(DT_MbOrder_t order);
void     DT_MbData_SetHrU32(uint16_t addr, uint32_t val);
uint32_t DT_MbData_GetHrU32(uint16_t addr);
void     DT_MbData_SetIrU32(uint16_t addr, uint32_t val);
uint32_t DT_MbData_GetIrU32(uint16_t addr);
void     DT_MbData_SetHrFloat(uint16_t addr, float val);
float    DT_MbData_GetHrFloat(uint16_t addr);
void     DT_MbData_SetIrFloat(uint16_t addr, float val);
float    DT_MbData_GetIrFloat(uint16_t addr);

/** @brief 範圍檢查：addr..addr+count-1 是否都在資料表內 */
bool DT_MbData_InRange(DT_MbType_t type, uint16_t addr, uint16_t count);

void              DT_MbData_SetWriteCb(DT_MbWriteCb_t cb);
DT_MbWriteCb_t    DT_MbData_GetWriteCb(void);
void              DT_MbData_SetValidateCb(DT_MbValidateCb_t cb);
DT_MbValidateCb_t DT_MbData_GetValidateCb(void);

/* 給 DT_MbPdu 使用 */
void    DT_MbData_NotifyWrite(DT_MbType_t type, uint16_t addr, uint16_t count);
uint8_t DT_MbData_Validate(DT_MbType_t type, uint16_t addr, uint16_t value);

/** @brief 全部資料表清為 0 */
void DT_MbData_Clear(void);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MB_DATA_H_ */
