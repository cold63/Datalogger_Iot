/**
 * @file DT_MbServer.cpp
 * @brief Modbus TCP Server 網路層。
 *
 *  - 每條連線佔 1 個 W5500 socket，全部監聽同一個 port
 *  - 共開 DT_MB_SERVER_MAX_CONN + DT_MB_SERVER_SPARE 個 socket；連線數超過
 *    DT_MB_SERVER_MAX_CONN 時踢掉閒置最久的一條，避免死連線佔住名額
 *  - 收到的資料累積到滿一個 ADU (6 + MBAP.LEN) 才處理，可處理 TCP 分段
 *    與同一封包內多筆請求
 */

#include <string.h>
#include "DT_Internal.h"        // ioLibrary socket.h / w5500.h (setSn_KPALVTR)
#include "DT_Net.h"
#include "DT_Tcp.h"
#include "DT_MbServer.h"
#include "DT_MbPdu.h"

#define DT_MB_SERVER_SOCKS (DT_MB_SERVER_MAX_CONN + DT_MB_SERVER_SPARE)

typedef struct {
    int      sock;                  // W5500 socket，-1 = 未開啟
    bool     connected;
    uint16_t rx_len;
    uint32_t last_ms;               // 最後收到資料的時間
    uint8_t  rx[DT_MB_ADU_MAX];
} conn_t;

static conn_t  s_conn[DT_MB_SERVER_SOCKS];
static uint8_t    s_tx[DT_MB_ADU_MAX];
static uint16_t   s_port    = 0;    // 0 = 未啟用
static uint8_t    s_unit_id = 1;
static DT_MbStats_t s_stats;

/* 通訊中斷監控 */
static DT_MbFailsafeCb_t s_failsafe_cb = 0;
static uint32_t s_failsafe_ms = 0;      // 0 = 關閉
static bool     s_armed     = false;    // 收到第一筆請求後才開始監控
static bool     s_comm_lost = false;
static uint32_t s_last_req_ms = 0;

int DT_MbServer_Begin(uint16_t port, uint8_t unit_id)
{
    if (port == 0) return DT_ERR_PARAM;
    DT_MbServer_Stop();
    s_port    = port;
    s_unit_id = unit_id;
    memset(&s_stats, 0, sizeof(s_stats));
    return DT_OK;
}

static void close_all(void)
{
    for (int i = 0; i < DT_MB_SERVER_SOCKS; i++) {
        if (s_conn[i].sock >= 0) DT_TcpServer_Stop(s_conn[i].sock);
        s_conn[i].sock      = -1;
        s_conn[i].connected = false;
        s_conn[i].rx_len    = 0;
    }
    s_stats.clients = 0;
}

void DT_MbServer_Stop(void)
{
    static bool inited = false;
    if (!inited) {                  // 第一次呼叫時 socket 欄位還是 0，先標成未開啟
        for (int i = 0; i < DT_MB_SERVER_SOCKS; i++) s_conn[i].sock = -1;
        inited = true;
    }
    close_all();
    s_port = 0;
}

void DT_MbServer_GetStats(DT_MbStats_t* st)
{
    if (st) *st = s_stats;
}

void DT_MbServer_SetFailsafe(uint32_t timeout_ms, DT_MbFailsafeCb_t cb)
{
    s_failsafe_ms = timeout_ms;
    s_failsafe_cb = cb;
}

bool DT_MbServer_CommLost(void) { return s_comm_lost; }

/* 收到一筆給本機的請求：更新通訊監控 */
static void mark_request(void)
{
    s_last_req_ms = millis();
    s_armed = true;
    if (s_comm_lost) {
        s_comm_lost = false;
        if (s_failsafe_cb) s_failsafe_cb(false);
    }
}

static void check_failsafe(void)
{
    if (s_failsafe_ms && s_armed && !s_comm_lost && DT_Elapsed(s_last_req_ms) >= s_failsafe_ms) {
        s_comm_lost = true;
        if (s_failsafe_cb) s_failsafe_cb(true);
    }
}

/* 處理一筆完整 ADU，回傳 false 表示要斷開連線 */
static bool handle_adu(conn_t* c, const DT_MbMbap_t* hdr)
{
    const uint8_t* pdu     = c->rx + DT_MB_MBAP_LEN;
    uint16_t       pdu_len = hdr->len - 1;
    int            resp_len;

    s_stats.requests++;
    if (hdr->uid != s_unit_id && hdr->uid != 0 && hdr->uid != 0xFF) {
#if DT_MB_REPLY_BAD_UID
        s_tx[DT_MB_MBAP_LEN]     = pdu[0] | 0x80;
        s_tx[DT_MB_MBAP_LEN + 1] = DT_MB_EX_GATEWAY_NO_RESPONSE;
        resp_len = 2;
#else
        s_stats.ignored++;
        return true;
#endif
    } else {
        mark_request();
        resp_len = DT_MbPdu_Process(pdu, pdu_len, s_tx + DT_MB_MBAP_LEN);
    }
    if (resp_len <= 0) return true;
    if (s_tx[DT_MB_MBAP_LEN] & 0x80) s_stats.exceptions++;

    DT_Mb_MbapBuild(s_tx, hdr->tid, hdr->uid, (uint16_t)resp_len);
    return DT_Tcp_Send(c->sock, s_tx, (uint16_t)(DT_MB_MBAP_LEN + resp_len)) >= 0;
}

static void drop_client(conn_t* c)
{
    DT_TcpServer_DropClient(c->sock);
    c->connected = false;
    c->rx_len    = 0;
    if (s_stats.clients) s_stats.clients--;
}

static void poll_conn(conn_t* c)
{
    bool has_client = DT_TcpServer_Poll(c->sock);
    if (has_client != c->connected) {
        c->connected = has_client;
        c->rx_len    = 0;
        c->last_ms   = millis();
        if (has_client) {
            s_stats.clients++;
            s_stats.connects++;
#if DT_MB_KEEPALIVE_S
            setSn_KPALVTR((uint8_t)c->sock, (uint8_t)(DT_MB_KEEPALIVE_S / 5));  // 單位 5 秒
#endif
        } else if (s_stats.clients) {
            s_stats.clients--;
        }
    }
    if (!has_client) return;

    int n = DT_Tcp_Recv(c->sock, c->rx + c->rx_len, (uint16_t)(DT_MB_ADU_MAX - c->rx_len));
    if (n > 0) {
        c->rx_len += (uint16_t)n;
        c->last_ms = millis();
    }

    // 逐筆處理緩衝區內完整的 ADU
    while (c->rx_len >= DT_MB_MBAP_LEN) {
        DT_MbMbap_t hdr;
        if (!DT_Mb_MbapParse(c->rx, c->rx_len, &hdr)) {
            s_stats.frame_errors++;
            drop_client(c);
            return;
        }
        uint16_t need = 6 + hdr.len;
        if (c->rx_len < need) break;            // 等待剩下的分段
        if (!handle_adu(c, &hdr)) { drop_client(c); return; }
        c->rx_len -= need;
        memmove(c->rx, c->rx + need, c->rx_len);
    }

#if DT_MB_SERVER_IDLE_MS
    if (millis() - c->last_ms >= DT_MB_SERVER_IDLE_MS) {
        s_stats.idle_drops++;
        drop_client(c);
    }
#endif
}

/* 連線數超過上限時，踢掉閒置最久的連線 */
static void evict_idlest(void)
{
    while (s_stats.clients > DT_MB_SERVER_MAX_CONN) {
        conn_t* victim = 0;
        uint32_t   now    = millis();
        for (int i = 0; i < DT_MB_SERVER_SOCKS; i++) {
            conn_t* c = &s_conn[i];
            if (c->connected && (!victim || now - c->last_ms > now - victim->last_ms)) victim = c;
        }
        if (!victim) break;
        s_stats.evictions++;
        drop_client(victim);
    }
}

void DT_MbServer_Loop(void)
{
    if (s_port == 0) return;
    check_failsafe();                           // 斷網時也要偵測通訊中斷
    if (!DT_Net_IsReady()) {                    // 斷線：關閉所有 socket，恢復後重開
        close_all();
        return;
    }
    for (int i = 0; i < DT_MB_SERVER_SOCKS; i++) {
        conn_t* c = &s_conn[i];
        if (c->sock < 0) {
            c->sock = DT_TcpServer_Begin(s_port);
            if (c->sock < 0) { c->sock = -1; continue; }   // 下次 poll 再試
            c->connected = false;
            c->rx_len    = 0;
        }
        poll_conn(c);
    }
    evict_idlest();
}
