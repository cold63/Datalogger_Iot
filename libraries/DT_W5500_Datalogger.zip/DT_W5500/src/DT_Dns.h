/**
 * @file DT_Dns.h
 * @brief Blocking DNS A-record resolver (uses reserved socket DT_SOCK_DNS).
 */

#ifndef _DT_DNS_H_
#define _DT_DNS_H_

#include "DT_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Resolve host to IPv4 using the current DNS server.
 *        A dotted-decimal string is parsed directly without a query.
 * @return DT_OK, DT_ERR_NOT_READY, DT_ERR_DNS or DT_ERR_TIMEOUT
 */
int DT_Dns_Resolve(const char* host, uint8_t out_ip[4]);

/** @brief Same as DT_Dns_Resolve() with an explicit DNS server. */
int DT_Dns_ResolveWith(const uint8_t dns_server[4], const char* host, uint8_t out_ip[4]);

#ifdef __cplusplus
}
#endif

#endif /* _DT_DNS_H_ */
