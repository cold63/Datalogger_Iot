/**
 * @file DT_Types.h
 * @brief Common types and error codes for DT_W5500.
 */

#ifndef _DT_TYPES_H_
#define _DT_TYPES_H_

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Return codes. All errors are negative. */
typedef enum {
    DT_OK               = 0,
    DT_ERR              = -1,   // generic failure
    DT_ERR_PARAM        = -2,   // invalid argument
    DT_ERR_CHIP         = -3,   // W5500 not detected
    DT_ERR_NO_LINK      = -4,   // Ethernet cable unplugged
    DT_ERR_NOT_READY    = -5,   // network not ready (no IP)
    DT_ERR_TIMEOUT      = -6,
    DT_ERR_NO_SOCKET    = -7,   // no free hardware socket
    DT_ERR_SOCKET       = -8,   // socket operation failed
    DT_ERR_DNS          = -9,   // name resolution failed
    DT_ERR_CONNECT      = -10,  // TCP connect failed
    DT_ERR_TLS          = -11,  // TLS setup / handshake failed
    DT_ERR_MQTT         = -12,
    DT_ERR_HTTP         = -13,  // malformed HTTP response
    DT_ERR_NO_MEM       = -14,
    DT_ERR_CLOSED       = -15,  // peer closed connection
    DT_ERR_URL          = -16,  // malformed URL
    DT_ERR_MODBUS       = -17,  // malformed Modbus response (TID/UID/FC/length mismatch)
    DT_ERR_BUSY         = -18,  // previous request still in progress
    DT_ERR_MB_EXCEPTION = -100  // Modbus exception response: DT_ERR_MB_EXCEPTION - exception code
} DT_Err_t;

/** @brief W5500 wiring. */
typedef struct {
    uint8_t sclk;
    uint8_t miso;
    uint8_t mosi;
    uint8_t cs;
    uint8_t rst;
} DT_Pins_t;

/** @brief Network configuration (same layout as ioLibrary wiz_NetInfo). */
typedef struct {
    uint8_t mac[6];
    uint8_t ip[4];
    uint8_t sn[4];
    uint8_t gw[4];
    uint8_t dns[4];
    uint8_t dhcp;               // 1 = static, 2 = DHCP (NETINFO_STATIC / NETINFO_DHCP)
} DT_NetInfo_t;

#define DT_NETINFO_STATIC   1
#define DT_NETINFO_DHCP     2

/** @brief Returns a short text for a DT_Err_t value. */
const char* DT_ErrName(int err);

#ifdef __cplusplus
}
#endif

#endif /* _DT_TYPES_H_ */
