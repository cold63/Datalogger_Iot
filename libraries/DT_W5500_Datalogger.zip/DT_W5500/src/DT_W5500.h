/**
 * @file DT_W5500.h
 * @brief DT_W5500 umbrella header.
 *
 * Modules:
 *   DT_Core  - chip init, SPI HAL, net registers, socket pool, utilities
 *   DT_Net   - link monitor, DHCP / static IP, auto recovery
 *   DT_Dns   - name resolution
 *   DT_Tcp   - TCP client / server
 *   DT_Udp   - UDP
 *   DT_Tls   - TLS client (MbedTLS)
 *   DT_Mqtt  - MQTT client over TCP / TLS
 *   DT_Http  - HTTP / HTTPS client
 *   DT_Mb*   - Modbus TCP server / client / polling / storage (see DT_Modbus.h)
 * Native ioLibrary API: #include <DT_W5500_Raw.h>
 */

#ifndef _DT_W5500_H_
#define _DT_W5500_H_

#define DT_W5500_VERSION "1.1.0"

#include "DT_Config.h"
#include "DT_Types.h"
#include "DT_Core.h"
#include "DT_Net.h"
#include "DT_Dns.h"
#include "DT_Tcp.h"
#include "DT_Udp.h"
#include "DT_Tls.h"
#include "DT_Mqtt.h"
#include "DT_Http.h"
#include "DT_Modbus.h"

#endif /* _DT_W5500_H_ */
