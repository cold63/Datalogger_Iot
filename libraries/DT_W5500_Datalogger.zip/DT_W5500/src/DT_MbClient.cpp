/**
 * @file DT_MbClient.cpp
 * @brief Modbus TCP Client 非阻塞狀態機。
 *
 *   IDLE ──排入請求──> PENDING ──未連線──> CONNECTING ──> 送出 ──> WAIT_RESP ──> 完成回呼 ──> IDLE
 *   連線使用 ioLibrary 非阻塞 connect，避免 DT_Tcp_ConnectIp() 最多 10 s 的阻塞
 */

#include <string.h>
#include "DT_Internal.h"        // ioLibrary socket / connect_W5x00 / getSn_SR
#include "DT_Core.h"
#include "DT_Net.h"
#include "DT_Tcp.h"
#include "DT_MbClient.h"

typedef enum {
    ST_IDLE = 0,
    ST_PENDING,         // 已排入，等待 poll 處理
    ST_CONNECTING,      // 非阻塞連線中
    ST_WAIT_RESP        // 已送出，等待回應
} client_state_t;

static client_state_t s_state = ST_IDLE;
static int      s_sock     = -1;
static uint8_t  s_ip[4];
static uint16_t s_port     = 0;     // 0 = 未設定目標
static uint8_t  s_unit_id  = 1;
static uint16_t s_tid      = 0;
static bool     s_failed   = false; // 上次連線失敗
static uint32_t s_fail_ms  = 0;
static uint32_t s_start_ms = 0;     // 目前階段開始時間
static DT_MbClientCb_t    s_cb = 0;
static DT_MbClientStats_t s_stats;

/* 進行中的請求 */
static uint8_t  s_req[DT_MB_PDU_MAX];
static uint16_t s_req_len  = 0;
static uint16_t s_req_addr = 0;
static uint16_t s_req_qty  = 0;

/* 回應 */
static uint8_t  s_rx[DT_MB_ADU_MAX];
static uint16_t s_rx_len = 0;
static uint16_t s_regs[DT_MB_MAX_READ_REGS];

/* ---------------------------------------------------------------------------
 * 連線管理
 * ------------------------------------------------------------------------- */
static void close_socket(void)
{
    if (s_sock >= 0) DT_Tcp_Close(s_sock);
    s_sock = -1;
}

static void mark_connect_failed(void)
{
    close_socket();
    s_failed  = true;
    s_fail_ms = millis();
}

/* 開始非阻塞連線，回傳 DT_OK 或錯誤碼 */
static int start_connect(void)
{
    int sn = DT_Socket_Alloc();
    if (sn < 0) return DT_ERR_NO_SOCKET;
    if (socket((uint8_t)sn, Sn_MR_TCP, DT_Socket_LocalPort(), SF_IO_NONBLOCK | SF_TCP_NODELAY) != sn) {
        DT_Socket_Free(sn);
        return DT_ERR_NO_SOCKET;
    }
    int8_t r = connect_W5x00((uint8_t)sn, s_ip, s_port);
    if (r != SOCK_BUSY && r != SOCK_OK) {
        DT_Socket_Free(sn);
        return DT_ERR_CONNECT;
    }
    s_sock = sn;
    return DT_OK;
}

/* 檢查連線進度：1 = 已連線，0 = 連線中，負值 = 失敗 */
static int check_connect(void)
{
    uint8_t sn = (uint8_t)s_sock;
    uint8_t sr = getSn_SR(sn);
    if (sr == SOCK_ESTABLISHED) {
        uint8_t mode = SOCK_IO_BLOCK;           // 與 DT_Tcp 一致：連線後改回阻塞式 IO
        ctlsocket(sn, CS_SET_IOMODE, &mode);    // (send 小封包很快；recv 只在有資料時呼叫)
        return 1;
    }
    if (sr == SOCK_CLOSED || (getSn_IR(sn) & Sn_IR_TIMEOUT)) {
        setSn_IR(sn, Sn_IR_TIMEOUT);
        return DT_ERR_CONNECT;
    }
    if (millis() - s_start_ms >= DT_MB_CLIENT_CONNECT_MS) return DT_ERR_TIMEOUT;
    return 0;
}

/* ---------------------------------------------------------------------------
 * 請求完成
 * ------------------------------------------------------------------------- */
static void finish(int result)
{
    DT_MbClientResult_t r;
    uint16_t pdu_len = s_rx_len > DT_MB_MBAP_LEN ? s_rx_len - DT_MB_MBAP_LEN : 0;
    const uint8_t* pdu = s_rx + DT_MB_MBAP_LEN;

    // 檢查回應內容並取出資料
    if (result == DT_OK) {
        uint8_t fc = s_req[0];
        if (pdu[0] & 0x80) {
            result = (pdu_len >= 2) ? DT_ERR_MB_EXCEPTION - pdu[1] : DT_ERR_MODBUS;
        } else if (fc == DT_MB_FC_READ_COILS || fc == DT_MB_FC_READ_DISCRETE) {
            uint8_t bytes = (uint8_t)((s_req_qty + 7) / 8);
            if (pdu_len != 2 + bytes || pdu[1] != bytes) result = DT_ERR_MODBUS;
        } else if (fc == DT_MB_FC_READ_HOLDING || fc == DT_MB_FC_READ_INPUT) {
            if (pdu_len != 2 + s_req_qty * 2 || pdu[1] != s_req_qty * 2) result = DT_ERR_MODBUS;
            else for (uint16_t i = 0; i < s_req_qty; i++) s_regs[i] = DT_Mb_GetU16(pdu + 2 + i * 2);
        } else {                                // FC05/06/15/16：回應前 5 bytes 與請求相同
            if (pdu_len != 5 || memcmp(pdu, s_req, 5) != 0) result = DT_ERR_MODBUS;
        }
        if (result == DT_ERR_MODBUS) close_socket();
    }

    if (result == DT_OK) s_stats.ok++;
    else                 s_stats.errors++;
    s_stats.last_error = result;
    s_state = ST_IDLE;

    r.fc     = s_req[0];
    r.addr   = s_req_addr;
    r.qty    = s_req_qty;
    r.result = result;
    r.regs   = s_regs;
    r.bits   = pdu + 2;
    if (s_cb) s_cb(&r);
}

static void send_request(void)
{
    uint8_t tx[DT_MB_ADU_MAX];
    s_tid++;
    DT_Mb_MbapBuild(tx, s_tid, s_unit_id, s_req_len);
    memcpy(tx + DT_MB_MBAP_LEN, s_req, s_req_len);
    while (DT_Tcp_Recv(s_sock, s_rx, sizeof(s_rx)) > 0) { }    // 丟棄殘留資料
    s_rx_len = 0;
    if (DT_Tcp_Send(s_sock, tx, (uint16_t)(DT_MB_MBAP_LEN + s_req_len)) < 0) {
        close_socket();
        finish(DT_ERR_CLOSED);
        return;
    }
    s_state    = ST_WAIT_RESP;
    s_start_ms = millis();
}

/* 收回應，回傳 true 表示已完成 (成功或失敗) */
static bool poll_response(void)
{
    int n = DT_Tcp_Recv(s_sock, s_rx + s_rx_len, (uint16_t)(sizeof(s_rx) - s_rx_len));
    if (n < 0) { close_socket(); finish(DT_ERR_CLOSED); return true; }
    s_rx_len += (uint16_t)n;

    if (s_rx_len >= DT_MB_MBAP_LEN) {
        DT_MbMbap_t hdr;
        if (!DT_Mb_MbapParse(s_rx, s_rx_len, &hdr) || hdr.tid != s_tid || hdr.uid != s_unit_id) {
            close_socket();                     // 狀態不明，斷線重來以免收到錯位的回應
            finish(DT_ERR_MODBUS);
            return true;
        }
        if (s_rx_len >= 6 + hdr.len) {
            if ((s_rx[DT_MB_MBAP_LEN] & 0x7F) != s_req[0]) { close_socket(); finish(DT_ERR_MODBUS); }
            else finish(DT_OK);
            return true;
        }
    }
    if (millis() - s_start_ms >= DT_MB_CLIENT_TIMEOUT_MS) {
        close_socket();
        finish(DT_ERR_TIMEOUT);
        return true;
    }
    return false;
}

void DT_MbClient_Loop(void)
{
    if (s_state == ST_IDLE) {
        // 閒置時順便回收已被對方關閉的連線
        if (s_sock >= 0 && !DT_Tcp_IsConnected(s_sock)) close_socket();
        return;
    }
    if (!DT_Net_IsReady()) {
        close_socket();
        finish(DT_ERR_NOT_READY);
        return;
    }

    switch (s_state) {
    case ST_PENDING:
        if (s_sock >= 0 && DT_Tcp_IsConnected(s_sock)) { send_request(); break; }
        close_socket();
        if (s_failed && millis() - s_fail_ms < DT_MB_CLIENT_RETRY_MS) { finish(DT_ERR_CONNECT); break; }
        {
            int r = start_connect();
            if (r != DT_OK) { mark_connect_failed(); finish(r); break; }
        }
        s_state    = ST_CONNECTING;
        s_start_ms = millis();
        break;

    case ST_CONNECTING: {
        int r = check_connect();
        if (r == 1) { s_failed = false; send_request(); }
        else if (r < 0) { mark_connect_failed(); finish(r == DT_ERR_TIMEOUT ? DT_ERR_TIMEOUT : DT_ERR_CONNECT); }
        break;
    }

    case ST_WAIT_RESP:
        poll_response();
        break;

    default:
        break;
    }
}

/* ---------------------------------------------------------------------------
 * 公開 API
 * ------------------------------------------------------------------------- */
void DT_MbClient_Close(void)
{
    close_socket();
    s_failed = false;
    if (s_state != ST_IDLE) finish(DT_ERR_CLOSED);
}

void DT_MbClient_SetTarget(const uint8_t ip[4], uint16_t port, uint8_t unit_id)
{
    if (s_sock >= 0 && (memcmp(s_ip, ip, 4) != 0 || s_port != port)) DT_MbClient_Close();
    memcpy(s_ip, ip, 4);
    s_port    = port;
    s_unit_id = unit_id;
    s_failed  = false;
}

void DT_MbClient_SetCallback(DT_MbClientCb_t cb) { s_cb = cb; }
bool DT_MbClient_Busy(void)                      { return s_state != ST_IDLE; }

bool DT_MbClient_Bit(const DT_MbClientResult_t* r, uint16_t i)
{
    return i < r->qty && ((r->bits[i >> 3] >> (i & 7)) & 1);
}

void DT_MbClient_GetStats(DT_MbClientStats_t* st)
{
    if (!st) return;
    *st = s_stats;
    st->connected = s_sock >= 0 && s_state != ST_CONNECTING && DT_Tcp_IsConnected(s_sock);
}

/* 排入請求 (PDU 已放在 s_req) */
static int submit(uint16_t len, uint16_t addr, uint16_t qty)
{
    if (s_port == 0) return DT_ERR_NOT_READY;
    s_req_len  = len;
    s_req_addr = addr;
    s_req_qty  = qty;
    s_rx_len   = 0;
    s_state    = ST_PENDING;
    return DT_OK;
}

static int read_req(uint8_t fc, uint16_t addr, uint16_t qty, uint16_t max)
{
    if (s_state != ST_IDLE) return DT_ERR_BUSY;
    if (qty < 1 || qty > max) return DT_ERR_PARAM;
    s_req[0] = fc;
    DT_Mb_PutU16(s_req + 1, addr);
    DT_Mb_PutU16(s_req + 3, qty);
    return submit(5, addr, qty);
}

int DT_MbClient_ReadCoils(uint16_t addr, uint16_t qty)    { return read_req(DT_MB_FC_READ_COILS, addr, qty, DT_MB_MAX_READ_BITS); }
int DT_MbClient_ReadDiscrete(uint16_t addr, uint16_t qty) { return read_req(DT_MB_FC_READ_DISCRETE, addr, qty, DT_MB_MAX_READ_BITS); }
int DT_MbClient_ReadHolding(uint16_t addr, uint16_t qty)  { return read_req(DT_MB_FC_READ_HOLDING, addr, qty, DT_MB_MAX_READ_REGS); }
int DT_MbClient_ReadInput(uint16_t addr, uint16_t qty)    { return read_req(DT_MB_FC_READ_INPUT, addr, qty, DT_MB_MAX_READ_REGS); }

int DT_MbClient_WriteCoil(uint16_t addr, bool val)
{
    if (s_state != ST_IDLE) return DT_ERR_BUSY;
    s_req[0] = DT_MB_FC_WRITE_COIL;
    DT_Mb_PutU16(s_req + 1, addr);
    DT_Mb_PutU16(s_req + 3, val ? 0xFF00 : 0x0000);
    return submit(5, addr, 1);
}

int DT_MbClient_WriteRegister(uint16_t addr, uint16_t val)
{
    if (s_state != ST_IDLE) return DT_ERR_BUSY;
    s_req[0] = DT_MB_FC_WRITE_REGISTER;
    DT_Mb_PutU16(s_req + 1, addr);
    DT_Mb_PutU16(s_req + 3, val);
    return submit(5, addr, 1);
}

int DT_MbClient_WriteCoils(uint16_t addr, uint16_t qty, const bool* vals)
{
    if (s_state != ST_IDLE) return DT_ERR_BUSY;
    if (!vals || qty < 1 || qty > DT_MB_MAX_WRITE_BITS) return DT_ERR_PARAM;
    uint8_t bytes = (uint8_t)((qty + 7) / 8);
    s_req[0] = DT_MB_FC_WRITE_COILS;
    DT_Mb_PutU16(s_req + 1, addr);
    DT_Mb_PutU16(s_req + 3, qty);
    s_req[5] = bytes;
    memset(s_req + 6, 0, bytes);
    for (uint16_t i = 0; i < qty; i++)
        if (vals[i]) s_req[6 + (i >> 3)] |= (uint8_t)(1 << (i & 7));
    return submit((uint16_t)(6 + bytes), addr, qty);
}

int DT_MbClient_WriteRegisters(uint16_t addr, uint16_t qty, const uint16_t* vals)
{
    if (s_state != ST_IDLE) return DT_ERR_BUSY;
    if (!vals || qty < 1 || qty > DT_MB_MAX_WRITE_REGS) return DT_ERR_PARAM;
    s_req[0] = DT_MB_FC_WRITE_REGISTERS;
    DT_Mb_PutU16(s_req + 1, addr);
    DT_Mb_PutU16(s_req + 3, qty);
    s_req[5] = (uint8_t)(qty * 2);
    for (uint16_t i = 0; i < qty; i++) DT_Mb_PutU16(s_req + 6 + i * 2, vals[i]);
    return submit((uint16_t)(6 + qty * 2), addr, qty);
}
