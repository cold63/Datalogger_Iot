/**
 * @file DT_Net.h
 * @brief Non-blocking network manager: link monitor, DHCP / static IP, auto recovery.
 *
 * 使用方式：setup() 中呼叫 DT_Net_BeginDhcp() 或 DT_Net_BeginStatic()，
 * loop() 中持續呼叫 DT_Net_Loop()。網線拔除或 DHCP 失敗時會自動重試。
 */

#ifndef _DT_NET_H_
#define _DT_NET_H_

#include "DT_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    DT_NET_IDLE = 0,        // DT_Net_Begin*() not called yet
    DT_NET_LINK_DOWN,       // waiting for Ethernet cable
    DT_NET_DHCP,            // DHCP in progress
    DT_NET_READY,           // IP configured, network usable
    DT_NET_FAIL             // DHCP failed, waiting DT_NET_RETRY_MS before retry
} DT_NetState_t;

typedef void (*DT_NetEventCb_t)(DT_NetState_t state);

/** @brief Start in DHCP mode. Call after DT_W5500_Begin(). */
int DT_Net_BeginDhcp(const uint8_t mac[6]);

/** @brief Start with a static configuration. dns may be NULL (defaults to 8.8.8.8). */
int DT_Net_BeginStatic(const uint8_t mac[6], const uint8_t ip[4], const uint8_t sn[4],
                       const uint8_t gw[4], const uint8_t dns[4]);

/** @brief Run the state machine. Call from loop() as often as possible. */
void DT_Net_Loop(void);

/** @brief Blocking helper: runs DT_Net_Loop() until READY or timeout. */
int DT_Net_WaitReady(uint32_t timeout_ms);

DT_NetState_t DT_Net_GetState(void);
bool          DT_Net_IsReady(void);
const char*   DT_Net_StateName(DT_NetState_t state);

/** @brief Called on every state change (from inside DT_Net_Loop()). */
void DT_Net_SetEventCallback(DT_NetEventCb_t cb);

void DT_Net_GetLocalIp(uint8_t ip[4]);
void DT_Net_SetDnsServer(const uint8_t dns[4]);   // override DHCP-provided DNS
void DT_Net_GetDnsServer(uint8_t dns[4]);         // DNS server currently in use

#ifdef __cplusplus
}
#endif

#endif /* _DT_NET_H_ */
