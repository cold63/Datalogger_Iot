/**
 * @file DT_Tcp.h
 * @brief TCP client / server on W5500 hardware sockets.
 *
 * 所有函式以 socket 編號 (handle) 操作；handle >= 0 為有效，負值為 DT_Err_t。
 */

#ifndef _DT_TCP_H_
#define _DT_TCP_H_

#include "DT_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ===== Client ===== */

/** @brief Resolve host and connect. @return socket handle or DT_Err_t */
int DT_Tcp_Connect(const char* host, uint16_t port);

/** @brief Connect to an IP address. @return socket handle or DT_Err_t */
int DT_Tcp_ConnectIp(const uint8_t ip[4], uint16_t port);

/* ===== Data (client and server) ===== */

/** @brief Send all bytes (blocks until queued). @return len or DT_Err_t */
int  DT_Tcp_Send(int sock, const uint8_t* data, uint16_t len);
int  DT_Tcp_SendStr(int sock, const char* str);

/** @brief Bytes waiting in the receive buffer. */
int  DT_Tcp_Available(int sock);

/** @brief Non-blocking read. @return bytes read (0 if none) or DT_Err_t */
int  DT_Tcp_Recv(int sock, uint8_t* buf, uint16_t len);

/** @brief Read until len bytes or timeout. @return bytes read or DT_Err_t if closed with nothing read */
int  DT_Tcp_RecvTimeout(int sock, uint8_t* buf, uint16_t len, uint32_t timeout_ms);

/** @brief true while established, or peer closed but unread data remains. */
bool DT_Tcp_IsConnected(int sock);

void DT_Tcp_GetRemote(int sock, uint8_t ip[4], uint16_t* port);

/** @brief Disconnect, close and release the socket. */
void DT_Tcp_Close(int sock);

/* ===== Server (one client per socket) ===== */

/** @brief Open a listening socket. @return socket handle or DT_Err_t */
int  DT_TcpServer_Begin(uint16_t port);

/**
 * @brief Maintain the server socket; re-listens after the client leaves.
 * @return true when a client is connected
 */
bool DT_TcpServer_Poll(int sock);

/** @brief Drop the current client and listen again. */
void DT_TcpServer_DropClient(int sock);

void DT_TcpServer_Stop(int sock);

#ifdef __cplusplus
}
#endif

#endif /* _DT_TCP_H_ */
