/**
 * @file DT_Udp.h
 * @brief UDP sockets.
 */

#ifndef _DT_UDP_H_
#define _DT_UDP_H_

#include "DT_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Open a UDP socket. local_port = 0 picks an ephemeral port. @return handle or DT_Err_t */
int  DT_Udp_Begin(uint16_t local_port);

/** @brief Send one datagram. @return len or DT_Err_t */
int  DT_Udp_SendTo(int sock, const uint8_t ip[4], uint16_t port, const uint8_t* data, uint16_t len);

/** @brief Resolve host then send. @return len or DT_Err_t */
int  DT_Udp_SendToHost(int sock, const char* host, uint16_t port, const uint8_t* data, uint16_t len);

/** @brief true if at least one datagram is waiting. */
bool DT_Udp_Available(int sock);

/**
 * @brief Non-blocking receive of one datagram.
 *        If buf is smaller than the datagram, the rest is returned by the next call.
 * @return bytes read (0 if none) or DT_Err_t
 */
int  DT_Udp_RecvFrom(int sock, uint8_t* buf, uint16_t len, uint8_t ip[4], uint16_t* port);

void DT_Udp_Close(int sock);

#ifdef __cplusplus
}
#endif

#endif /* _DT_UDP_H_ */
