/**
 * @file DT_MbServer.h
 * @brief Modbus TCP Server (Slave)，最多 DT_MB_SERVER_MAX_CONN 條同時連線。
 *
 * 使用方式：先以 DT_MbData_Begin() 設定資料表，再呼叫 DT_MbServer_Begin()，
 * loop() 中持續呼叫 DT_MbServer_Loop() (非阻塞)。
 *  - 網路斷線時自動關閉 socket，恢復後自動重新監聽
 *  - 連線滿時由備用 socket 接受新連線，並踢掉閒置最久的一條 (DT_MB_SERVER_SPARE)
 *  - TCP keepalive 偵測對方已消失的連線 (DT_MB_KEEPALIVE_S)
 *  - Unit ID 接受 unit_id、0 與 0xFF
 * 佔用 socket：DT_MB_SERVER_MAX_CONN + DT_MB_SERVER_SPARE (預設 3 個)。
 */

#ifndef _DT_MB_SERVER_H_
#define _DT_MB_SERVER_H_

#include "DT_MbCommon.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @brief 統計資料 */
typedef struct {
    uint8_t  clients;       // 目前連線數
    uint32_t connects;      // 累計連線次數
    uint32_t requests;      // 已處理請求數
    uint32_t exceptions;    // 回覆例外的次數
    uint32_t frame_errors;  // MBAP 不合法而斷線的次數
    uint32_t ignored;       // Unit ID 不符而未回應的次數
    uint32_t idle_drops;    // 閒置逾時斷線的次數
    uint32_t evictions;     // 連線滿時被踢掉的次數
} DT_MbStats_t;

/**
 * @brief 通訊狀態改變時呼叫
 * @param lost true = 超過設定時間沒收到請求 (應將輸出設為安全狀態)；false = 通訊恢復
 * 收到第一筆請求後才開始監控，開機時尚無 Master 不會觸發
 */
typedef void (*DT_MbFailsafeCb_t)(bool lost);

/** @brief 設定 port 與 Unit ID；實際監聽在網路 Ready 後由 DT_MbServer_Loop() 開啟 */
int  DT_MbServer_Begin(uint16_t port, uint8_t unit_id);
void DT_MbServer_Loop(void);
void DT_MbServer_Stop(void);
void DT_MbServer_GetStats(DT_MbStats_t* st);

/** @brief 通訊中斷保護：timeout_ms 內沒收到請求即呼叫 cb(true)，0 = 關閉 */
void DT_MbServer_SetFailsafe(uint32_t timeout_ms, DT_MbFailsafeCb_t cb);
bool DT_MbServer_CommLost(void);

#ifdef __cplusplus
}
#endif

#endif /* _DT_MB_SERVER_H_ */
