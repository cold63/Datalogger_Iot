/**
 * @file DT_MbSelfTest.cpp
 * @brief 以固定測試向量驗證 DT_MbPdu_Process()。
 *
 * 測試期間改用內部的測試資料表，結束後還原 sketch 的資料表與回呼。
 */

#include <stdio.h>
#include <string.h>
#include "DT_Config.h"
#include "DT_MbSelfTest.h"
#include "DT_MbPdu.h"
#include "DT_MbData.h"

/* 測試用資料表 (大小固定，與測試向量對應) */
#define TEST_COILS  64
#define TEST_DI     64
#define TEST_HR     100
#define TEST_IR     100
static uint8_t  t_coils[DT_MB_BITS_BYTES(TEST_COILS)];
static uint8_t  t_di[DT_MB_BITS_BYTES(TEST_DI)];
static uint16_t t_hr[TEST_HR];
static uint16_t t_ir[TEST_IR];

static DT_MbLogFn_t s_log;
static int s_fail;
static int s_total;

/* 送出 req，比對回應是否等於 expect */
static void check(const char* name, const uint8_t* req, uint16_t req_len,
                  const uint8_t* expect, uint16_t expect_len)
{
    uint8_t resp[DT_MB_PDU_MAX];
    char    line[96];
    int     n  = DT_MbPdu_Process(req, req_len, resp);
    bool    ok = (n == expect_len) && memcmp(resp, expect, expect_len) == 0;

    s_total++;
    if (!ok) s_fail++;
    snprintf(line, sizeof(line), "[TEST] %-28s %s", name, ok ? "PASS" : "FAIL");
    s_log(line);
    if (!ok) {
        int  pos = snprintf(line, sizeof(line), "       got(%d):", n);
        for (int i = 0; i < n && i < 16 && pos < (int)sizeof(line) - 4; i++)
            pos += snprintf(line + pos, sizeof(line) - pos, " %02X", resp[i]);
        s_log(line);
    }
}

/* 比對資料表的值 */
static void check_value(const char* name, uint32_t got, uint32_t expect)
{
    char line[96];
    bool ok = got == expect;
    s_total++;
    if (!ok) s_fail++;
    snprintf(line, sizeof(line), "[TEST] %-28s %s", name, ok ? "PASS" : "FAIL");
    s_log(line);
    if (!ok) {
        snprintf(line, sizeof(line), "       got %lu, expect %lu", (unsigned long)got, (unsigned long)expect);
        s_log(line);
    }
}

#define CHECK(name, req, exp) check(name, req, sizeof(req), exp, sizeof(exp))

/* 測試用寫入檢查：HR50 不可 > 1000；Coil60 不可設為 ON */
static uint8_t test_validate(DT_MbType_t type, uint16_t addr, uint16_t value)
{
    if (type == DT_MB_TYPE_HOLDING && addr == 50 && value > 1000) return DT_MB_EX_ILLEGAL_VALUE;
    if (type == DT_MB_TYPE_COIL && addr == 60 && value)           return DT_MB_EX_DEVICE_FAILURE;
    return 0;
}

int DT_MbSelfTest_Run(DT_MbLogFn_t log)
{
    char line[64];
    if (!log) return -1;
    s_log  = log;
    s_fail = 0;
    s_total = 0;

    // 保存 sketch 的設定，改用測試資料表
    DT_MbTables_t     saved_tables;
    DT_MbWriteCb_t    saved_write    = DT_MbData_GetWriteCb();
    DT_MbValidateCb_t saved_validate = DT_MbData_GetValidateCb();
    DT_MbData_GetTables(&saved_tables);
    DT_MbData_Begin(t_coils, TEST_COILS, t_di, TEST_DI, t_hr, TEST_HR, t_ir, TEST_IR);
    DT_MbData_SetWriteCb(0);
    DT_MbData_SetValidateCb(0);
    DT_MbData_Clear();
    s_log("[TEST] ===== DT_MbPdu self test =====");

    /* ---- FC06 / FC03 寫讀單一暫存器 ---- */
    { uint8_t q[] = {0x06, 0x00, 0x05, 0x12, 0x34}; uint8_t e[] = {0x06, 0x00, 0x05, 0x12, 0x34}; CHECK("FC06 write HR5", q, e); }
    check_value("HR5 value", DT_MbData_GetHr(5), 0x1234);
    { uint8_t q[] = {0x03, 0x00, 0x04, 0x00, 0x02}; uint8_t e[] = {0x03, 0x04, 0x00, 0x00, 0x12, 0x34}; CHECK("FC03 read HR4..5", q, e); }

    /* ---- FC16 / FC03 寫讀多個暫存器 ---- */
    { uint8_t q[] = {0x10, 0x00, 0x0A, 0x00, 0x02, 0x04, 0xAB, 0xCD, 0x00, 0x01};
      uint8_t e[] = {0x10, 0x00, 0x0A, 0x00, 0x02}; CHECK("FC16 write HR10..11", q, e); }
    { uint8_t q[] = {0x03, 0x00, 0x0A, 0x00, 0x02}; uint8_t e[] = {0x03, 0x04, 0xAB, 0xCD, 0x00, 0x01}; CHECK("FC03 read HR10..11", q, e); }

    /* ---- FC04 讀 Input Register ---- */
    DT_MbData_SetIr(0, 0xBEEF);
    { uint8_t q[] = {0x04, 0x00, 0x00, 0x00, 0x01}; uint8_t e[] = {0x04, 0x02, 0xBE, 0xEF}; CHECK("FC04 read IR0", q, e); }

    /* ---- FC05 / FC01 Coil ---- */
    { uint8_t q[] = {0x05, 0x00, 0x03, 0xFF, 0x00}; uint8_t e[] = {0x05, 0x00, 0x03, 0xFF, 0x00}; CHECK("FC05 coil3 ON", q, e); }
    { uint8_t q[] = {0x01, 0x00, 0x00, 0x00, 0x08}; uint8_t e[] = {0x01, 0x01, 0x08}; CHECK("FC01 read coil0..7", q, e); }
    { uint8_t q[] = {0x05, 0x00, 0x03, 0x00, 0x00}; uint8_t e[] = {0x05, 0x00, 0x03, 0x00, 0x00}; CHECK("FC05 coil3 OFF", q, e); }
    check_value("coil3 value", DT_MbData_GetCoil(3), 0);

    /* ---- FC15 位元打包邊界 (qty = 1 / 8 / 9) ---- */
    { uint8_t q[] = {0x0F, 0x00, 0x10, 0x00, 0x01, 0x01, 0x01}; uint8_t e[] = {0x0F, 0x00, 0x10, 0x00, 0x01}; CHECK("FC15 qty=1", q, e); }
    { uint8_t q[] = {0x0F, 0x00, 0x20, 0x00, 0x08, 0x01, 0xA5}; uint8_t e[] = {0x0F, 0x00, 0x20, 0x00, 0x08}; CHECK("FC15 qty=8", q, e); }
    { uint8_t q[] = {0x0F, 0x00, 0x30, 0x00, 0x09, 0x02, 0xFF, 0x01}; uint8_t e[] = {0x0F, 0x00, 0x30, 0x00, 0x09}; CHECK("FC15 qty=9", q, e); }
    { uint8_t q[] = {0x01, 0x00, 0x10, 0x00, 0x01}; uint8_t e[] = {0x01, 0x01, 0x01}; CHECK("FC01 read qty=1", q, e); }
    { uint8_t q[] = {0x01, 0x00, 0x20, 0x00, 0x08}; uint8_t e[] = {0x01, 0x01, 0xA5}; CHECK("FC01 read qty=8", q, e); }
    { uint8_t q[] = {0x01, 0x00, 0x30, 0x00, 0x0A}; uint8_t e[] = {0x01, 0x02, 0xFF, 0x01}; CHECK("FC01 read qty=10", q, e); }

    /* ---- FC02 Discrete Input ---- */
    DT_MbData_SetDi(1, true);
    DT_MbData_SetDi(9, true);
    { uint8_t q[] = {0x02, 0x00, 0x00, 0x00, 0x0A}; uint8_t e[] = {0x02, 0x02, 0x02, 0x02}; CHECK("FC02 read DI0..9", q, e); }

    /* ---- EX01 不支援的功能碼 ---- */
    { uint8_t q[] = {0x2B, 0x0E, 0x01, 0x00}; uint8_t e[] = {0xAB, 0x01}; CHECK("EX01 FC 0x2B", q, e); }
    { uint8_t q[] = {0x07}; uint8_t e[] = {0x87, 0x01}; CHECK("EX01 FC 0x07", q, e); }

    /* ---- EX02 位址超出範圍 ---- */
    { uint8_t q[] = {0x03, 0x00, TEST_HR - 1, 0x00, 0x02}; uint8_t e[] = {0x83, 0x02}; CHECK("EX02 FC03 past end", q, e); }
    { uint8_t q[] = {0x06, 0x00, TEST_HR, 0x00, 0x01}; uint8_t e[] = {0x86, 0x02}; CHECK("EX02 FC06 addr=size", q, e); }
    { uint8_t q[] = {0x01, 0xFF, 0xFF, 0x00, 0x02}; uint8_t e[] = {0x81, 0x02}; CHECK("EX02 FC01 addr overflow", q, e); }
    { uint8_t q[] = {0x05, 0x00, TEST_COILS, 0xFF, 0x00}; uint8_t e[] = {0x85, 0x02}; CHECK("EX02 FC05 addr=size", q, e); }

    /* ---- EX03 數量 / 值 / 長度錯誤 ---- */
    { uint8_t q[] = {0x03, 0x00, 0x00, 0x00, 0x00}; uint8_t e[] = {0x83, 0x03}; CHECK("EX03 FC03 qty=0", q, e); }
    { uint8_t q[] = {0x03, 0x00, 0x00, 0x00, 0x7E}; uint8_t e[] = {0x83, 0x03}; CHECK("EX03 FC03 qty=126", q, e); }
    { uint8_t q[] = {0x01, 0x00, 0x00, 0x07, 0xD1}; uint8_t e[] = {0x81, 0x03}; CHECK("EX03 FC01 qty=2001", q, e); }
    { uint8_t q[] = {0x05, 0x00, 0x00, 0x12, 0x34}; uint8_t e[] = {0x85, 0x03}; CHECK("EX03 FC05 value", q, e); }
    { uint8_t q[] = {0x0F, 0x00, 0x00, 0x00, 0x09, 0x01, 0xFF}; uint8_t e[] = {0x8F, 0x03}; CHECK("EX03 FC15 byte count", q, e); }
    { uint8_t q[] = {0x10, 0x00, 0x00, 0x00, 0x02, 0x04, 0x00, 0x01}; uint8_t e[] = {0x90, 0x03}; CHECK("EX03 FC16 short data", q, e); }
    { uint8_t q[] = {0x03, 0x00, 0x00}; uint8_t e[] = {0x83, 0x03}; CHECK("EX03 FC03 short PDU", q, e); }

    /* ---- 例外回應不可改動資料 ---- */
    check_value("HR0 unchanged", DT_MbData_GetHr(0), 0);

    /* ---- 寫入前檢查 (validate callback) ---- */
    DT_MbData_SetValidateCb(test_validate);
    { uint8_t q[] = {0x06, 0x00, 0x32, 0x01, 0xF4}; uint8_t e[] = {0x06, 0x00, 0x32, 0x01, 0xF4}; CHECK("VAL FC06 HR50=500 accept", q, e); }
    { uint8_t q[] = {0x06, 0x00, 0x32, 0x07, 0xD0}; uint8_t e[] = {0x86, 0x03}; CHECK("VAL FC06 HR50=2000 reject", q, e); }
    check_value("VAL HR50 still 500", DT_MbData_GetHr(50), 500);
    { uint8_t q[] = {0x10, 0x00, 0x31, 0x00, 0x03, 0x06, 0x00, 0x01, 0x07, 0xD0, 0x00, 0x03};
      uint8_t e[] = {0x90, 0x03}; CHECK("VAL FC16 one bad -> reject", q, e); }
    check_value("VAL FC16 none written", DT_MbData_GetHr(49) == 0 && DT_MbData_GetHr(51) == 0, 1);
    { uint8_t q[] = {0x05, 0x00, 0x3C, 0xFF, 0x00}; uint8_t e[] = {0x85, 0x04}; CHECK("VAL FC05 coil60 ON reject", q, e); }
    // Coil48..56 已被前面的 FC15 qty=9 設為 ON，這裡改用未寫過的 Coil57..63
    { uint8_t q[] = {0x0F, 0x00, 0x39, 0x00, 0x07, 0x01, 0x7F}; uint8_t e[] = {0x8F, 0x04}; CHECK("VAL FC15 coil57..63 reject", q, e); }
    check_value("VAL FC15 none written", DT_MbData_GetCoil(57), 0);
    DT_MbData_SetValidateCb(0);

    /* ---- FC22 遮罩寫入 (規範範例：0x12 AND 0xF2 OR 0x25 = 0x17) ---- */
    DT_MbData_SetHr(60, 0x0012);
    { uint8_t q[] = {0x16, 0x00, 0x3C, 0x00, 0xF2, 0x00, 0x25}; uint8_t e[] = {0x16, 0x00, 0x3C, 0x00, 0xF2, 0x00, 0x25}; CHECK("FC22 mask write HR60", q, e); }
    check_value("FC22 HR60 = 0x17", DT_MbData_GetHr(60), 0x17);

    /* ---- FC23 先寫後讀 ---- */
    { uint8_t q[] = {0x17, 0x00, 0x3C, 0x00, 0x03, 0x00, 0x3D, 0x00, 0x02, 0x04, 0x00, 0xFF, 0x00, 0xAA};
      uint8_t e[] = {0x17, 0x06, 0x00, 0x17, 0x00, 0xFF, 0x00, 0xAA}; CHECK("FC23 write 61..62 read 60..62", q, e); }
    { uint8_t q[] = {0x17, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x04, 0x00, 0x01, 0x00, 0x02};
      uint8_t e[] = {0x97, 0x03}; CHECK("EX03 FC23 byte count", q, e); }
    { uint8_t q[] = {0x17, 0x00, 0x00, 0x00, 0x01, 0x00, TEST_HR - 1, 0x00, 0x02, 0x04, 0x00, 0x01, 0x00, 0x02};
      uint8_t e[] = {0x97, 0x02}; CHECK("EX02 FC23 write past end", q, e); }

    /* ---- FC43 / MEI 14 裝置識別 ---- */
    {
        uint8_t resp[DT_MB_PDU_MAX];
        uint8_t q1[] = {0x2B, 0x0E, 0x04, 0x01};            // individual: ProductCode
        int n = DT_MbPdu_Process(q1, sizeof(q1), resp);
        size_t len = strlen(DT_MB_DEVID_PRODUCT_CODE);
        check_value("FC43 individual ProductCode",
                    n == (int)(9 + len) && resp[3] == 0x82 && resp[6] == 1 && resp[7] == 0x01 &&
                    resp[8] == len && memcmp(resp + 9, DT_MB_DEVID_PRODUCT_CODE, len) == 0, 1);
        uint8_t q2[] = {0x2B, 0x0E, 0x01, 0x00};            // basic stream: 0x00..0x02
        n = DT_MbPdu_Process(q2, sizeof(q2), resp);
        check_value("FC43 basic stream 3 objects", n > 7 && resp[6] == 3 && resp[4] == 0, 1);
        uint8_t q3[] = {0x2B, 0x0E, 0x02, 0x00};            // regular stream: 0x00..0x05
        n = DT_MbPdu_Process(q3, sizeof(q3), resp);
        check_value("FC43 regular stream 6 objects", n > 7 && resp[6] == 6, 1);
    }
    { uint8_t q[] = {0x2B, 0x0D, 0x01, 0x00}; uint8_t e[] = {0xAB, 0x01}; CHECK("EX01 FC43 MEI 0x0D", q, e); }
    { uint8_t q[] = {0x2B, 0x0E, 0x05, 0x00}; uint8_t e[] = {0xAB, 0x03}; CHECK("EX03 FC43 code 5", q, e); }
    { uint8_t q[] = {0x2B, 0x0E, 0x04, 0x09}; uint8_t e[] = {0xAB, 0x02}; CHECK("EX02 FC43 object 9", q, e); }

    /* ---- 32 位元 / float 排列 ---- */
    {
        uint16_t r[2];
        DT_Mb_U32ToRegs(0x11223344UL, r, DT_MB_ORDER_ABCD);
        check_value("U32 ABCD", r[0] == 0x1122 && r[1] == 0x3344, 1);
        DT_Mb_U32ToRegs(0x11223344UL, r, DT_MB_ORDER_CDAB);
        check_value("U32 CDAB", r[0] == 0x3344 && r[1] == 0x1122, 1);
        DT_Mb_U32ToRegs(0x11223344UL, r, DT_MB_ORDER_BADC);
        check_value("U32 BADC", r[0] == 0x2211 && r[1] == 0x4433, 1);
        DT_Mb_U32ToRegs(0x11223344UL, r, DT_MB_ORDER_DCBA);
        check_value("U32 DCBA", r[0] == 0x4433 && r[1] == 0x2211, 1);
        check_value("U32 DCBA round trip", DT_Mb_RegsToU32(r, DT_MB_ORDER_DCBA), 0x11223344UL);
        DT_Mb_FloatToRegs(1.0f, r, DT_MB_ORDER_ABCD);
        check_value("FLOAT 1.0 = 3F80 0000", r[0] == 0x3F80 && r[1] == 0x0000, 1);
        DT_MbData_SetIrFloat(30, -12.5f);
        check_value("FLOAT IR30 round trip", DT_MbData_GetIrFloat(30) == -12.5f, 1);
    }

    /* ---- MBAP 解析 ---- */
    {
        DT_MbMbap_t h;
        uint8_t ok_hdr[]  = {0x00, 0x01, 0x00, 0x00, 0x00, 0x06, 0x01};
        uint8_t bad_pid[] = {0x00, 0x01, 0x00, 0x01, 0x00, 0x06, 0x01};
        uint8_t bad_len[] = {0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01};
        check_value("MBAP valid", DT_Mb_MbapParse(ok_hdr, 7, &h) && h.tid == 1 && h.len == 6, 1);
        check_value("MBAP PID!=0 rejected", DT_Mb_MbapParse(bad_pid, 7, &h), 0);
        check_value("MBAP LEN=256 rejected", DT_Mb_MbapParse(bad_len, 7, &h), 0);
    }

    // 還原 sketch 的設定
    DT_MbData_SetTables(&saved_tables);
    DT_MbData_SetWriteCb(saved_write);
    DT_MbData_SetValidateCb(saved_validate);
    snprintf(line, sizeof(line), "[TEST] ===== %d/%d passed =====", s_total - s_fail, s_total);
    s_log(line);
    return s_fail;
}
