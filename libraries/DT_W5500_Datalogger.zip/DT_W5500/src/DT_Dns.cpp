/**
 * @file DT_Dns.cpp
 * @brief Minimal DNS client: builds an A query and walks the answer section
 *        (handles name compression and CNAME chains).
 */

#include "DT_Internal.h"
#include "DT_Core.h"
#include "DT_Net.h"
#include "DT_Dns.h"

#define DNS_PORT        53
#define DNS_BUF_SIZE    512

static uint8_t s_buf[DNS_BUF_SIZE];

static int build_query(uint16_t id, const char* host, uint8_t* buf, uint16_t size) {
    uint16_t n = 0;
    buf[n++] = id >> 8;  buf[n++] = id & 0xFF;
    buf[n++] = 0x01;     buf[n++] = 0x00;          // standard query, recursion desired
    buf[n++] = 0x00;     buf[n++] = 0x01;          // QDCOUNT = 1
    memset(&buf[n], 0, 6); n += 6;                 // AN/NS/AR = 0

    const char* p = host;
    while (*p) {
        const char* dot = strchr(p, '.');
        size_t seg = dot ? (size_t)(dot - p) : strlen(p);
        if (seg == 0 || seg > 63 || n + seg + 6 >= size) return -1;
        buf[n++] = (uint8_t)seg;
        memcpy(&buf[n], p, seg);
        n += seg;
        p += seg;
        if (*p == '.') p++;
    }
    buf[n++] = 0x00;
    buf[n++] = 0x00; buf[n++] = 0x01;              // QTYPE  = A
    buf[n++] = 0x00; buf[n++] = 0x01;              // QCLASS = IN
    return n;
}

// Skip an encoded name, return new position or -1
static int skip_name(const uint8_t* buf, int len, int pos) {
    while (pos < len) {
        uint8_t l = buf[pos];
        if (l == 0) return pos + 1;
        if ((l & 0xC0) == 0xC0) return (pos + 2 <= len) ? pos + 2 : -1;
        pos += l + 1;
    }
    return -1;
}

static int parse_response(const uint8_t* buf, int len, uint16_t id, uint8_t out_ip[4]) {
    if (len < 12) return DT_ERR_DNS;
    if (((buf[0] << 8) | buf[1]) != id) return DT_ERR_TIMEOUT;   // not our answer, keep waiting
    if (!(buf[2] & 0x80)) return DT_ERR_TIMEOUT;                 // not a response
    if ((buf[3] & 0x0F) != 0) return DT_ERR_DNS;                 // RCODE != NOERROR

    uint16_t qd = (buf[4] << 8) | buf[5];
    uint16_t an = (buf[6] << 8) | buf[7];
    int pos = 12;
    for (uint16_t i = 0; i < qd; i++) {
        pos = skip_name(buf, len, pos);
        if (pos < 0 || pos + 4 > len) return DT_ERR_DNS;
        pos += 4;
    }
    for (uint16_t i = 0; i < an; i++) {
        pos = skip_name(buf, len, pos);
        if (pos < 0 || pos + 10 > len) return DT_ERR_DNS;
        uint16_t type  = (buf[pos] << 8) | buf[pos + 1];
        uint16_t cls   = (buf[pos + 2] << 8) | buf[pos + 3];
        uint16_t rdlen = (buf[pos + 8] << 8) | buf[pos + 9];
        pos += 10;
        if (pos + rdlen > len) return DT_ERR_DNS;
        if (type == 1 && cls == 1 && rdlen == 4) {
            memcpy(out_ip, &buf[pos], 4);
            return DT_OK;
        }
        pos += rdlen;   // CNAME etc.: the A record follows in the same answer section
    }
    return DT_ERR_DNS;
}

int DT_Dns_ResolveWith(const uint8_t dns_server[4], const char* host, uint8_t out_ip[4]) {
    if (!dns_server || !host || !out_ip || !*host) return DT_ERR_PARAM;
    if (DT_StrToIp(host, out_ip)) return DT_OK;

    uint16_t id = (uint16_t)(micros() ^ (millis() << 4));
    uint8_t query[300];
    int qlen = build_query(id, host, query, sizeof(query));
    if (qlen < 0) return DT_ERR_PARAM;

    const uint8_t sn = DT_SOCK_DNS;
    if (socket(sn, Sn_MR_UDP, DT_Socket_LocalPort(), 0) != sn) return DT_ERR_SOCKET;

    int result = DT_ERR_TIMEOUT;

    for (int attempt = 0; attempt <= DT_DNS_RETRY && result == DT_ERR_TIMEOUT; attempt++) {
        if (sendto_W5x00(sn, query, (uint16_t)qlen, (uint8_t*)dns_server, DNS_PORT) < 0) {
            result = DT_ERR_SOCKET;
            break;
        }
        uint32_t start = millis();
        while (DT_Elapsed(start) < DT_DNS_TIMEOUT_MS) {
            if (getSn_RX_RSR(sn) > 0) {
                uint8_t from[4];
                uint16_t port;
                int32_t len = recvfrom_W5x00(sn, s_buf, sizeof(s_buf), from, &port);
                if (len > 0 && port == DNS_PORT) {
                    result = parse_response(s_buf, (int)len, id, out_ip);
                    if (result != DT_ERR_TIMEOUT) break;
                }
            }
            delay(5);
        }
    }
    close(sn);
    return result;
}

int DT_Dns_Resolve(const char* host, uint8_t out_ip[4]) {
    if (host && out_ip && DT_StrToIp(host, out_ip)) return DT_OK;
    if (!DT_Net_IsReady()) return DT_ERR_NOT_READY;
    uint8_t dns[4];
    DT_Net_GetDnsServer(dns);
    return DT_Dns_ResolveWith(dns, host, out_ip);
}
