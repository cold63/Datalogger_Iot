/**
 * @file DT_Net.cpp
 * @brief Network manager state machine.
 */

#include "DT_Internal.h"
#include "DT_Core.h"
#include "DT_Net.h"

extern "C" {
#include "utility/ioLibrary/Internet/DHCP/dhcp.h"
}

static DT_NetState_t   s_state = DT_NET_IDLE;
static DT_NetEventCb_t s_cb = NULL;
static bool            s_useDhcp = false;
static bool            s_dnsOverride = false;
static DT_NetInfo_t    s_static;              // static config (also holds MAC)
static uint8_t         s_dns[4] = {8, 8, 8, 8};
static uint8_t         s_dhcpBuf[548];

static uint32_t s_lastSecond = 0;
static uint32_t s_lastLinkCheck = 0;
static uint32_t s_failSince = 0;

static void set_state(DT_NetState_t st) {
    if (st == s_state) return;
    s_state = st;
    if (s_cb) s_cb(st);
}

/* ===== DHCP callbacks (replace ioLibrary defaults that soft-reset the chip) ===== */

static void dhcp_apply(void) {
    uint8_t ip[4], sn[4], gw[4], dns[4];
    getIPfromDHCP(ip);
    getSNfromDHCP(sn);
    getGWfromDHCP(gw);
    getDNSfromDHCP(dns);
    setSIPR(ip);
    setSUBR(sn);
    setGAR(gw);
    if (!s_dnsOverride && (dns[0] | dns[1] | dns[2] | dns[3])) memcpy(s_dns, dns, 4);
}

static void dhcp_conflict(void) {
    // ioLibrary already sent DHCPDECLINE and restarts discovery
}

static void start_dhcp(void) {
    setSHAR(s_static.mac);
    DHCP_init(DT_SOCK_DHCP, s_dhcpBuf);
    reg_dhcp_cbfunc(dhcp_apply, dhcp_apply, dhcp_conflict);
    s_lastSecond = millis();
    set_state(DT_NET_DHCP);
}

static void apply_static(void) {
    DT_W5500_SetNetInfo(&s_static);
    set_state(DT_NET_READY);
}

static void link_up_start(void) {
    if (s_useDhcp) start_dhcp();
    else apply_static();
}

/* ===== Public API ===== */

int DT_Net_BeginDhcp(const uint8_t mac[6]) {
    if (!mac) return DT_ERR_PARAM;
    memset(&s_static, 0, sizeof(s_static));
    memcpy(s_static.mac, mac, 6);
    s_static.dhcp = DT_NETINFO_DHCP;
    s_useDhcp = true;
    setSHAR((uint8_t*)mac);
    s_state = DT_NET_IDLE;
    set_state(DT_NET_LINK_DOWN);
    s_lastLinkCheck = millis() - DT_NET_LINK_CHECK_MS;   // check link on first loop
    return DT_OK;
}

int DT_Net_BeginStatic(const uint8_t mac[6], const uint8_t ip[4], const uint8_t sn[4],
                       const uint8_t gw[4], const uint8_t dns[4]) {
    if (!mac || !ip || !sn || !gw) return DT_ERR_PARAM;
    memcpy(s_static.mac, mac, 6);
    memcpy(s_static.ip, ip, 4);
    memcpy(s_static.sn, sn, 4);
    memcpy(s_static.gw, gw, 4);
    if (dns) memcpy(s_dns, dns, 4);
    memcpy(s_static.dns, s_dns, 4);
    s_static.dhcp = DT_NETINFO_STATIC;
    s_useDhcp = false;
    setSHAR((uint8_t*)mac);
    s_state = DT_NET_IDLE;
    set_state(DT_NET_LINK_DOWN);
    s_lastLinkCheck = millis() - DT_NET_LINK_CHECK_MS;
    return DT_OK;
}

void DT_Net_Loop(void) {
    if (s_state == DT_NET_IDLE) return;

    // DHCP needs a 1 second tick; catch up if the loop was blocked (e.g. TLS handshake)
    if (s_useDhcp) {
        while (DT_Elapsed(s_lastSecond) >= 1000) {
            s_lastSecond += 1000;
            DHCP_time_handler();
        }
    }

    // Link monitor
    if (DT_Elapsed(s_lastLinkCheck) >= DT_NET_LINK_CHECK_MS) {
        s_lastLinkCheck = millis();
        bool up = DT_W5500_IsLinkUp();
        if (!up && s_state != DT_NET_LINK_DOWN) {
            if (s_useDhcp) DHCP_stop();
            set_state(DT_NET_LINK_DOWN);
        } else if (up && s_state == DT_NET_LINK_DOWN) {
            link_up_start();
        }
    }

    switch (s_state) {
    case DT_NET_DHCP:
        switch (DHCP_run()) {
        case DHCP_IP_ASSIGN:
        case DHCP_IP_CHANGED:
        case DHCP_IP_LEASED:
            set_state(DT_NET_READY);
            break;
        case DHCP_FAILED:
            DHCP_stop();
            s_failSince = millis();
            set_state(DT_NET_FAIL);
            break;
        default:
            break;
        }
        break;

    case DT_NET_READY:
        if (s_useDhcp) {
            // keep the lease alive; a failed renewal falls back to discovery inside ioLibrary
            uint8_t r = DHCP_run();
            if (r == DHCP_FAILED) {
                DHCP_stop();
                s_failSince = millis();
                set_state(DT_NET_FAIL);
            }
        }
        break;

    case DT_NET_FAIL:
        if (DT_Elapsed(s_failSince) >= DT_NET_RETRY_MS) {
            if (DT_W5500_IsLinkUp()) link_up_start();
            else set_state(DT_NET_LINK_DOWN);
        }
        break;

    default:
        break;
    }
}

int DT_Net_WaitReady(uint32_t timeout_ms) {
    if (s_state == DT_NET_IDLE) return DT_ERR_NOT_READY;
    uint32_t start = millis();
    while (s_state != DT_NET_READY) {
        DT_Net_Loop();
        if (DT_Elapsed(start) >= timeout_ms) {
            return (s_state == DT_NET_LINK_DOWN) ? DT_ERR_NO_LINK : DT_ERR_TIMEOUT;
        }
        delay(10);
    }
    return DT_OK;
}

DT_NetState_t DT_Net_GetState(void) { return s_state; }
bool DT_Net_IsReady(void) { return s_state == DT_NET_READY; }

const char* DT_Net_StateName(DT_NetState_t state) {
    switch (state) {
    case DT_NET_IDLE:      return "IDLE";
    case DT_NET_LINK_DOWN: return "LINK_DOWN";
    case DT_NET_DHCP:      return "DHCP";
    case DT_NET_READY:     return "READY";
    case DT_NET_FAIL:      return "FAIL";
    default:               return "?";
    }
}

void DT_Net_SetEventCallback(DT_NetEventCb_t cb) { s_cb = cb; }

void DT_Net_GetLocalIp(uint8_t ip[4]) { getSIPR(ip); }

void DT_Net_SetDnsServer(const uint8_t dns[4]) {
    if (!dns) return;
    memcpy(s_dns, dns, 4);
    s_dnsOverride = true;
}

void DT_Net_GetDnsServer(uint8_t dns[4]) { memcpy(dns, s_dns, 4); }
