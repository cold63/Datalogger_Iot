/**
 * @file DT_MbPdu.cpp
 * @brief Modbus Server PDU 處理。
 *
 * 驗證順序依規範：功能碼 (EX01) → 長度/數量 (EX03) → 位址 (EX02) → 寫入前檢查。
 */

#include <string.h>
#include "DT_Config.h"
#include "DT_MbPdu.h"
#include "DT_MbData.h"

static int build_exception(uint8_t fc, uint8_t ex, uint8_t* resp)
{
    resp[0] = fc | 0x80;
    resp[1] = ex;
    return 2;
}

/* FC01 / FC02：讀取位元，回應 byte count + 打包資料 (LSB = 起始位址) */
static int read_bits(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t   fc   = req[0];
    DT_MbType_t type = (fc == DT_MB_FC_READ_COILS) ? DT_MB_TYPE_COIL : DT_MB_TYPE_DISCRETE;
    if (len != 5) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint16_t addr = DT_Mb_GetU16(req + 1);
    uint16_t qty  = DT_Mb_GetU16(req + 3);
    if (qty < 1 || qty > DT_MB_MAX_READ_BITS) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);
    if (!DT_MbData_InRange(type, addr, qty)) return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);

    uint8_t bytes = (uint8_t)((qty + 7) / 8);
    resp[0] = fc;
    resp[1] = bytes;
    for (uint8_t i = 0; i < bytes; i++) resp[2 + i] = 0;
    for (uint16_t i = 0; i < qty; i++) {
        bool v = (type == DT_MB_TYPE_COIL) ? DT_MbData_GetCoil(addr + i) : DT_MbData_GetDi(addr + i);
        if (v) resp[2 + (i >> 3)] |= (uint8_t)(1 << (i & 7));
    }
    return 2 + bytes;
}

/* FC03 / FC04：讀取暫存器 */
static int read_regs(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t   fc   = req[0];
    DT_MbType_t type = (fc == DT_MB_FC_READ_HOLDING) ? DT_MB_TYPE_HOLDING : DT_MB_TYPE_INPUT;
    if (len != 5) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint16_t addr = DT_Mb_GetU16(req + 1);
    uint16_t qty  = DT_Mb_GetU16(req + 3);
    if (qty < 1 || qty > DT_MB_MAX_READ_REGS) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);
    if (!DT_MbData_InRange(type, addr, qty)) return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);

    resp[0] = fc;
    resp[1] = (uint8_t)(qty * 2);
    for (uint16_t i = 0; i < qty; i++) {
        uint16_t v = (type == DT_MB_TYPE_HOLDING) ? DT_MbData_GetHr(addr + i) : DT_MbData_GetIr(addr + i);
        DT_Mb_PutU16(resp + 2 + i * 2, v);
    }
    return 2 + qty * 2;
}

/* FC05：寫單一 Coil，值只能是 0xFF00 (ON) 或 0x0000 (OFF)，回應 = 請求 echo */
static int write_single_coil(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t fc = req[0];
    if (len != 5) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint16_t addr = DT_Mb_GetU16(req + 1);
    uint16_t val  = DT_Mb_GetU16(req + 3);
    if (val != 0xFF00 && val != 0x0000) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);
    if (!DT_MbData_InRange(DT_MB_TYPE_COIL, addr, 1)) return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);
    uint8_t ex = DT_MbData_Validate(DT_MB_TYPE_COIL, addr, val == 0xFF00);
    if (ex) return build_exception(fc, ex, resp);

    DT_MbData_SetCoil(addr, val == 0xFF00);
    DT_MbData_NotifyWrite(DT_MB_TYPE_COIL, addr, 1);
    for (uint8_t i = 0; i < 5; i++) resp[i] = req[i];
    return 5;
}

/* FC06：寫單一 Holding Register，回應 = 請求 echo */
static int write_single_reg(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t fc = req[0];
    if (len != 5) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint16_t addr = DT_Mb_GetU16(req + 1);
    if (!DT_MbData_InRange(DT_MB_TYPE_HOLDING, addr, 1)) return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);
    uint8_t ex = DT_MbData_Validate(DT_MB_TYPE_HOLDING, addr, DT_Mb_GetU16(req + 3));
    if (ex) return build_exception(fc, ex, resp);

    DT_MbData_SetHr(addr, DT_Mb_GetU16(req + 3));
    DT_MbData_NotifyWrite(DT_MB_TYPE_HOLDING, addr, 1);
    for (uint8_t i = 0; i < 5; i++) resp[i] = req[i];
    return 5;
}

/* FC15：寫多個 Coils，回應 = fc + addr + qty */
static int write_multi_coils(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t fc = req[0];
    if (len < 7) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint16_t addr  = DT_Mb_GetU16(req + 1);
    uint16_t qty   = DT_Mb_GetU16(req + 3);
    uint8_t  bytes = req[5];
    if (qty < 1 || qty > DT_MB_MAX_WRITE_BITS || bytes != (qty + 7) / 8 || len != 6 + bytes)
        return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);
    if (!DT_MbData_InRange(DT_MB_TYPE_COIL, addr, qty)) return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);
    for (uint16_t i = 0; i < qty; i++) {            // 全部通過才寫入
        uint8_t ex = DT_MbData_Validate(DT_MB_TYPE_COIL, addr + i, (req[6 + (i >> 3)] >> (i & 7)) & 1);
        if (ex) return build_exception(fc, ex, resp);
    }

    for (uint16_t i = 0; i < qty; i++)
        DT_MbData_SetCoil(addr + i, (req[6 + (i >> 3)] >> (i & 7)) & 1);
    DT_MbData_NotifyWrite(DT_MB_TYPE_COIL, addr, qty);
    for (uint8_t i = 0; i < 5; i++) resp[i] = req[i];
    return 5;
}

/* FC16：寫多個 Holding Registers，回應 = fc + addr + qty */
static int write_multi_regs(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t fc = req[0];
    if (len < 8) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint16_t addr  = DT_Mb_GetU16(req + 1);
    uint16_t qty   = DT_Mb_GetU16(req + 3);
    uint8_t  bytes = req[5];
    if (qty < 1 || qty > DT_MB_MAX_WRITE_REGS || bytes != qty * 2 || len != 6 + bytes)
        return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);
    if (!DT_MbData_InRange(DT_MB_TYPE_HOLDING, addr, qty)) return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);
    for (uint16_t i = 0; i < qty; i++) {            // 全部通過才寫入
        uint8_t ex = DT_MbData_Validate(DT_MB_TYPE_HOLDING, addr + i, DT_Mb_GetU16(req + 6 + i * 2));
        if (ex) return build_exception(fc, ex, resp);
    }

    for (uint16_t i = 0; i < qty; i++)
        DT_MbData_SetHr(addr + i, DT_Mb_GetU16(req + 6 + i * 2));
    DT_MbData_NotifyWrite(DT_MB_TYPE_HOLDING, addr, qty);
    for (uint8_t i = 0; i < 5; i++) resp[i] = req[i];
    return 5;
}

/* FC22：遮罩寫入 HR，新值 = (目前值 AND and_mask) OR (or_mask AND NOT and_mask)，回應 = 請求 echo */
static int mask_write_reg(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t fc = req[0];
    if (len != 7) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint16_t addr     = DT_Mb_GetU16(req + 1);
    uint16_t and_mask = DT_Mb_GetU16(req + 3);
    uint16_t or_mask  = DT_Mb_GetU16(req + 5);
    if (!DT_MbData_InRange(DT_MB_TYPE_HOLDING, addr, 1)) return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);

    uint16_t val = (uint16_t)((DT_MbData_GetHr(addr) & and_mask) | (or_mask & (uint16_t)~and_mask));
    uint8_t  ex  = DT_MbData_Validate(DT_MB_TYPE_HOLDING, addr, val);
    if (ex) return build_exception(fc, ex, resp);

    DT_MbData_SetHr(addr, val);
    DT_MbData_NotifyWrite(DT_MB_TYPE_HOLDING, addr, 1);
    for (uint8_t i = 0; i < 7; i++) resp[i] = req[i];
    return 7;
}

/* FC23：先寫入再讀取 HR，回應 = byte count + 讀取資料 */
static int read_write_regs(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t fc = req[0];
    if (len < 12) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint16_t raddr = DT_Mb_GetU16(req + 1);
    uint16_t rqty  = DT_Mb_GetU16(req + 3);
    uint16_t waddr = DT_Mb_GetU16(req + 5);
    uint16_t wqty  = DT_Mb_GetU16(req + 7);
    uint8_t  bytes = req[9];
    if (rqty < 1 || rqty > DT_MB_MAX_READ_REGS || wqty < 1 || wqty > DT_MB_MAX_RW_WRITE_REGS ||
        bytes != wqty * 2 || len != 10 + bytes)
        return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);
    if (!DT_MbData_InRange(DT_MB_TYPE_HOLDING, raddr, rqty) || !DT_MbData_InRange(DT_MB_TYPE_HOLDING, waddr, wqty))
        return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);
    for (uint16_t i = 0; i < wqty; i++) {           // 全部通過才寫入
        uint8_t ex = DT_MbData_Validate(DT_MB_TYPE_HOLDING, waddr + i, DT_Mb_GetU16(req + 10 + i * 2));
        if (ex) return build_exception(fc, ex, resp);
    }

    for (uint16_t i = 0; i < wqty; i++)
        DT_MbData_SetHr(waddr + i, DT_Mb_GetU16(req + 10 + i * 2));
    DT_MbData_NotifyWrite(DT_MB_TYPE_HOLDING, waddr, wqty);

    resp[0] = fc;
    resp[1] = (uint8_t)(rqty * 2);
    for (uint16_t i = 0; i < rqty; i++) DT_Mb_PutU16(resp + 2 + i * 2, DT_MbData_GetHr(raddr + i));
    return 2 + rqty * 2;
}

/* FC43 / MEI 14：讀取裝置識別 */
static const char* s_devid[DT_MB_DEVID_COUNT] = {
    DT_MB_DEVID_VENDOR, DT_MB_DEVID_PRODUCT_CODE, DT_MB_DEVID_REVISION,      // Basic   0x00..0x02
    DT_MB_DEVID_VENDOR_URL, DT_MB_DEVID_PRODUCT_NAME, DT_MB_DEVID_MODEL_NAME // Regular 0x03..0x05
};
#define DEVID_COUNT       DT_MB_DEVID_COUNT
#define DEVID_BASIC_LAST  0x02
#define DEVID_STR_MAX     48      // 單一物件最長字元數 (確保回應 <= 253 bytes)

int DT_MbPdu_SetDeviceId(uint8_t id, const char* str) {
    if (id >= DT_MB_DEVID_COUNT || !str) return DT_ERR_PARAM;
    s_devid[id] = str;
    return DT_OK;
}

static int read_device_id(const uint8_t* req, uint16_t len, uint8_t* resp)
{
    uint8_t fc = req[0];
    if (len < 2 || req[1] != DT_MB_MEI_DEVICE_ID) return build_exception(fc, DT_MB_EX_ILLEGAL_FUNCTION, resp);
    if (len != 4) return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);

    uint8_t code = req[2];
    uint8_t id   = req[3];
    uint8_t first, last;
    switch (code) {
    case 1:  first = id; last = DEVID_BASIC_LAST;  break;     // basic stream
    case 2:
    case 3:  first = id; last = DEVID_COUNT - 1;   break;     // regular / extended stream (無 extended 物件)
    case 4:                                                   // individual
        if (id >= DEVID_COUNT) return build_exception(fc, DT_MB_EX_ILLEGAL_ADDRESS, resp);
        first = last = id;
        break;
    default:
        return build_exception(fc, DT_MB_EX_ILLEGAL_VALUE, resp);
    }
    if (first > last) first = 0;                              // 規範：物件 id 不符時從 0 開始

    resp[0] = fc;
    resp[1] = DT_MB_MEI_DEVICE_ID;
    resp[2] = code;
    resp[3] = 0x82;             // conformity: regular + individual access
    resp[4] = 0x00;             // more follows
    resp[5] = 0x00;             // next object id
    resp[6] = 0;                // 物件數
    int pos = 7;
    for (uint8_t i = first; i <= last; i++) {
        size_t n = strlen(s_devid[i]);
        if (n > DEVID_STR_MAX) n = DEVID_STR_MAX;
        if (pos + 2 + (int)n > DT_MB_PDU_MAX) {    // 放不下：告知 Master 從 next object id 繼續讀
            resp[4] = 0xFF;
            resp[5] = i;
            break;
        }
        resp[6]++;
        resp[pos++] = i;
        resp[pos++] = (uint8_t)n;
        memcpy(resp + pos, s_devid[i], n);
        pos += (int)n;
    }
    return pos;
}

int DT_MbPdu_Process(const uint8_t* req, uint16_t req_len, uint8_t* resp)
{
    if (req_len < 1) return 0;
    switch (req[0]) {
    case DT_MB_FC_READ_COILS:
    case DT_MB_FC_READ_DISCRETE:   return read_bits(req, req_len, resp);
    case DT_MB_FC_READ_HOLDING:
    case DT_MB_FC_READ_INPUT:      return read_regs(req, req_len, resp);
    case DT_MB_FC_WRITE_COIL:      return write_single_coil(req, req_len, resp);
    case DT_MB_FC_WRITE_REGISTER:  return write_single_reg(req, req_len, resp);
    case DT_MB_FC_WRITE_COILS:     return write_multi_coils(req, req_len, resp);
    case DT_MB_FC_WRITE_REGISTERS: return write_multi_regs(req, req_len, resp);
    case DT_MB_FC_MASK_WRITE_REGISTER:  return mask_write_reg(req, req_len, resp);
    case DT_MB_FC_READ_WRITE_REGISTERS: return read_write_regs(req, req_len, resp);
    case DT_MB_FC_DEVICE_ID:            return read_device_id(req, req_len, resp);
    default:                    return build_exception(req[0] & 0x7F, DT_MB_EX_ILLEGAL_FUNCTION, resp);
    }
}
