/**
 * @file DT_Mqtt.cpp
 * @brief MQTT client state machine around Paho MQTTClient.
 */

#include "DT_Internal.h"
#include "DT_Net.h"
#include "DT_Tcp.h"
#include "DT_Tls.h"
#include "DT_Mqtt.h"

extern "C" {
#include "utility/ioLibrary/Internet/MQTT/MQTTClient.h"
}

#define READ_SETTLE_MS  1000    // time allowed to finish a packet whose bytes already arrived

// MQTTClient.c is compiled with its default MAX_MESSAGE_HANDLERS, so it cannot be raised here
static_assert(DT_MQTT_MAX_SUBS <= MAX_MESSAGE_HANDLERS, "DT_MQTT_MAX_SUBS exceeds Paho MAX_MESSAGE_HANDLERS");

typedef struct {
    bool    used;
    uint8_t qos;
    char    topic[DT_MQTT_TOPIC_MAX];
} MqttSub;

static DT_MqttConfig_t  s_cfg;
static char s_host[64], s_id[64], s_user[64], s_pass[128], s_willTopic[DT_MQTT_TOPIC_MAX], s_willMsg[128];

static DT_MqttState_t   s_state = DT_MQTT_IDLE;
static DT_MqttMsgCb_t   s_msgCb = NULL;
static DT_MqttStateCb_t s_stateCb = NULL;
static MqttSub          s_subs[DT_MQTT_MAX_SUBS];

static Network          s_net;
static MQTTClient       s_client;
static unsigned char    s_sendBuf[DT_MQTT_BUF_SIZE];
static unsigned char    s_readBuf[DT_MQTT_BUF_SIZE];

static int      s_handle = -1;      // TCP socket or TLS session
static bool     s_lost = false;
static int      s_lastErr = 0;
static uint32_t s_retrySince = 0;
static uint32_t s_pingSince = 0;
static bool     s_pingWait = false;

static void set_state(DT_MqttState_t st) {
    if (st == s_state) return;
    s_state = st;
    if (s_stateCb) s_stateCb(st);
}

static void copy_str(char* dst, size_t size, const char* src) {
    if (!src) { dst[0] = '\0'; return; }
    strncpy(dst, src, size - 1);
    dst[size - 1] = '\0';
}

/* ===== Transport ===== */

static int tr_available(void) {
    if (s_handle < 0) return 0;
    return s_cfg.use_tls ? DT_Tls_Available(s_handle) : DT_Tcp_Available(s_handle);
}

static int tr_recv(uint8_t* buf, uint16_t len) {
    return s_cfg.use_tls ? DT_Tls_Recv(s_handle, buf, len) : DT_Tcp_Recv(s_handle, buf, len);
}

static bool tr_connected(void) {
    if (s_handle < 0) return false;
    return s_cfg.use_tls ? DT_Tls_IsConnected(s_handle) : DT_Tcp_IsConnected(s_handle);
}

static void tr_close(void) {
    if (s_handle < 0) return;
    if (s_cfg.use_tls) DT_Tls_Close(s_handle);
    else DT_Tcp_Close(s_handle);
    s_handle = -1;
}

// Paho read hook: must return exactly len bytes for a complete packet section
static int net_read(Network* n, unsigned char* buf, int len, long timeout_ms) {
    (void)n;
    if (s_handle < 0) return -1;
    uint32_t timeout = (timeout_ms > 0) ? (uint32_t)timeout_ms : 0;
    // Bytes already queued mean a packet is arriving: allow it to complete,
    // otherwise a short yield timeout would split the packet and desync the stream.
    if (tr_available() > 0 && timeout < READ_SETTLE_MS) timeout = READ_SETTLE_MS;

    int got = 0;
    uint32_t start = millis();
    while (got < len) {
        int r = tr_recv(buf + got, (uint16_t)(len - got));
        if (r < 0) { s_lost = true; return got ? got : -1; }
        if (r > 0) { got += r; continue; }
        if (DT_Elapsed(start) >= timeout) break;
        delay(1);
    }
    return got;
}

static int net_write(Network* n, unsigned char* buf, int len, long timeout_ms) {
    (void)n; (void)timeout_ms;
    if (s_handle < 0) return -1;
    int r = s_cfg.use_tls ? DT_Tls_Send(s_handle, buf, (uint16_t)len)
                          : DT_Tcp_Send(s_handle, buf, (uint16_t)len);
    if (r < 0) { s_lost = true; return -1; }
    return r;
}

static void net_disconnect(Network* n) { (void)n; }

/* ===== Message dispatch ===== */

static void on_message(MessageData* md) {
    if (!s_msgCb) return;
    char topic[DT_MQTT_TOPIC_MAX];
    int tl = md->topicName->lenstring.len;
    if (tl > DT_MQTT_TOPIC_MAX - 1) tl = DT_MQTT_TOPIC_MAX - 1;
    memcpy(topic, md->topicName->lenstring.data, tl);
    topic[tl] = '\0';
    s_msgCb(topic, (const uint8_t*)md->message->payload, (uint16_t)md->message->payloadlen);
}

static int paho_subscribe(MqttSub* sub) {
    int rc = MQTTSubscribe(&s_client, sub->topic, (enum QoS)sub->qos, on_message);
    return (rc == 0) ? DT_OK : DT_ERR_MQTT;
}

/* ===== Connection ===== */

static void connection_lost(void) {
    tr_close();
    s_client.isconnected = 0;
    s_lost = false;
    s_pingWait = false;
    s_retrySince = millis();
    set_state(DT_MQTT_RETRY_WAIT);
}

static void do_connect(void) {
    s_handle = s_cfg.use_tls ? DT_Tls_Connect(s_cfg.host, s_cfg.port, s_cfg.tls)
                             : DT_Tcp_Connect(s_cfg.host, s_cfg.port);
    if (s_handle < 0) {
        s_lastErr = s_handle;
        s_handle = -1;
        connection_lost();
        return;
    }

    s_net.my_socket = 0;
    s_net.mqttread = net_read;
    s_net.mqttwrite = net_write;
    s_net.disconnect = net_disconnect;
    MQTTClientInit(&s_client, &s_net, s_cfg.cmd_timeout_ms,
                   s_sendBuf, sizeof(s_sendBuf), s_readBuf, sizeof(s_readBuf));
    for (int i = 0; i < MAX_MESSAGE_HANDLERS; i++) {
        s_client.messageHandlers[i].topicFilter = 0;
        s_client.messageHandlers[i].fp = NULL;
    }

    MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
    data.MQTTVersion = s_cfg.mqtt_version;
    data.clientID.cstring = s_id;
    data.keepAliveInterval = s_cfg.keepalive_s;
    data.cleansession = s_cfg.clean_session ? 1 : 0;
    if (s_user[0]) data.username.cstring = s_user;
    if (s_cfg.password) data.password.cstring = s_pass;
    if (s_willTopic[0]) {
        data.willFlag = 1;
        data.will.topicName.cstring = s_willTopic;
        data.will.message.cstring = s_willMsg;
        data.will.qos = s_cfg.will_qos;
        data.will.retained = s_cfg.will_retain ? 1 : 0;
    }

    s_lost = false;
    int rc = MQTTConnect(&s_client, &data);
    if (rc != 0) {
        s_lastErr = (rc > 0) ? rc : DT_ERR_MQTT;   // > 0: CONNACK refusal code
        connection_lost();
        return;
    }
    s_lastErr = DT_OK;
    s_pingWait = false;
    set_state(DT_MQTT_CONNECTED);

    for (int i = 0; i < DT_MQTT_MAX_SUBS; i++) {
        if (s_subs[i].used) paho_subscribe(&s_subs[i]);
    }
}

/* ===== Public API ===== */

void DT_Mqtt_ConfigDefault(DT_MqttConfig_t* cfg) {
    if (!cfg) return;
    memset(cfg, 0, sizeof(*cfg));
    cfg->port = 1883;
    cfg->client_id = "DT_W5500";
    cfg->keepalive_s = 60;
    cfg->clean_session = true;
    cfg->mqtt_version = 4;
    cfg->reconnect_ms = DT_MQTT_RECONNECT_MS;
    cfg->cmd_timeout_ms = DT_MQTT_CMD_TIMEOUT_MS;
}

int DT_Mqtt_Begin(const DT_MqttConfig_t* cfg) {
    if (!cfg || !cfg->host || !cfg->client_id || cfg->port == 0) return DT_ERR_PARAM;
    if (s_handle >= 0) tr_close();

    s_cfg = *cfg;
    copy_str(s_host, sizeof(s_host), cfg->host);
    copy_str(s_id, sizeof(s_id), cfg->client_id);
    copy_str(s_user, sizeof(s_user), cfg->username);
    copy_str(s_pass, sizeof(s_pass), cfg->password);
    copy_str(s_willTopic, sizeof(s_willTopic), cfg->will_topic);
    copy_str(s_willMsg, sizeof(s_willMsg), cfg->will_msg);
    s_cfg.host = s_host;
    s_cfg.client_id = s_id;
    if (s_cfg.mqtt_version != 3) s_cfg.mqtt_version = 4;
    if (s_cfg.reconnect_ms == 0) s_cfg.reconnect_ms = DT_MQTT_RECONNECT_MS;
    if (s_cfg.cmd_timeout_ms == 0) s_cfg.cmd_timeout_ms = DT_MQTT_CMD_TIMEOUT_MS;

    s_state = DT_MQTT_IDLE;
    set_state(DT_MQTT_WAIT_NET);
    return DT_OK;
}

void DT_Mqtt_SetCallback(DT_MqttMsgCb_t cb) { s_msgCb = cb; }
void DT_Mqtt_SetStateCallback(DT_MqttStateCb_t cb) { s_stateCb = cb; }

int DT_Mqtt_Subscribe(const char* topic, uint8_t qos) {
    if (!topic || !*topic || strlen(topic) >= DT_MQTT_TOPIC_MAX || qos > 2) return DT_ERR_PARAM;
    MqttSub* slot = NULL;
    for (int i = 0; i < DT_MQTT_MAX_SUBS; i++) {
        if (s_subs[i].used && strcmp(s_subs[i].topic, topic) == 0) return DT_OK;
        if (!s_subs[i].used && !slot) slot = &s_subs[i];
    }
    if (!slot) return DT_ERR_NO_MEM;
    slot->used = true;
    slot->qos = qos;
    copy_str(slot->topic, sizeof(slot->topic), topic);
    if (s_state == DT_MQTT_CONNECTED) return paho_subscribe(slot);
    return DT_OK;
}

int DT_Mqtt_Unsubscribe(const char* topic) {
    if (!topic) return DT_ERR_PARAM;
    for (int i = 0; i < DT_MQTT_MAX_SUBS; i++) {
        if (!s_subs[i].used || strcmp(s_subs[i].topic, topic) != 0) continue;
        int rc = DT_OK;
        if (s_state == DT_MQTT_CONNECTED) {
            rc = (MQTTUnsubscribe(&s_client, s_subs[i].topic) == 0) ? DT_OK : DT_ERR_MQTT;
        }
        // Paho does not clear the handler slot on unsubscribe
        for (int k = 0; k < MAX_MESSAGE_HANDLERS; k++) {
            if (s_client.messageHandlers[k].topicFilter == s_subs[i].topic) {
                s_client.messageHandlers[k].topicFilter = 0;
                s_client.messageHandlers[k].fp = NULL;
            }
        }
        s_subs[i].used = false;
        return rc;
    }
    return DT_ERR_PARAM;
}

int DT_Mqtt_Publish(const char* topic, const uint8_t* payload, uint16_t len, uint8_t qos, bool retain) {
    if (!topic || (!payload && len) || qos > 2) return DT_ERR_PARAM;
    if (s_state != DT_MQTT_CONNECTED) return DT_ERR_NOT_READY;
    MQTTMessage msg;
    msg.qos = (enum QoS)qos;
    msg.retained = retain ? 1 : 0;
    msg.dup = 0;
    msg.id = 0;
    msg.payload = (void*)payload;
    msg.payloadlen = len;
    int rc = MQTTPublish(&s_client, topic, &msg);
    if (s_lost) { connection_lost(); return DT_ERR_CLOSED; }
    return (rc == 0) ? DT_OK : DT_ERR_MQTT;
}

int DT_Mqtt_PublishStr(const char* topic, const char* msg) {
    if (!msg) return DT_ERR_PARAM;
    return DT_Mqtt_Publish(topic, (const uint8_t*)msg, (uint16_t)strlen(msg), 0, false);
}

void DT_Mqtt_Loop(void) {
    switch (s_state) {
    case DT_MQTT_IDLE:
        return;

    case DT_MQTT_WAIT_NET:
        if (DT_Net_IsReady()) set_state(DT_MQTT_CONNECTING);
        return;

    case DT_MQTT_CONNECTING:
        if (!DT_Net_IsReady()) { set_state(DT_MQTT_WAIT_NET); return; }
        do_connect();
        return;

    case DT_MQTT_RETRY_WAIT:
        if (DT_Elapsed(s_retrySince) >= s_cfg.reconnect_ms) {
            set_state(DT_Net_IsReady() ? DT_MQTT_CONNECTING : DT_MQTT_WAIT_NET);
        }
        return;

    case DT_MQTT_CONNECTED:
        break;
    }

    if (!DT_Net_IsReady() || !tr_connected() || s_lost) {
        if (s_lastErr == DT_OK) s_lastErr = DT_ERR_CLOSED;
        connection_lost();
        return;
    }

    // Only block in MQTTYield when bytes are waiting or a ping is due
    if (tr_available() > 0) {
        MQTTYield(&s_client, READ_SETTLE_MS);
    } else if (s_cfg.keepalive_s && TimerIsExpired(&s_client.ping_timer)) {
        MQTTYield(&s_client, 1);
    }
    if (s_lost) { connection_lost(); return; }

    // Paho never times out an unanswered PINGREQ; treat it as a dead link
    if (s_client.ping_outstanding) {
        if (!s_pingWait) { s_pingWait = true; s_pingSince = millis(); }
        else if (DT_Elapsed(s_pingSince) >= (uint32_t)s_cfg.keepalive_s * 1000UL) {
            s_lastErr = DT_ERR_TIMEOUT;
            connection_lost();
        }
    } else {
        s_pingWait = false;
    }
}

bool DT_Mqtt_IsConnected(void) { return s_state == DT_MQTT_CONNECTED; }
DT_MqttState_t DT_Mqtt_GetState(void) { return s_state; }

const char* DT_Mqtt_StateName(DT_MqttState_t state) {
    switch (state) {
    case DT_MQTT_IDLE:       return "IDLE";
    case DT_MQTT_WAIT_NET:   return "WAIT_NET";
    case DT_MQTT_CONNECTING: return "CONNECTING";
    case DT_MQTT_CONNECTED:  return "CONNECTED";
    case DT_MQTT_RETRY_WAIT: return "RETRY_WAIT";
    default:                 return "?";
    }
}

int DT_Mqtt_LastError(void) { return s_lastErr; }

void DT_Mqtt_Disconnect(void) {
    if (s_state == DT_MQTT_CONNECTED) MQTTDisconnect(&s_client);
    tr_close();
    s_client.isconnected = 0;
    set_state(DT_MQTT_IDLE);
}
