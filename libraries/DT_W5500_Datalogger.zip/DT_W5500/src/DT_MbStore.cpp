/**
 * @file DT_MbStore.cpp
 * @brief HR 設定值斷電保存 (AmebaD Preferences / DCT)。
 */

#include <Arduino.h>
#include <Preferences.h>
#include <string.h>
#include "DT_Config.h"
#include "DT_MbStore.h"
#include "DT_MbData.h"

#define STORE_NAMESPACE "dt_mb"
#define STORE_KEY       "hr"
#define STORE_CHECK_MS  500             // 檢查值是否改變的週期

typedef struct {
    uint16_t start;
    uint16_t count;
    uint16_t values[DT_MB_STORE_MAX_REGS];
} store_record_t;

static Preferences s_prefs;
static bool     s_ready       = false;
static uint16_t s_start       = 0;
static uint16_t s_count       = 0;
static uint16_t s_saved_crc   = 0;      // Flash 內資料的 CRC
static uint16_t s_pending_crc = 0;      // 最近一次看到的 CRC
static uint32_t s_change_ms   = 0;      // 值最後一次改變的時間
static uint32_t s_check_ms    = 0;
static uint32_t s_writes      = 0;

/* CRC16 (Modbus 多項式 0xA001)，只用來判斷值是否改變 */
static uint16_t crc16(const uint8_t* p, uint32_t len) {
    uint16_t crc = 0xFFFF;
    while (len--) {
        crc ^= *p++;
        for (int i = 0; i < 8; i++) crc = (crc & 1) ? (crc >> 1) ^ 0xA001 : crc >> 1;
    }
    return crc;
}

static size_t record_size(void) { return 4 + s_count * sizeof(uint16_t); }

static uint16_t current_crc(store_record_t* rec) {
    rec->start = s_start;
    rec->count = s_count;
    for (uint16_t i = 0; i < s_count; i++) rec->values[i] = DT_MbData_GetHr(s_start + i);
    return crc16((const uint8_t*)rec->values, s_count * sizeof(uint16_t));
}

int DT_MbStore_Begin(uint16_t hr_start, uint16_t hr_count) {
    if (hr_count == 0 || hr_count > DT_MB_STORE_MAX_REGS) return DT_ERR_PARAM;
    s_start = hr_start;
    s_count = hr_count;
    if (!s_ready) s_ready = s_prefs.begin(STORE_NAMESPACE, false);
    return s_ready ? DT_OK : DT_ERR;
}

int DT_MbStore_Load(void) {
    store_record_t rec;
    bool valid = false;
    if (s_ready && s_prefs.getBytesLength(STORE_KEY) == record_size()) {
        s_prefs.getBytes(STORE_KEY, &rec, record_size());
        valid = rec.start == s_start && rec.count == s_count;
    }
    if (valid) {
        for (uint16_t i = 0; i < s_count; i++) DT_MbData_SetHr(s_start + i, rec.values[i]);
        s_saved_crc = crc16((const uint8_t*)rec.values, s_count * sizeof(uint16_t));
    } else {
        s_saved_crc = current_crc(&rec);        // 視目前預設值為已保存，未改變就不寫入
    }
    s_pending_crc = s_saved_crc;
    return valid ? DT_OK : DT_ERR;
}

int DT_MbStore_Save(void) {
    if (!s_ready) return DT_ERR;
    store_record_t rec;
    uint16_t crc = current_crc(&rec);
    if (s_prefs.putBytes(STORE_KEY, &rec, record_size()) != record_size()) return DT_ERR;
    s_saved_crc   = crc;
    s_pending_crc = crc;
    s_writes++;
    return DT_OK;
}

bool DT_MbStore_Loop(void) {
    if (!s_ready || (uint32_t)(millis() - s_check_ms) < STORE_CHECK_MS) return false;
    s_check_ms = millis();

    store_record_t rec;
    uint16_t crc = current_crc(&rec);
    if (crc == s_saved_crc) { s_pending_crc = crc; return false; }
    if (crc != s_pending_crc) {                 // 值還在變動：重新計時
        s_pending_crc = crc;
        s_change_ms   = millis();
        return false;
    }
    if ((uint32_t)(millis() - s_change_ms) < DT_MB_STORE_DELAY_MS) return false;
    return DT_MbStore_Save() == DT_OK;
}

int DT_MbStore_Erase(void) {
    if (!s_ready) return DT_ERR;
    s_prefs.remove(STORE_KEY);
    s_writes++;
    return DT_OK;
}

uint32_t DT_MbStore_WriteCount(void) { return s_writes; }
