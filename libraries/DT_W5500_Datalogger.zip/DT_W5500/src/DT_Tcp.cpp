/**
 * @file DT_Tcp.cpp
 * @brief TCP wrapper over ioLibrary sockets.
 */

#include "DT_Internal.h"
#include "DT_Core.h"
#include "DT_Net.h"
#include "DT_Dns.h"
#include "DT_Tcp.h"

static uint16_t s_listenPort[DT_SOCK_APP_MAX];

static void set_blocking(uint8_t sn) {
    uint8_t mode = SOCK_IO_BLOCK;
    ctlsocket(sn, CS_SET_IOMODE, &mode);
}

int DT_Tcp_ConnectIp(const uint8_t ip[4], uint16_t port) {
    if (!ip || port == 0) return DT_ERR_PARAM;
    if (!DT_Net_IsReady()) return DT_ERR_NOT_READY;

    int sn = DT_Socket_Alloc();
    if (sn < 0) return sn;

    // Non-blocking connect so the timeout is ours, then switch back to blocking IO
    if (socket((uint8_t)sn, Sn_MR_TCP, DT_Socket_LocalPort(), SF_IO_NONBLOCK | SF_TCP_NODELAY) != sn) {
        DT_Socket_Free(sn);
        return DT_ERR_SOCKET;
    }
    int8_t r = connect_W5x00((uint8_t)sn, (uint8_t*)ip, port);
    if (r != SOCK_BUSY && r != SOCK_OK) {
        DT_Socket_Free(sn);
        return DT_ERR_CONNECT;
    }

    uint32_t start = millis();
    while (true) {
        uint8_t sr = getSn_SR((uint8_t)sn);
        if (sr == SOCK_ESTABLISHED) break;
        if (sr == SOCK_CLOSED || (getSn_IR((uint8_t)sn) & Sn_IR_TIMEOUT)) {
            setSn_IR((uint8_t)sn, Sn_IR_TIMEOUT);
            DT_Socket_Free(sn);
            return DT_ERR_CONNECT;
        }
        if (DT_Elapsed(start) >= DT_TCP_CONNECT_TIMEOUT_MS) {
            DT_Socket_Free(sn);
            return DT_ERR_TIMEOUT;
        }
        delay(2);
    }
    set_blocking((uint8_t)sn);
    s_listenPort[sn] = 0;
    return sn;
}

int DT_Tcp_Connect(const char* host, uint16_t port) {
    uint8_t ip[4];
    int r = DT_Dns_Resolve(host, ip);
    if (r != DT_OK) return r;
    return DT_Tcp_ConnectIp(ip, port);
}

int DT_Tcp_Send(int sock, const uint8_t* data, uint16_t len) {
    if (!DT_Socket_IsValid(sock) || (!data && len)) return DT_ERR_PARAM;
    uint16_t sent = 0;
    while (sent < len) {
        int32_t r = send((uint8_t)sock, (uint8_t*)data + sent, len - sent);
        if (r < 0) return DT_ERR_CLOSED;
        sent += (uint16_t)r;
    }
    return len;
}

int DT_Tcp_SendStr(int sock, const char* str) {
    if (!str) return DT_ERR_PARAM;
    return DT_Tcp_Send(sock, (const uint8_t*)str, (uint16_t)strlen(str));
}

int DT_Tcp_Available(int sock) {
    if (!DT_Socket_IsValid(sock)) return 0;
    return getSn_RX_RSR((uint8_t)sock);
}

int DT_Tcp_Recv(int sock, uint8_t* buf, uint16_t len) {
    if (!DT_Socket_IsValid(sock) || !buf) return DT_ERR_PARAM;
    uint16_t avail = getSn_RX_RSR((uint8_t)sock);
    if (avail == 0) {
        uint8_t sr = getSn_SR((uint8_t)sock);
        return (sr == SOCK_ESTABLISHED) ? 0 : DT_ERR_CLOSED;
    }
    if (len > avail) len = avail;
    int32_t r = recv((uint8_t)sock, buf, len);   // data is present, so this does not block
    return (r < 0) ? DT_ERR_CLOSED : (int)r;
}

int DT_Tcp_RecvTimeout(int sock, uint8_t* buf, uint16_t len, uint32_t timeout_ms) {
    uint16_t got = 0;
    uint32_t start = millis();
    while (got < len) {
        int r = DT_Tcp_Recv(sock, buf + got, len - got);
        if (r < 0) return got ? got : r;
        if (r > 0) { got += r; continue; }
        if (DT_Elapsed(start) >= timeout_ms) break;
        delay(1);
    }
    return got;
}

bool DT_Tcp_IsConnected(int sock) {
    if (!DT_Socket_IsValid(sock)) return false;
    uint8_t sr = getSn_SR((uint8_t)sock);
    if (sr == SOCK_ESTABLISHED) return true;
    return sr == SOCK_CLOSE_WAIT && getSn_RX_RSR((uint8_t)sock) > 0;
}

void DT_Tcp_GetRemote(int sock, uint8_t ip[4], uint16_t* port) {
    if (!DT_Socket_IsValid(sock)) return;
    if (ip) getSn_DIPR((uint8_t)sock, ip);
    if (port) *port = getSn_DPORT((uint8_t)sock);
}

// Graceful FIN with a bounded wait, then force close
static void graceful_close(uint8_t sn) {
    uint8_t sr = getSn_SR(sn);
    if (sr == SOCK_ESTABLISHED || sr == SOCK_CLOSE_WAIT) {
        setSn_CR(sn, Sn_CR_DISCON);
        while (getSn_CR(sn));
        uint32_t start = millis();
        while (getSn_SR(sn) != SOCK_CLOSED && DT_Elapsed(start) < 1000) delay(1);
    }
    close(sn);
}

void DT_Tcp_Close(int sock) {
    if (!DT_Socket_IsValid(sock)) return;
    graceful_close((uint8_t)sock);
    s_listenPort[sock] = 0;
    DT_Socket_Free(sock);
}

/* ===== Server ===== */

static bool start_listen(uint8_t sn, uint16_t port) {
    if (socket(sn, Sn_MR_TCP, port, SF_TCP_NODELAY) != sn) return false;
    return listen(sn) == SOCK_OK;
}

int DT_TcpServer_Begin(uint16_t port) {
    if (port == 0) return DT_ERR_PARAM;
    if (!DT_Net_IsReady()) return DT_ERR_NOT_READY;
    int sn = DT_Socket_Alloc();
    if (sn < 0) return sn;
    if (!start_listen((uint8_t)sn, port)) {
        DT_Socket_Free(sn);
        return DT_ERR_SOCKET;
    }
    s_listenPort[sn] = port;
    return sn;
}

bool DT_TcpServer_Poll(int sock) {
    if (!DT_Socket_IsValid(sock) || s_listenPort[sock] == 0) return false;
    uint8_t sn = (uint8_t)sock;
    switch (getSn_SR(sn)) {
    case SOCK_ESTABLISHED:
        if (getSn_IR(sn) & Sn_IR_CON) setSn_IR(sn, Sn_IR_CON);
        return true;
    case SOCK_CLOSE_WAIT:
        if (getSn_RX_RSR(sn) > 0) return true;   // let the sketch drain remaining data
        setSn_CR(sn, Sn_CR_DISCON);              // non-blocking; becomes CLOSED, then re-listen
        while (getSn_CR(sn));
        return false;
    case SOCK_LISTEN:
    case SOCK_SYNRECV:
        return false;
    case SOCK_CLOSED:
        start_listen(sn, s_listenPort[sock]);
        return false;
    default:                                     // FIN_WAIT, TIME_WAIT, ...
        return false;
    }
}

void DT_TcpServer_DropClient(int sock) {
    if (!DT_Socket_IsValid(sock) || s_listenPort[sock] == 0) return;
    graceful_close((uint8_t)sock);
    start_listen((uint8_t)sock, s_listenPort[sock]);
}

void DT_TcpServer_Stop(int sock) {
    DT_Tcp_Close(sock);
}
