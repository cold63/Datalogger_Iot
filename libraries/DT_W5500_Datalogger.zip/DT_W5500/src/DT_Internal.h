/**
 * @file DT_Internal.h
 * @brief Private header shared by DT_W5500 modules. Do not include from sketches.
 *
 * ioLibrary 的 socket.h 定義了 connect/sendto/recvfrom 等巨集與 close/send/recv
 * 等全域函式，只在 Library 內部使用，避免與 lwIP 或使用者程式碼衝突。
 */

#ifndef _DT_INTERNAL_H_
#define _DT_INTERNAL_H_

#include <Arduino.h>
#include "DT_Config.h"
#include "DT_Types.h"

extern "C" {
#include "utility/ioLibrary/Ethernet/wizchip_conf.h"
#include "utility/ioLibrary/Ethernet/socket.h"
}

/* Port layer used by patched ioLibrary sources (C linkage). */
extern "C" unsigned long DT_Port_Millis(void);
extern "C" void DT_Port_DelayMs(uint32_t ms);

/* Elapsed time helper, wrap-around safe. */
static inline uint32_t DT_Elapsed(uint32_t since) {
    return (uint32_t)millis() - since;
}

/* Socket owner bookkeeping (DT_Core.cpp). */
bool DT_Socket_IsValid(int sn);

#endif /* _DT_INTERNAL_H_ */
