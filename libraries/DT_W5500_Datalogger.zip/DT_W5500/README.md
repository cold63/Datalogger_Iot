# DT_W5500

RTL8720DF (AmebaD) + W5500 乙太網路 Arduino Library。C 語言風格 API，所有公開函式以 `DT_` 為前綴。

- 平台：Realtek AmebaD Arduino core 3.2.x（`architectures=AmebaD`）
- SPI：軟體 bit-bang SPI，腳位可在執行時指定
- 功能：DHCP / 靜態 IP、Link 偵測與自動恢復、DNS、TCP Client/Server、UDP、TLS、MQTT(S)、HTTP(S)
- 基礎：WIZnet ioLibrary_Driver（精簡版）、Paho MQTT Embedded C、AmebaD 內建 MbedTLS 2.4.0

## 安裝

把整個 `DT_W5500` 資料夾複製到 `Documents/Arduino/libraries/`，重新啟動 Arduino IDE。
範例在 **File → Examples → DT_W5500**。

arduino-cli：

```
arduino-cli compile -b realtek:AmebaD:DataloggerIot --library <path>/DT_W5500 <sketch>
```

## 接線（預設值，可在 `DT_Config.h` 修改或執行時傳入 `DT_Pins_t`）

| RTL8720DF | W5500 |
|---|---|
| 19 | SCLK |
| 16 | MISO |
| 17 | MOSI |
| 18 | CS |
| 11 | RST |

## 快速開始

```cpp
#include <DT_W5500.h>

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};

void onMsg(const char* topic, const uint8_t* payload, uint16_t len) {
    Serial.print(topic); Serial.print(": "); Serial.write(payload, len); Serial.println();
}

void setup() {
    Serial.begin(115200);
    DT_W5500_Begin(NULL);              // 預設腳位
    DT_Net_BeginDhcp(mac);

    DT_MqttConfig_t cfg;
    DT_Mqtt_ConfigDefault(&cfg);
    cfg.host = "broker.hivemq.com";
    cfg.client_id = "my_device";
    DT_Mqtt_Begin(&cfg);
    DT_Mqtt_SetCallback(onMsg);
    DT_Mqtt_Subscribe("my/topic", 0);
}

void loop() {
    DT_Net_Loop();                     // 網路管理 (必要)
    DT_Mqtt_Loop();                    // 有用 MQTT 才需要
}
```

## 模組與 API

所有回傳 `int` 的函式：`>= 0` 表示成功（handle、長度或 HTTP 狀態碼），負值為 `DT_Err_t`，可用 `DT_ErrName()` 轉成文字。

| 模組 | 主要函式 |
|---|---|
| Core | `DT_W5500_Begin` `DT_W5500_BeginEx` `DT_W5500_IsLinkUp` `DT_W5500_SetNetInfo/GetNetInfo` `DT_W5500_SetRetry` `DT_Socket_Alloc/Free` `DT_PrintNetInfo` |
| Net | `DT_Net_BeginDhcp` `DT_Net_BeginStatic` `DT_Net_Loop` `DT_Net_WaitReady` `DT_Net_IsReady` `DT_Net_SetEventCallback` |
| DNS | `DT_Dns_Resolve` `DT_Dns_ResolveWith` |
| TCP | `DT_Tcp_Connect` `DT_Tcp_Send` `DT_Tcp_Recv` `DT_Tcp_RecvTimeout` `DT_Tcp_IsConnected` `DT_Tcp_Close` `DT_TcpServer_Begin` `DT_TcpServer_Poll` |
| UDP | `DT_Udp_Begin` `DT_Udp_SendTo` `DT_Udp_SendToHost` `DT_Udp_RecvFrom` `DT_Udp_Close` |
| TLS | `DT_Tls_Connect` `DT_Tls_Send` `DT_Tls_Recv` `DT_Tls_RecvTimeout` `DT_Tls_Close` `DT_Tls_LastError` |
| MQTT | `DT_Mqtt_Begin` `DT_Mqtt_Loop` `DT_Mqtt_Subscribe` `DT_Mqtt_Publish` `DT_Mqtt_PublishStr` `DT_Mqtt_SetCallback` |
| HTTP | `DT_Http_Get` `DT_Http_Post` `DT_Http_Request`（支援 https、chunked、串流 callback） |
| Modbus TCP | `DT_MbData_Begin` `DT_MbServer_Begin/Loop` `DT_MbClient_*` `DT_MbPoll_Add/Loop` `DT_MbStore_*`（見下方「Modbus TCP」） |
| Raw | `#include <DT_W5500_Raw.h>` 後可直接使用 ioLibrary 原生 API |

詳細說明見各 `src/DT_*.h` 標頭檔註解。

HTTP Server 沒有獨立模組，範例 `examples/DT_HttpServer` 示範如何用 `DT_TcpServer_*` 實作狀態網頁、JSON API 與 LED 控制。

## Socket 配置

W5500 共 8 個硬體 socket：

| Socket | 用途 |
|---|---|
| 0–5 | 由 `DT_Socket_Alloc()` 動態配置給 TCP / UDP / TLS / MQTT / HTTP |
| 6 | DNS（保留） |
| 7 | DHCP（保留） |

每個 TLS 連線佔用一個 TCP socket；`DT_TLS_MAX_SESSIONS` 預設 2。

Modbus TCP Server 佔用 `DT_MB_SERVER_MAX_CONN + DT_MB_SERVER_SPARE` 個（預設 3），Client 連線期間佔用 1 個。

## Modbus TCP

Server (Slave) 與非阻塞 Client (Master)，全部在 `loop()` 中以非阻塞方式執行。

| 模組 | 功能 |
|---|---|
| `DT_MbData` | 資料表 (Coils / DI / HR / IR)，陣列由 sketch 宣告；寫入前檢查與寫入後回呼；32 位元 / float (ABCD/CDAB/BADC/DCBA) |
| `DT_MbServer` | FC01/02/03/04/05/06/15/16/22/23/43(MEI 14)；多連線、連線滿時踢掉閒置最久的一條、TCP keepalive、通訊中斷保護 (fail-safe) |
| `DT_MbClient` | 非阻塞請求 + 完成回呼；連線 3 秒逾時、失敗後 5 秒內不重試，不會拖住 Server |
| `DT_MbPoll` | 輪詢表：多台 Slave、各自週期，結果自動存入本機 IR / DI；離線偵測；單筆寫入佇列 |
| `DT_MbStore` | 一段 HR 斷電保存 (Preferences / DCT)，值穩定 3 秒才寫、沒變不寫 |
| `DT_MbSelfTest` | 板上自我測試 (不需網路) |

最小 Slave：

```cpp
#include <DT_W5500.h>

uint8_t  mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0x01};
uint8_t  coils[DT_MB_BITS_BYTES(16)], di[DT_MB_BITS_BYTES(16)];
uint16_t hr[50], ir[50];

void setup() {
    DT_MbData_Begin(coils, 16, di, 16, hr, 50, ir, 50);
    DT_W5500_Begin(NULL);
    DT_Net_BeginDhcp(mac);
    DT_MbServer_Begin(502, 1);
}

void loop() {
    DT_Net_Loop();
    DT_MbServer_Loop();
    DT_MbData_SetIr(0, analogRead(A0));    // 更新資料
}
```

範例：

| 範例 | 內容 |
|---|---|
| `DT_ModbusSlave` | 只有 Server：寫入檢查、fail-safe、設定保存、診斷暫存器 |
| `DT_ModbusMaster` | 只有 Client：輪詢多台 Slave、離線偵測、Serial 指令寫入 |
| `DT_ModbusTcp` | Server + Client 完整版：輪詢結果放進本機資料表、閘道轉寫、診斷 IR90..99、自我測試 |

錯誤碼沿用 `DT_Err_t`：`DT_ERR_MODBUS` (回應格式錯誤)、`DT_ERR_BUSY`；例外回應為 `DT_ERR_MB_EXCEPTION - 例外碼`，用 `DT_Mb_ExceptionCode()` 取出例外碼。

位址一律為 0-based 協定位址（GUI 工具的 40001 = HR0、30001 = IR0）。

**設定保存位置**：`DT_MbStore` 使用 Preferences (DCT，namespace `"dt_mb"`)，不直接寫 Flash 位址。AmebaD 的 0x100000~0x105FFF 已被 SDK 用於 UART / AP 設定、BLE 配對資料、WiFi 快速重連，請勿自行寫入。DCT 共 6 個 namespace，`DT_MbStore` 佔 1 個；單筆最多保存 64 個 HR。

**PC 測試工具** (`extras/modbus_tools/`，只用 Python 標準函式庫)：

- `mb_test_master.py <IP>`：自動測試板子的 Server (功能碼、例外、分段封包、多連線、寫入檢查、float、fail-safe…)；`--write-hr` / `--read-hr` 可手動讀寫
- `mb_sim_slave.py`：在 PC 模擬 Slave，測試板子的 Client；`--delay` `--exception` `--bad-tid` `--drop` 注入錯誤
- Windows 防火牆需允許 TCP 502 連入：`New-NetFirewallRule -DisplayName "Modbus TCP 502" -Direction Inbound -Protocol TCP -LocalPort 502 -Action Allow -Profile Private`

## 舊程式對照

| 舊程式 (w5500_driver / examples) | DT_W5500 |
|---|---|
| `w5500_driver_init(tx, rx)` | `DT_W5500_BeginEx(NULL, tx, rx)` / `DT_W5500_Begin(NULL)` |
| `ameba_w5500_*` HAL callbacks | 內部實作（不再公開） |
| `wizchip_setnetinfo()` | `DT_Net_BeginStatic()` 或 `DT_W5500_SetNetInfo()` |
| `DHCP_init` + `DHCP_run` + `DHCP_time_handler` | `DT_Net_BeginDhcp()` + `DT_Net_Loop()` |
| `wizphy_getphylink()` | `DT_W5500_IsLinkUp()` / `DT_Net_GetState()` |
| `simple_dns_query()` | `DT_Dns_Resolve()` |
| `socket` + `connect` + `send` / `recv` | `DT_Tcp_Connect` / `DT_Tcp_Send` / `DT_Tcp_Recv` |
| `sendto` / `recvfrom` | `DT_Udp_SendTo` / `DT_Udp_RecvFrom` |
| MbedTLS 橋接 + handshake 狀態 | `DT_Tls_Connect()` |
| MQTT 狀態機 + `MilliTimer_Handler` + `MQTTYield` | `DT_Mqtt_Begin()` + `DT_Mqtt_Loop()` |
| HTTPS 狀態機 | `DT_Http_Get()` / `DT_Http_Request()` |

## 對原始 ioLibrary 的修改

`src/utility/ioLibrary` 只保留 W5500、socket、DHCP、DNS、MQTT，並做了以下修補（皆以 `DT_W5500 patch` 註記）：

1. `wizchip_conf.h`：預設晶片由 W6300 改為 W5500（Library 中每個 .c 單獨編譯，無法依賴外部 define）。
2. `mqtt_interface.c`：`MilliTimer` 改用系統 `millis()`。原本需要 1ms 中斷遞增，若只在 `loop()` 中遞增，`MQTTConnect` 等阻塞呼叫中的逾時永遠不會到期。
3. `dhcp.c`：IP 衝突時原本忙等 `dhcp_tick_1s`，在單執行緒環境會卡死，改為實際延遲。

## 注意事項

- **TLS 憑證驗證**：`DT_TlsConfig_t.ca_cert` 為 NULL 時不驗證伺服器（僅加密）。正式產品請提供 Root CA；驗證需正確的系統時間。
- **TLS 亂數**：使用 AmebaD SDK 的 `rtw_get_random_bytes_f_rng`，不再使用 `rand()`。
- **阻塞時間**：`DT_Tcp_Connect`、`DT_Dns_Resolve`、`DT_Tls_Connect`、`DT_Http_*`、MQTT 連線為阻塞呼叫。Bit-bang SPI 下 TLS 握手約 10–30 秒。`DT_Net_Loop()` 會補算阻塞期間的 DHCP 秒數。
- **字串生命週期**：`DT_Mqtt_Begin()` 會複製 host / client_id / 帳密等字串；`cfg.tls` 指向的 `DT_TlsConfig_t` 與憑證字串須在連線期間保持有效（建議宣告為全域）。
- **與 WiFi 同時使用**：公開標頭不包含 ioLibrary 的 `socket.h`，不會與 lwIP 衝突；但 `DT_W5500_Raw.h` 會引入 `connect/sendto/recvfrom` 巨集，請勿與 WiFi 標頭放在同一檔案。
- **設定**：Arduino IDE 無法替 Library 傳入 `-D` 參數，請直接修改 `src/DT_Config.h`（Modbus 相關為 `DT_MB_*`；資料表大小由 sketch 決定，不在此設定）。
- **Preferences 相依**：`DT_MbStore` 使用 AmebaD 內建的 Preferences 程式庫，編譯時會一併編譯（不需另外安裝；未使用 Modbus 的程式碼會被 linker 移除）。

## 授權

- WIZnet ioLibrary_Driver：MIT（`src/utility/ioLibrary/LICENSE_ioLibrary.txt`）
- Paho MQTT Embedded C：EPL-1.0 / EDL-1.0（見各檔案標頭）
- DT_W5500 包裝層：見 `LICENSE`
