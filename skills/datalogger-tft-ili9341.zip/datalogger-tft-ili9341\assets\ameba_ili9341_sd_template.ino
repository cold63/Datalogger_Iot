/********************************************************************
 * 專案名稱：ameba_ili9341_sd_template
 * 說    明：Datalogger IoT TFT LCD 擴展板最小範本
 *           - AmebaILI9341 (硬體 SPI) 顯示數值
 *           - SdFat 軟體 SPI 每 10 秒附加一筆 CSV 到 SD 卡
 *
 * 硬    體：
 *   - 開發板:    Datalogger IoT (RTL8720DF / AmebaD)
 *   - 螢幕:      2.4吋 240x320 ILI9341 TFT
 *   - TFT_RESET: 14
 *   - TFT_DC:    5
 *   - TFT_CS:    SPI_SS
 *   - BL_PIN:    9 (背光控制, HIGH 開)
 *   - SD_CS:     11, SD_MOSI: 10, SD_MISO: 15, SD_SCK: 8 (軟體 SPI)
 ********************************************************************/

#include "SPI.h"
#include "AmebaILI9341.h"
#include "SdFat.h"

#if SPI_DRIVER_SELECT != 2  // 需在 SdFat/SdFatConfig.h 設定
#error SPI_DRIVER_SELECT must be two in SdFat/SdFatConfig.h
#endif

// ------------------- 硬體接腳定義 -------------------
#define TFT_RESET   14
#define TFT_DC      5
#define TFT_CS      SPI_SS
#define BL_PIN      9

const uint8_t SD_CS_PIN     = 11;
const uint8_t SOFT_MISO_PIN = 15;
const uint8_t SOFT_MOSI_PIN = 10;
const uint8_t SOFT_SCK_PIN  = 8;

// SD 卡軟體 SPI (硬體 SPI 已給 TFT 使用)
SoftSpiDriver<SOFT_MISO_PIN, SOFT_MOSI_PIN, SOFT_SCK_PIN> softSpi;
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, SHARED_SPI, SD_SCK_MHZ(0), &softSpi)

SdFat sd;
File file;
bool sd_ok = false;

// 建立 AmebaILI9341 物件
AmebaILI9341 tft = AmebaILI9341(TFT_CS, TFT_DC, TFT_RESET);

// ---------------- 全域變數 ----------------
float value = 0.0;
unsigned long last_update_time = 0;
unsigned long last_log_time = 0;

// ---------------- 副程式宣告 ----------------
void drawFrame();
void updateValue(float v);
void logToSd(float v);

/**************************************************************************/
/*!
    @brief  Arduino 主要設定函式
*/
/**************************************************************************/
void setup() {
    Serial.begin(115200);

    // 開啟背光
    pinMode(BL_PIN, OUTPUT);
    digitalWrite(BL_PIN, HIGH);

    // 初始化 TFT，橫向 320x240
    tft.begin();
    tft.setRotation(1);
    tft.fillScreen(ILI9341_BLACK);

    // 初始化 SD 卡，失敗不中斷顯示
    sd_ok = sd.begin(SD_CONFIG);
    Serial.println(sd_ok ? "SD card OK" : "Initialize SD card error");

    drawFrame();
    updateValue(value);
}

/**************************************************************************/
/*!
    @brief  Arduino 主迴圈函式
*/
/**************************************************************************/
void loop() {
    // 每秒更新顯示
    if (millis() - last_update_time >= 1000) {
        last_update_time = millis();
        value = 50.0 + 25.0 * sin(millis() / 10000.0);  // 模擬數值，替換成感測器讀值
        updateValue(value);
    }

    // 每 10 秒寫入 SD
    if (sd_ok && millis() - last_log_time >= 10000) {
        last_log_time = millis();
        logToSd(value);
    }
}

/**************************************************************************/
/*!
    @brief  繪製靜態框線與標題 (只在 setup 呼叫一次)
*/
/**************************************************************************/
void drawFrame() {
    tft.drawRectangle(5, 5, 310, 230, ILI9341_WHITE);

    tft.setCursor(20, 20);
    tft.setFontSize(3);
    tft.setForeground(ILI9341_CYAN);
    tft.print("Datalogger IoT");

    tft.setCursor(20, 80);
    tft.setFontSize(2);
    tft.setForeground(ILI9341_YELLOW);
    tft.print("Value:");

    tft.setCursor(20, 200);
    tft.setFontSize(1);
    tft.setForeground(sd_ok ? ILI9341_GREEN : ILI9341_RED);
    tft.print(sd_ok ? "SD: OK" : "SD: ERROR");
}

/**************************************************************************/
/*!
    @brief  更新數值區 (局部擦除後重畫，避免閃爍)
*/
/**************************************************************************/
void updateValue(float v) {
    char buf[12];
    dtostrf(v, 6, 1, buf);

    tft.fillRectangle(20, 110, 280, 40, ILI9341_BLACK);
    tft.setCursor(20, 110);
    tft.setFontSize(5);
    tft.setForeground(ILI9341_WHITE);
    tft.setBackground(ILI9341_BLACK);
    tft.print(buf);
}

/**************************************************************************/
/*!
    @brief  附加一筆 CSV 到 SD 卡 (millis, value)
*/
/**************************************************************************/
void logToSd(float v) {
    if (!file.open("log.csv", O_APPEND | O_RDWR | O_CREAT)) {
        Serial.println("open log.csv failed");
        return;
    }
    file.print(millis());
    file.print(',');
    file.println(v, 1);
    file.close();
}
