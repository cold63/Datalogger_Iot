/********************************************************************
 * 專案名稱：gfx_sd_template
 * 說    明：Datalogger IoT TFT LCD 擴展板最小範本 (GFX Library for Arduino)
 *           - Arduino_GFX + U8g2 中文字型顯示數值
 *           - SdFat 軟體 SPI 每 10 秒附加一筆 CSV 到 SD 卡
 *
 * 硬    體：
 *   - 開發板:    Datalogger IoT (RTL8720DF / AmebaD)
 *   - 螢幕:      2.4吋 240x320 ILI9341 TFT
 *   - TFT:       DC 5, CS 18, SCK 19, MOSI 17, RST 14 (Arduino_SWSPI)
 *   - GFX_BL:    9 (背光控制, HIGH 開)
 *   - SD_CS:     11, SD_MOSI: 10, SD_MISO: 15, SD_SCK: 8 (軟體 SPI)
 *
 * 函 式 庫：GFX Library for Arduino、U8g2、SdFat
 ********************************************************************/

#include <U8g2lib.h>
#include <Arduino_GFX_Library.h>
#include "SdFat.h"

#if SPI_DRIVER_SELECT != 2  // 需在 SdFat/SdFatConfig.h 設定
#error SPI_DRIVER_SELECT must be two in SdFat/SdFatConfig.h
#endif

// ------------------- 硬體接腳定義 -------------------
#define GFX_BL      9

const uint8_t SD_CS_PIN     = 11;
const uint8_t SOFT_MISO_PIN = 15;
const uint8_t SOFT_MOSI_PIN = 10;
const uint8_t SOFT_SCK_PIN  = 8;

// TFT：軟體 SPI 匯流排 + ILI9341，橫向 (rotation 1) 320x240
Arduino_DataBus *bus = new Arduino_SWSPI(5 /* DC */, 18 /* CS */, 19 /* SCK */, 17 /* MOSI */, GFX_NOT_DEFINED /* MISO */);
Arduino_GFX *gfx = new Arduino_ILI9341(bus, 14 /* RST */, 1 /* rotation */, false /* IPS */);

// SD 卡軟體 SPI
SoftSpiDriver<SOFT_MISO_PIN, SOFT_MOSI_PIN, SOFT_SCK_PIN> softSpi;
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, SHARED_SPI, SD_SCK_MHZ(0), &softSpi)

SdFat sd;
File file;
bool sd_ok = false;

// ---------------- 版面配置 ----------------
const int16_t HEADER_H = 30;    // 標題列高度
const int16_t VALUE_X  = 20;    // 數值起始 X
const int16_t VALUE_Y  = 145;   // 數值基線 Y (U8g2 字型的 setCursor y 是基線)

// ---------------- 全域變數 ----------------
float value = 0.0;
unsigned long last_update_time = 0;
unsigned long last_log_time = 0;

// ---------------- 副程式宣告 ----------------
void drawLayout();
void updateValue(float v);
void logToSd(float v);

/**************************************************************************/
/*!
    @brief  Arduino 主要設定函式
*/
/**************************************************************************/
void setup() {
    Serial.begin(115200);

    // 初始化 TFT
    if (!gfx->begin()) {
        Serial.println("gfx->begin() failed!");
    }
    gfx->fillScreen(RGB565_BLACK);
    gfx->setUTF8Print(true);                     // 啟用 UTF-8 才能顯示中文
    gfx->setFont(u8g2_font_unifont_h_chinese);   // 16px 中文字型

    // 開啟背光
    pinMode(GFX_BL, OUTPUT);
    digitalWrite(GFX_BL, HIGH);

    // 初始化 SD 卡，失敗不中斷顯示
    sd_ok = sd.begin(SD_CONFIG);
    Serial.println(sd_ok ? "SD card OK" : "Initialize SD card error");

    drawLayout();
    updateValue(value);
}

/**************************************************************************/
/*!
    @brief  Arduino 主迴圈函式
*/
/**************************************************************************/
void loop() {
    // 每秒更新顯示
    if (millis() - last_update_time >= 1000) {
        last_update_time = millis();
        value = 50.0 + 25.0 * sin(millis() / 10000.0);  // 模擬數值，替換成感測器讀值
        updateValue(value);
    }

    // 每 10 秒寫入 SD
    if (sd_ok && millis() - last_log_time >= 10000) {
        last_log_time = millis();
        logToSd(value);
    }
}

/**************************************************************************/
/*!
    @brief  繪製靜態版面 (只在 setup 呼叫一次)
*/
/**************************************************************************/
void drawLayout() {
    // 標題列
    gfx->setTextSize(1);
    gfx->setTextColor(RGB565_YELLOW);
    gfx->setCursor(8, HEADER_H - 8);
    gfx->print("環境監測");
    gfx->drawFastHLine(0, HEADER_H, gfx->width(), RGB565_WHITE);

    // 數值區外框與名稱
    gfx->drawRoundRect(10, 45, 300, 110, 8, RGB565_DARKGREY);
    gfx->setTextColor(RGB565_WHITE);
    gfx->setCursor(20, 70);
    gfx->print("數值：");

    // SD 狀態
    gfx->setTextColor(sd_ok ? RGB565_GREEN : RGB565_RED);
    gfx->setCursor(8, gfx->height() - 8);
    gfx->print(sd_ok ? "SD 卡：正常" : "SD 卡：錯誤");
}

/**************************************************************************/
/*!
    @brief  更新數值區 (U8g2 字型不會清除整個字串背景，需先 fillRect 擦除)
*/
/**************************************************************************/
void updateValue(float v) {
    char buf[12];
    dtostrf(v, 0, 1, buf);

    // 擦除範圍：基線往上 3 倍字高 (16px x 3)，往下留 6px 給下伸部
    gfx->fillRect(VALUE_X, VALUE_Y - 48, 280, 54, RGB565_BLACK);
    gfx->setTextSize(3);
    gfx->setTextColor(RGB565_CYAN);
    gfx->setCursor(VALUE_X, VALUE_Y);
    gfx->print(buf);
    gfx->setTextSize(1);
}

/**************************************************************************/
/*!
    @brief  附加一筆 CSV 到 SD 卡 (millis, value)
*/
/**************************************************************************/
void logToSd(float v) {
    if (!file.open("log.csv", O_APPEND | O_RDWR | O_CREAT)) {
        Serial.println("open log.csv failed");
        return;
    }
    file.print(millis());
    file.print(',');
    file.println(v, 1);
    file.close();
}
