﻿# 安裝 datalogger-tft-ili9341 skill 到指定的 Arduino 專案 (<專案>\.claude\skills\)
# 用法：
#   powershell -ExecutionPolicy Bypass -File <本腳本路徑> -Project <專案資料夾>
#   省略 -Project 時安裝到目前資料夾
# 來源：優先使用本腳本旁的 datalogger-tft-ili9341 資料夾，否則使用旁邊的 datalogger-tft-ili9341.zip
param(
    [string]$Project = (Get-Location).Path
)

$name = "datalogger-tft-ili9341"
if (-not (Test-Path $Project)) {
    Write-Error "找不到專案資料夾 $Project"
    exit 1
}

$src = Join-Path $PSScriptRoot $name
$tmp = $null
if (-not (Test-Path (Join-Path $src "SKILL.md"))) {
    $zip = Join-Path $PSScriptRoot "$name.zip"
    if (-not (Test-Path $zip)) {
        Write-Error "找不到 $src 或 $zip"
        exit 1
    }
    $tmp = Join-Path $env:TEMP "$name-install"
    if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
    Expand-Archive -Path $zip -DestinationPath $tmp -Force
    $src = Join-Path $tmp $name
}

$dest = Join-Path (Resolve-Path $Project) ".claude\skills\$name"
if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
Copy-Item -Recurse $src $dest

if ($tmp) { Remove-Item -Recurse -Force $tmp }

Write-Host "已安裝到 $dest"
Write-Host "請在該專案重新開啟 Claude Code 以載入 skill。"
