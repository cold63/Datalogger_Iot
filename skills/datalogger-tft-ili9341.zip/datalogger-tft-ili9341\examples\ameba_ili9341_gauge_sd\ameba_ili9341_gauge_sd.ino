/********************************************************************
 * 專案名稱：ameba_ili9341_gauge_sd (原 ili9341_demo6_sdcard)
 * 說    明：使用 AmebaILI9341 函式庫，實現一個包含溫濕度儀表、
 *           日期、時間的連續顯示畫面。
 *           (版本5: 修正指針方向)
 * 
 * 硬    體：
 *   - 開發板:    Realtek AmebaD (或相容開發板)
 *   - 螢幕:      2.4吋 240x320 ILI9341 TFT
 *   - TFT_RESET: 14
 *   - TFT_DC:    5
 *   - TFT_CS:    SPI_SS
 *   - BL_PIN:    9 (背光控制)
 ********************************************************************/

#include "SPI.h"
#include "AmebaILI9341.h"

#include "SdFat.h"
#if SPI_DRIVER_SELECT == 2  // Must be set in SdFat/SdFatConfig.h

// SD_FAT_TYPE = 0 for SdFat/File as defined in SdFatConfig.h,
// 1 for FAT16/FAT32, 2 for exFAT, 3 for FAT16/FAT32 and exFAT.
#define SD_FAT_TYPE 0
//
// Chip select may be constant or RAM variable.
const uint8_t SD_CS_PIN = 11;
//
// Pin numbers in templates must be constants.
const uint8_t SOFT_MISO_PIN = 15;
const uint8_t SOFT_MOSI_PIN = 10;
const uint8_t SOFT_SCK_PIN = 8;

// SdFat software SPI template
SoftSpiDriver<SOFT_MISO_PIN, SOFT_MOSI_PIN, SOFT_SCK_PIN> softSpi;
// Speed argument is ignored for software SPI.
#if ENABLE_DEDICATED_SPI
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, DEDICATED_SPI, SD_SCK_MHZ(0), &softSpi)
#else  // ENABLE_DEDICATED_SPI
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, SHARED_SPI, SD_SCK_MHZ(0), &softSpi)
#endif  // ENABLE_DEDICATED_SPI

#if SD_FAT_TYPE == 0
SdFat sd;
File file;
#elif SD_FAT_TYPE == 1
SdFat32 sd;
File32 file;
#elif SD_FAT_TYPE == 2
SdExFat sd;
ExFile file;
#elif SD_FAT_TYPE == 3
SdFs sd;
FsFile file;
#else  // SD_FAT_TYPE
#error Invalid SD_FAT_TYPE
#endif  // SD_FAT_TYPE

#else  // SPI_DRIVER_SELECT
#error SPI_DRIVER_SELECT must be two in SdFat/SdFatConfig.h
#endif  // SPI_DRIVER_SELECT


// ------------------- 硬體接腳定義 -------------------
#define TFT_RESET   14
#define TFT_DC      5
#define TFT_CS      SPI_SS
#define BL_PIN      9

// 建立 AmebaILI9341 物件
AmebaILI9341 tft = AmebaILI9341(TFT_CS, TFT_DC, TFT_RESET);

// ---------------- 全域變數 ----------------
float temperature = 25.0;
float humidity = 50.0;
float old_temperature = 25.0;
float old_humidity = 50.0;

int year = 25, month = 8, day = 17;
int hour = 10, minute = 30, second = 0;

unsigned long last_update_time = 0;
uint8_t x;

// ---------------- 副程式宣告 ----------------
void myFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
void drawFrame();
void drawTempGaugeBackground();
void drawHumGaugeBackground();
void updateTempGauge(float temp, float old_temp);
void updateHumGauge(float hum, float old_hum);
void updateDate(int y, int m, int d);
void updateTime(int h, int m, int s);
void updateValues(float temp, float hum);

/**************************************************************************/
/*!
    @brief  Arduino 主要設定函式
*/
/**************************************************************************/
void setup() {
    Serial.begin(115200);
    Serial.println("ILI9341 Demo 6 (v5, Final Fix) Start...");

    pinMode(BL_PIN, OUTPUT);
    digitalWrite(BL_PIN, HIGH);

    tft.begin();
    tft.setRotation(1);
    tft.fillScreen(ILI9341_BLACK);

     if (!sd.begin(SD_CONFIG)) {
        //sd.initErrorHalt();
        Serial.println("Initize SD Card error");
    }
   
    drawFrame();
    drawTempGaugeBackground();
    drawHumGaugeBackground();

    updateTempGauge(temperature, old_temperature);
    updateHumGauge(humidity, old_humidity);
    updateDate(year, month, day);
    updateTime(hour, minute, second);
    updateValues(temperature, humidity);
    
    last_update_time = millis();
}

/**************************************************************************/
/*!
    @brief  Arduino 主迴圈函式
*/
/**************************************************************************/
void loop() {
    if (millis() - last_update_time > 1000) {
        last_update_time = millis();

        old_temperature = temperature;
        old_humidity = humidity;

        temperature = 25.0 + 10.0 * sin(millis() / 20000.0);
        humidity = 55.0 + 25.0 * cos(millis() / 5000.0);
        
        second++;
        if (second >= 60) {
            second = 0;
            minute++;
            if (minute >= 60) {
                minute = 0;
                hour++;
                if (hour >= 24) {
                    hour = 0;
                    day++;
                }
            }
        }

        updateTempGauge(temperature, old_temperature);
        updateHumGauge(humidity, old_humidity);
        updateTime(hour, minute, second);
        updateValues(temperature, humidity);

        if(x < 5)
        {
            if (!file.open("SoftSPI2.txt",O_APPEND| O_RDWR | O_CREAT)) {
            sd.errorHalt(F("open failed"));
            }
            file.println(F("This line was printed using software SPI."));

            file.rewind();

            while (file.available()) {
            Serial.write(file.read());
            }

            file.close();

            Serial.println(F("Done."));

            delay(500);  

            x++; 
            }        
    }
    
}

/**************************************************************************/
/*!
    @brief  自定義的 fillRect 函式
*/
/**************************************************************************/
void myFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
    for (int16_t i = 0; i < h; i++) {
        tft.drawLine(x, y + i, x + w - 1, y + i, color);
    }
}

/**************************************************************************/
/*!
    @brief  繪製整個UI的靜態邊框
*/
/**************************************************************************/
void drawFrame() {
    tft.drawRectangle(5, 5, 190, 230, ILI9341_WHITE);
    tft.drawLine(6, 120, 194, 120, ILI9341_WHITE);
    tft.drawRectangle(200, 5, 115, 50, ILI9341_WHITE);
    tft.drawRectangle(200, 60, 115, 50, ILI9341_WHITE);
    tft.drawRectangle(200, 115, 115, 120, ILI9341_WHITE);
}

/**************************************************************************/
/*!
    @brief  繪製溫度儀表盤的底圖 (上半部)
*/
/**************************************************************************/
void drawTempGaugeBackground() {
    int centerX = 100;
    int centerY = 110;
    int radius = 55;

    tft.setCursor(centerX - 20, 20);
    tft.setFontSize(2);
    tft.setForeground(ILI9341_RED);
    tft.println("TEMP");

    for (int i = 0; i <= 180; i += 18) {
        float angle = i * PI / 180.0;
        int x1 = centerX - (radius - 8) * cos(angle);
        int y1 = centerY - (radius - 8) * sin(angle);
        int x2 = centerX - radius * cos(angle);
        int y2 = centerY - radius * sin(angle);
        tft.drawLine(x1, y1, x2, y2, ILI9341_WHITE);
    }
    
    tft.setFontSize(1);
    tft.setForeground(ILI9341_WHITE);
    tft.setCursor(centerX - radius - 12, centerY - 5);
    tft.println("0");
    tft.setCursor(centerX - 5, centerY - radius - 15);
    tft.println("25");
    tft.setCursor(centerX + radius, centerY - 5);
    tft.println("50");
}

/**************************************************************************/
/*!
    @brief  繪製濕度儀表盤的底圖 (下半部)
*/
/**************************************************************************/
void drawHumGaugeBackground() {
    int centerX = 100;
    int centerY = 220;
    int radius = 60;

    tft.setCursor(centerX - 20, 130);
    tft.setFontSize(2);
    tft.setForeground(ILI9341_BLUE);
    tft.println("HUMID");

    for (int i = 0; i <= 180; i += 18) {
        float angle = i * PI / 180.0;
        int x1 = centerX - (radius - 8) * cos(angle);
        int y1 = centerY - (radius - 8) * sin(angle);
        int x2 = centerX - radius * cos(angle);
        int y2 = centerY - radius * sin(angle);
        tft.drawLine(x1, y1, x2, y2, ILI9341_WHITE);
    }

    tft.setFontSize(1);
    tft.setForeground(ILI9341_WHITE);
    tft.setCursor(centerX - radius - 12, centerY - 5);
    tft.println("0");
    tft.setCursor(centerX - 5, centerY - radius - 15);
    tft.println("50");
    tft.setCursor(centerX + radius, centerY - 5);
    tft.println("100");
}

/**************************************************************************/
/*!
    @brief  更新溫度儀表盤的指針
*/
/**************************************************************************/
void updateTempGauge(float temp, float old_temp) {
    int centerX = 100;
    int centerY = 110;
    int radius = 50;

    // **修正** 映射: 溫度 0-50 -> 角度 0-180
    float angle_old = map(old_temp, 0, 50, 0, 180) * PI / 180.0;
    float angle_new = map(temp, 0, 50, 0, 180) * PI / 180.0;

    tft.drawLine(centerX, centerY, centerX - radius * cos(angle_old), centerY - radius * sin(angle_old), ILI9341_BLACK);
    tft.drawLine(centerX, centerY, centerX - radius * cos(angle_new), centerY - radius * sin(angle_new), ILI9341_RED);
}

/**************************************************************************/
/*!
    @brief  更新濕度儀表盤的指針
*/
/**************************************************************************/
void updateHumGauge(float hum, float old_hum) {
    int centerX = 100;
    int centerY = 220;
    int radius = 55;

    // **修正** 映射: 濕度 0-100 -> 角度 0-180
    float angle_old = map(old_hum, 0, 100, 0, 180) * PI / 180.0;
    float angle_new = map(hum, 0, 100, 0, 180) * PI / 180.0;

    tft.drawLine(centerX, centerY, centerX - radius * cos(angle_old), centerY - radius * sin(angle_old), ILI9341_BLACK);
    tft.drawLine(centerX, centerY, centerX - radius * cos(angle_new), centerY - radius * sin(angle_new), ILI9341_BLUE);
}

/**************************************************************************/
/*!
    @brief  更新日期顯示
*/
/**************************************************************************/
void updateDate(int y, int m, int d) {
    char dateStr[12];
    sprintf(dateStr, "%02d/%02d/%02d", y, m, d);
    myFillRect(205, 25, 105, 15, ILI9341_BLACK);
    tft.setCursor(210, 25);
    tft.setFontSize(2);
    tft.setForeground(ILI9341_YELLOW);
    tft.println(dateStr);
}

/**************************************************************************/
/*!
    @brief  更新時間顯示
*/
/**************************************************************************/
void updateTime(int h, int m, int s) {
    char timeStr[10];
    sprintf(timeStr, "%02d:%02d:%02d", h, m, s);
    myFillRect(210, 75, 100, 20, ILI9341_BLACK);
    tft.setCursor(215, 78);
    tft.setFontSize(2);
    tft.setForeground(ILI9341_GREENYELLOW);
    tft.println(timeStr);
}

/**************************************************************************/
/*!
    @brief  更新溫濕度數值顯示
*/
/**************************************************************************/
void updateValues(float temp, float hum) {
    char tempStr[10];
    char humStr[10];
    dtostrf(temp, 4, 1, tempStr);
    dtostrf(hum, 4, 1, humStr);

    myFillRect(205, 130, 105, 90, ILI9341_BLACK);

    tft.setCursor(210, 135);
    tft.setFontSize(2);
    tft.setForeground(ILI9341_RED);
    tft.println("Temp:");
    tft.setCursor(220, 155);
    tft.setForeground(ILI9341_WHITE);
    tft.print(tempStr);
    tft.println(" C");

    tft.setCursor(210, 185);
    tft.setFontSize(2);
    tft.setForeground(ILI9341_BLUE);
    tft.println("Humi:");
    tft.setCursor(220, 205);
    tft.setForeground(ILI9341_WHITE);
    tft.print(humStr);
    tft.println(" %");
}