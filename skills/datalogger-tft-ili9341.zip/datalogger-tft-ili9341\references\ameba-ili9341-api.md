# AmebaILI9341 API 參考

來源：`<AmebaD SDK>/libraries/SPI/src/AmebaILI9341.h`、`.cpp`
`#include "SPI.h"` 和 `#include "AmebaILI9341.h"` 兩者都要引入。類別繼承自 `Print`，所以可以用 `print()`、`println()`、`printf` 風格的 `print(value, fmt)`。

## 建構與初始化

| 函式 | 說明 |
|---|---|
| `AmebaILI9341(int csPin, int dcPin, int resetPin, SPIClass& spi = SPI)` | 建立物件。csPin 目前**無作用**，固定使用硬體 SS |
| `void begin()` | 重置並初始化 LCD（硬體 SPI） |
| `void setRotation(uint8_t m)` | 0 = 直向 240x320、**1 = 橫向 320x240（建議）**、2 = 直向翻轉、3 = 橫向翻轉 |
| `int16_t getWidth()` / `getHeight()` | 依目前旋轉方向回傳寬、高 |

## 填色與繪圖

| 函式 | 說明 |
|---|---|
| `void fillScreen(uint16_t color)` | 整個畫面填色（慢，只在初始化或切換頁面時用） |
| `void clr()` | 用目前背景色清除畫面 |
| `void fillRectangle(x, y, w, h, color)` | 實心矩形；會裁切右側和下方，**不裁切負座標** |
| `void drawRectangle(x, y, w, h [, color])` | 空心矩形；省略 color 時用 foreground |
| `void drawLine(x0, y0, x1, y1 [, color])` | 直線 |
| `void drawCircle(x0, y0, r [, color])` | 空心圓（沒有實心圓） |
| `void drawPixel(x, y, color)` | 單點 |
| `void drawBitmap(x, y, w, h, const unsigned short *data)` | RGB565 點陣圖，長度 w*h（可用來顯示 Logo 或中文字圖） |

## 文字

| 函式 | 說明 |
|---|---|
| `void setCursor(x, y)` | 設定文字起點（左上角） |
| `void setForeground(color)` | 文字顏色（預設 WHITE） |
| `void setBackground(color)` | 文字背景色（預設 BLACK）；和前景色不同時會畫出背景 |
| `void setFontSize(uint8_t s)` | 放大倍率 1, 2, 3…；每字元 `6*s` x `8*s` 像素 |
| `print(...)` / `println(...)` | 繼承自 Print；`\n` 會讓 x 歸零、y 加 `8*s`；超出右邊界時自動換行 |
| `void drawChar(x, y, c, fg, bg, size)` | 直接畫單一字元（會改變目前的 fontsize） |

字串寬度估算：`寬 = 字數 * 6 * size`、`高 = 8 * size`。
例：size 2、8 個字元（`10:31:50`）寬 96 px、高 16 px。

## 低階

| 函式 | 說明 |
|---|---|
| `setAddress(x0, y0, x1, y1)` | 設定 GRAM 寫入視窗 |
| `writecommand(uint8_t)` / `writedata(uint8_t)` / `writedata(uint8_t*, size_t)` | 直接送 ILI9341 指令或資料（例如 `ILI9341_INVON` 反相、`ILI9341_DISPOFF` 關閉顯示） |

## 內建顏色（RGB565）

| 常數 | 值 | 常數 | 值 |
|---|---|---|---|
| `ILI9341_BLACK` | 0x0000 | `ILI9341_BLUE` | 0x001F |
| `ILI9341_NAVY` | 0x000F | `ILI9341_GREEN` | 0x07E0 |
| `ILI9341_DARKGREEN` | 0x03E0 | `ILI9341_CYAN` | 0x07FF |
| `ILI9341_DARKCYAN` | 0x03EF | `ILI9341_RED` | 0xF800 |
| `ILI9341_MAROON` | 0x7800 | `ILI9341_MAGENTA` | 0xF81F |
| `ILI9341_PURPLE` | 0x780F | `ILI9341_YELLOW` | 0xFFE0 |
| `ILI9341_OLIVE` | 0x7BE0 | `ILI9341_WHITE` | 0xFFFF |
| `ILI9341_LIGHTGREY` | 0xC618 | `ILI9341_ORANGE` | 0xFD20 |
| `ILI9341_DARKGREY` | 0x7BEF | `ILI9341_GREENYELLOW` | 0xAFE5 |
| `ILI9341_PINK` | 0xF81F | | |

自訂顏色：

```cpp
#define RGB565(r, g, b) ((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3))
```

## 常用自訂副程式（函式庫沒有提供）

```cpp
// 實心圓：用水平線填滿
void myFillCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color) {
    for (int16_t dy = -r; dy <= r; dy++) {
        int16_t dx = (int16_t)sqrt((float)(r * r - dy * dy));
        tft.drawLine(x0 - dx, y0 + dy, x0 + dx, y0 + dy, color);
    }
}

// 水平進度條（外框 + 填色比例）
void drawBar(int16_t x, int16_t y, int16_t w, int16_t h, float ratio, uint16_t color) {
    if (ratio < 0) ratio = 0;
    if (ratio > 1) ratio = 1;
    int16_t fw = (int16_t)((w - 2) * ratio);
    tft.drawRectangle(x, y, w, h, ILI9341_WHITE);
    tft.fillRectangle(x + 1, y + 1, fw, h - 2, color);
    tft.fillRectangle(x + 1 + fw, y + 1, (w - 2) - fw, h - 2, ILI9341_BLACK);
}
```
