---
name: datalogger-tft-ili9341
description: 'Datalogger IoT 系列 TFT LCD 擴展板（RTL8720DF / AmebaD + 2.4" ILI9341 240x320 + SD 卡）應用開發。支援兩種顯示方式：Ameba 原生 AmebaILI9341（硬體 SPI，快、無中文）或 GFX Library for Arduino（Arduino_GFX + U8g2，支援中文）；SD 卡用 SdFat 軟體 SPI。適用：建立 TFT 顯示畫面、中文介面、儀表/數值/時間 UI、感測器資料顯示、SD 卡資料記錄、查詢擴展板腳位、開發環境設定、尋找範例。觸發詞：TFT、LCD、ILI9341、AmebaILI9341、Arduino_GFX、GFX Library、U8g2、中文顯示、擴展板、儀表畫面、顯示畫面、SD 卡記錄、Datalogger IoT。'
---

# Datalogger IoT TFT LCD 擴展板（ILI9341 + SD Card）

協助使用者在 **Datalogger IoT（RTL8720DF / AmebaD）** 上，用 TFT LCD 擴展板建立顯示與資料記錄應用。

- TFT：2.4" 240x320 **ILI9341**，接在板子的 SPI 腳位（DC 5、CS 18、SCK 19、MOSI 17、RST 14、背光 9）。
- SD 卡：一律走 **SdFat 軟體 SPI**（腳位 8/10/11/15），兩種顯示方式都相同。
- 板型：**Datalogger series (RTL8720DF)**，FQBN `realtek:AmebaD:DataloggerIot`。

本 skill 自帶範本與範例。下文的 `assets/`、`examples/`、`references/` 路徑都以 **本 skill 資料夾** 為基準（即 `SKILL.md` 所在的資料夾），在任何電腦上都能使用。

## 0. 先讓使用者選擇顯示方式（必做）

開始寫程式前，除非使用者已經明確指定，否則**必須用 AskUserQuestion 讓使用者選擇**下列方式之一。需求有中文時，把 B 標為建議。修改既有程式時，沿用該程式已使用的函式庫，不必再問。

| | **A. AmebaILI9341**（Ameba 原生） | **B. GFX Library for Arduino** |
|---|---|---|
| 來源 | Realtek AmebaD 開發板套件內建（`SPI` 函式庫內），免另外安裝 | 需安裝 `GFX Library for Arduino` + `U8g2` |
| 匯流排 | 硬體 SPI，**速度快** | `Arduino_SWSPI` 軟體 SPI，較慢（已實機驗證） |
| 中文 | **不支援**（只能用點陣圖） | **支援**：`setUTF8Print(true)` + U8g2 中文字型 |
| 繪圖 API | 精簡：線、矩形、圓、填色矩形、5x7 字型 | 完整：圓角框、實心圓、三角形、弧形、文字量測、Canvas、多種字型 |
| 程式大小（範本 + SD） | 約 246KB（Flash 11%） | 約 1.29MB（Flash 61%，主要是 `u8g2_font_unifont_h_chinese`）；留給 WiFi、MQTT 等功能的空間較少 |
| 適合 | 純數字或英文儀表、更新頻繁、要求速度 | 中文介面、資訊豐富或美觀的 UI |
| API 參考 | [references/ameba-ili9341-api.md](references/ameba-ili9341-api.md) | [references/arduino-gfx-api.md](references/arduino-gfx-api.md) |
| 範本 | [assets/ameba_ili9341_sd_template.ino](assets/ameba_ili9341_sd_template.ino) | [assets/gfx_sd_template.ino](assets/gfx_sd_template.ino) |

選定後，只讀對應的 API 參考、範本與範例；兩種函式庫的 API **不能混用**。

## 1. 開發環境準備

第一次使用，或編譯出現找不到標頭檔、`#error SPI_DRIVER_SELECT` 時，依下表檢查並協助使用者設定。

| 項目 | 設定方式 | 已驗證版本 |
|---|---|---|
| 開發板套件 | Arduino IDE「偏好設定 → 額外的開發板管理員網址」加入 `https://github.com/Ameba-AIoT/ameba-arduino-d/raw/master/Arduino_package/package_realtek_amebad_index.json`，再到開發板管理員安裝 **Realtek Ameba Boards (AmebaD)** | 3.2.0 編譯驗證；3.1.9 起已內建 AmebaILI9341 |
| 選擇板子 | 工具 → 開發板 → **Datalogger series (RTL8720DF)** | |
| SdFat | 程式庫管理員搜尋 **SdFat**（作者 Bill Greiman）安裝 | 2.3.0 |
| SdFat 設定 | 編輯 `<Arduino 專案資料夾>/libraries/SdFat/src/SdFatConfig.h`，把 `#define SPI_DRIVER_SELECT` 的值改為 **2**（預設為 0）。SdFat 更新後會被覆蓋，需要重新修改 | |
| GFX（只有 B 需要） | 程式庫管理員安裝 **GFX Library for Arduino**（作者 Moon On Our Nation） | 1.6.5 |
| U8g2（只有 B 需要） | 程式庫管理員安裝 **U8g2**（作者 oliver） | 2.36.19 |

- `<Arduino 專案資料夾>`：Arduino IDE「偏好設定 → 專案資料夾位置」，Windows 預設為 `文件\Arduino`。
- 開發板套件安裝位置：Windows 為 `%LOCALAPPDATA%\Arduino15\packages\realtek\hardware\AmebaD\<版本>\`，macOS 為 `~/Library/Arduino15/...`，Linux 為 `~/.arduino15/...`。版本號不要寫死，請用 Glob 搜尋 `**/AmebaD/*/libraries/SPI/src/AmebaILI9341.h` 確認。

## 2. 擴展板腳位（依開發板套件 `variants/Datalogger_AMB26/variant.h`）

| 功能 | Arduino Pin | MCU 腳 | 備註 |
|---|---|---|---|
| TFT_CS | `SPI_SS` (18) | PB_21 | |
| TFT_MOSI | `SPI_MOSI` (17) | PB_18 | |
| TFT_MISO | `SPI_MISO` (16) | PB_19 | GFX 方式不使用（`GFX_NOT_DEFINED`） |
| TFT_SCK | `SPI_SCLK` (19) | PB_20 | |
| TFT_DC | 5 | PA_28 | |
| TFT_RESET | 14 | PB_23 | |
| BL 背光 | 9 | PB_3 | HIGH = 亮、LOW = 滅；與 SWD_CLK 共用 |
| SD_CS | 11 | PB_1 | 軟體 SPI |
| SD_MOSI | 10 | PB_2 | 軟體 SPI |
| SD_MISO | 15 | PB_22 | 軟體 SPI |
| SD_SCK | 8 | PA_27 | 軟體 SPI；與 SWD_DATA 共用 |

上表以外的腳位（0–4、6、7、12、13）才可給感測器或其他擴充使用；寫程式前先確認沒有和上表衝突。

### A. AmebaILI9341 標準定義

```cpp
#include "SPI.h"
#include "AmebaILI9341.h"

#define TFT_RESET   14
#define TFT_DC      5
#define TFT_CS      SPI_SS
#define BL_PIN      9

AmebaILI9341 tft = AmebaILI9341(TFT_CS, TFT_DC, TFT_RESET);
```

### B. GFX Library for Arduino 標準定義

```cpp
#include <U8g2lib.h>              // 要放在 Arduino_GFX_Library.h 之前
#include <Arduino_GFX_Library.h>

#define GFX_BL 9

Arduino_DataBus *bus = new Arduino_SWSPI(5 /* DC */, 18 /* CS */, 19 /* SCK */, 17 /* MOSI */, GFX_NOT_DEFINED /* MISO */);
Arduino_GFX *gfx = new Arduino_ILI9341(bus, 14 /* RST */, 1 /* rotation */, false /* IPS */);
```

### SD 卡（兩種方式共用）

```cpp
#include "SdFat.h"
const uint8_t SD_CS_PIN     = 11;
const uint8_t SOFT_MISO_PIN = 15;
const uint8_t SOFT_MOSI_PIN = 10;
const uint8_t SOFT_SCK_PIN  = 8;
SoftSpiDriver<SOFT_MISO_PIN, SOFT_MOSI_PIN, SOFT_SCK_PIN> softSpi;
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, SHARED_SPI, SD_SCK_MHZ(0), &softSpi)
SdFat sd;
File file;
```

## 3. 範例與範本

### 本 skill 內附（優先參考）

| 路徑 | 方式 | 內容 |
|---|---|---|
| `assets/ameba_ili9341_sd_template.ino` | A | 最小範本：數值顯示 + SD 寫入 CSV |
| `assets/gfx_sd_template.ino` | B | 最小範本：中文標題、數值顯示 + SD 寫入 CSV |
| `examples/ameba_ili9341_gauge_sd/` | A | **完整範例**：溫溼度雙指針儀表、日期、時間、數值框、SD 寫檔；`screenshot.jpg` 是實機畫面 |
| `examples/gfx_hello_chinese/` | B | 最小中文顯示：UTF-8、U8g2 中文字型、文字縮放 |
| `examples/gfx_dashboard_mqtt/` | B | **中文多欄位儀表板**：版面依螢幕尺寸計算、只擦除數字區、WiFi + MQTT（JSON）+ FreeRTOS 任務；帳密已改為 `YOUR_...` 佔位字串；Flash 用量 85%，再加功能前要注意空間 |

範例中的感測器數值多為模擬值，移植時換成實際感測器讀值即可。每個範例資料夾都是完整的 Arduino sketch，可以直接複製出去開啟。

### 開發板套件與函式庫內的官方範例

- AmebaD 開發板套件：`<套件路徑>/libraries/SPI/examples/` 底下的 `ILI9341_TFT_LCD_basic`、`ILI9341_TFT_LCD_PM2.5`（A 方式）、`BW16_SD_Card_SPI`（SD）；函式庫原始碼在 `<套件路徑>/libraries/SPI/src/AmebaILI9341.h/.cpp`。
- GFX：`<Arduino 專案資料夾>/libraries/GFX_Library_for_Arduino/examples/` 底下的 `HelloWorld`、`U8g2Font`（中文）、`PDQgraphicstest`、`Clock`、`Canvas`、`Sprite`、`ImgViewer` 等。官方範例的匯流排和腳位**必須換成上面的標準定義**。

### 使用者自己的專案

如果目前工作區或上層資料夾有其他 TFT 專案，可用 Grep 以 `*.ino` 搜尋 `AmebaILI9341` 或 `Arduino_GFX_Library` 找出來參考，沿用團隊既有寫法。

## 4. 開發流程

1. **釐清需求**：要顯示的資料、是否需要中文、橫向或直向、區塊配置、更新頻率、是否寫入 SD、是否需要聯網。
2. **選擇顯示方式**（見第 0 節）；必要時確認開發環境（見第 1 節）。
3. **從範本開始**：複製對應的 `assets/*_template.ino`，或改寫最接近的 `examples/`。新 sketch 的檔名必須與資料夾同名。
4. **setup 順序**：
   - A：`Serial.begin` → 背光 HIGH → `tft.begin()` → `tft.setRotation(1)` → `tft.fillScreen()` → `sd.begin(SD_CONFIG)` → 畫靜態畫面。
   - B：`Serial.begin` → `gfx->begin()` → `fillScreen` → `setUTF8Print(true)` → `setFont(u8g2_font_unifont_h_chinese)` → 背光 HIGH → `sd.begin(SD_CONFIG)` → 畫靜態畫面。
   - SD 初始化失敗時只印訊息、在畫面上標示，不要停止程式。
5. **畫面分成靜態和動態兩層**：靜態（框線、標題、單位、刻度）在 setup 畫一次；動態（數值、時間、指針）寫成 `updateXxx()`，只擦除那一小塊再重畫。**不要每次 `fillScreen`**，會閃爍且很慢；B 用軟體 SPI 時更明顯。
6. **版面座標**：B 可依 `gfx->width()`、`gfx->height()` 計算（參考 `examples/gfx_dashboard_mqtt`），換旋轉方向時不必重算。
7. **loop 用 `millis()` 計時**，不要用長 `delay()`；搭配 FreeRTOS 任務時，loop 結尾要 `vTaskDelay()` 讓出 CPU（參考 `examples/gfx_dashboard_mqtt`）。
8. **建議程式風格**（範例採用的慣例，使用者或專案另有規範時以其為準）：
   - 檔頭註解區塊寫專案名稱、說明、硬體腳位。
   - 腳位用 `#define` 集中定義。
   - 每個副程式前加 `@brief` 註解。
   - 功能拆成自訂副程式。
   - 註解預設用繁體中文。
9. **機密資料**：WiFi、MQTT 等帳密一律寫成佔位字串（例如 `"YOUR_WIFI_SSID"`），或放在獨立的 `secrets.h` 並提醒使用者不要提交或分享。

## 5. 注意事項與陷阱

### 共通
- **SD 必須用軟體 SPI**，不要改成硬體 `SPI`。軟體 SPI 速度慢，請批次寫入。附加寫檔用 `file.open(name, O_APPEND | O_RDWR | O_CREAT)`，寫完務必 `file.close()`。
- **`sd.errorHalt()` 會讓程式停住**：正式應用改成印錯誤訊息後跳過寫檔。
- **Pin 8 / 9 與 SWD 共用**：使用 SWD 除錯器時會和 SD_SCK、背光衝突。
- **儀表指針**：先用背景色畫舊指針、再畫新指針；指針會掃過的刻度或文字，擦除後要重畫。
- **`map()` 是整數運算**：需要平滑角度時請自己用浮點公式計算。

### A. AmebaILI9341
- **這不是 Adafruit_GFX**：沒有 `setTextColor`、`setTextSize`、`fillRect`、`fillCircle`、`drawRoundRect`、`drawTriangle`、`width()`、`height()`。對應寫法：`setForeground` / `setBackground`、`setFontSize`、`fillRectangle`、`getWidth()` / `getHeight()`。缺少的圖形用 `drawLine` / `drawPixel` 自己寫副程式。
- **TFT 的 CS 參數無效**：函式庫固定使用硬體 SS（18）。
- **文字會畫背景色**（預設黑色）：更新**等寬**數字時可直接覆寫；字串變短時仍要先擦除或補空白。
- **`println()` 會把 cursor_x 歸零**：多行文字請每行自己 `setCursor`。
- **字型**：內建 5x7 字型，每字元 `6*size` x `8*size` 像素，只支援 ASCII，**不支援中文**。
- **`fillRectangle` 不裁切負座標**：x、y 必須 ≥ 0。完整範例中的 `myFillRect()`（逐行 `drawLine`）是另一種擦除寫法。

### B. GFX Library for Arduino
- **`#include <U8g2lib.h>` 必須放在 `Arduino_GFX_Library.h` 之前**，否則 `setFont(u8g2_font_...)` 無法使用。
- **中文必須 `setUTF8Print(true)`**，原始檔要存成 UTF-8。
- **U8g2 字型的 `setCursor` y 是基線**：字的上緣在 `y - 字高*textSize`，靠近上邊界時要預留高度，否則會被裁切。
- **U8g2 字型的背景只蓋到每個字形本身的方框**，不會清掉整段字串的範圍：更新數值前一定要先 `fillRect` 擦除該區（參考 `examples/gfx_dashboard_mqtt` 的 `updateValues()`）。
- **只擦除會變的部分**：單位、名稱只畫一次，數字區保留固定寬度擦除重畫。
- **匯流排用 `Arduino_SWSPI`**：`Arduino_HWSPI` 在此函式庫只針對 RTL8722DM 有支援，Datalogger IoT 未驗證；不要用 `create_default_Arduino_DataBus()`。
- **rotation 在建構子設定**（第 3 個參數），也可以用 `gfx->setRotation()` 改。
- **缺字**：字型沒收錄的字元不會顯示；遇到缺字時換字型（見 API 參考）或改用點陣圖。
- **全螢幕 `Arduino_Canvas` 需約 150KB RAM**，且整頁推送較慢，一般用局部擦除即可。

## 6. 驗證

- 編譯：Arduino IDE 或 VS Code Arduino 擴充套件選擇 **Datalogger series (RTL8720DF)**；或用 arduino-cli（Arduino IDE 2.x 有內建一份，位於 IDE 安裝資料夾）：
  `arduino-cli compile --fqbn realtek:AmebaD:DataloggerIot <sketch資料夾>`
- 上傳後打開序列埠監控（115200）：確認 `gfx->begin()` 和 SD 初始化訊息，以及畫面方向、排版、殘影和閃爍情況。
- 請使用者拍下實機畫面（像 `examples/ameba_ili9341_gauge_sd/screenshot.jpg` 那樣），用來核對座標與排版。
