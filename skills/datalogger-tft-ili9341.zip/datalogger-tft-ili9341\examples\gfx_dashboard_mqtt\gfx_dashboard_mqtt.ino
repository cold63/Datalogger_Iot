#include <U8g2lib.h>
#include <Arduino_GFX_Library.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

#define GFX_BL 9 // default backlight pin, you may replace DF_GFX_BL to actual backlight pin

/* More data bus class: https://github.com/moononournation/Arduino_GFX/wiki/Data-Bus-Class */
//Arduino_DataBus *bus = create_default_Arduino_DataBus();
Arduino_DataBus *bus = new Arduino_SWSPI(5 /* DC */, 18 /* CS */, 19 /* SCK */, 17 /* MOSI */, GFX_NOT_DEFINED /* MISO */);

/* More display class: https://github.com/moononournation/Arduino_GFX/wiki/Display-Class */
Arduino_GFX *gfx = new Arduino_ILI9341(bus,14, 2 /* rotation */, false /* IPS */);


/*******************************************************************************
 * End of Arduino_GFX setting
 ******************************************************************************/

// 環境監測欄位定義（數值暫時以亂數模擬）
struct SensorField
{
  const char *label; // 中文名稱
  const char *unit;  // 單位
  float minVal;       // 模擬最小值
  float maxVal;       // 模擬最大值
  uint8_t decimals;   // 小數位數
};

SensorField fields[] = {
    {"風速", "m/s", 0.0, 15.0, 1},
    {"溫度", "°C", 15.0, 35.0, 1},
    {"濕度", "%", 30.0, 90.0, 0},
    {"噪音", "dB", 30.0, 90.0, 0},
    {"PM2.5", "ug/m3", 0.0, 150.0, 0},
    {"PM1.0", "ug/m3", 0.0, 150.0, 0},
    {"光照", "lux", 0.0, 2000.0, 0},
};
const uint8_t FIELD_COUNT = sizeof(fields) / sizeof(fields[0]);

const int HEADER_H = 30;   // 標題列高度
const int LABEL_X = 8;     // 名稱起始 X
int rowH;                  // 每個欄位列高（依實際螢幕高度計算）
int valueX;                // 數值起始 X（依實際螢幕寬度計算）
int numberW;               // 數值（不含單位）保留寬度，只有這段會被清除重畫
int unitX;                 // 單位起始 X（單位固定不動，只畫一次）

unsigned long lastUpdate = 0;
const unsigned long UPDATE_INTERVAL = 2000; // 更新頻率（毫秒）

// ==================== WiFi 設定 ====================
char ssid[] = "YOUR_WIFI_SSID";        // WiFi SSID
char pass[] = "YOUR_WIFI_PASSWORD";    // WiFi 密碼
volatile bool wifiConnected = false;

// ==================== MQTT 設定 ====================
char mqttServer[] = "YOUR_MQTT_BROKER";              // MQTT Broker 位址
char clientId[20];                                     // MQTT 客戶端 ID（自動生成）
char subjectTopic[] = "YOUR_TOPIC/weather/sensor";    // MQTT Topic
char username[] = "YOUR_MQTT_USERNAME";                // MQTT 使用者名稱
char password[] = "YOUR_MQTT_PASSWORD";                // MQTT 密碼

unsigned long lastMQTTSendTime = 0;                   // MQTT 發送計時器
const unsigned long MQTT_SEND_INTERVAL = 5000;        // MQTT 發送間隔 (5秒)

WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);

float latestValue[FIELD_COUNT] = {0}; // 對應 fields[] 同索引，尚未收到資料前顯示 0
volatile bool newDataAvailable = false;

void onMqttMessage(char *topic, byte *payload, unsigned int length)
{

    Serial.print("Message arrived [");
    Serial.print(topic);
    Serial.print("] ");
    for (unsigned int i = 0; i < length; i++) {
        Serial.print((char)payload[i]);
    }
    Serial.println();
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, payload, length);
  if (err)
  {
    Serial.print("JSON parse failed: ");
    Serial.println(err.c_str());
    return;
  }

  // 陣列索引需對應 fields[] 目前的順序：風速,溫度,濕度,噪音,PM2.5,PM1.0,光照
  latestValue[0] = doc["wind_speed"] | latestValue[0];
  latestValue[1] = doc["temperature"] | latestValue[1];
  latestValue[2] = doc["humidity"] | latestValue[2];
  latestValue[3] = doc["noise"] | latestValue[3];
  latestValue[4] = doc["pm2_5"] | latestValue[4];
  latestValue[5] = doc["pm1_0"] | latestValue[5];
  latestValue[6] = doc["light"] | latestValue[6];
  printf("Latest values: wind_speed=%.2f, temperature=%.2f, humidity=%.2f, noise=%.2f, pm2_5=%.2f, pm1_0=%.2f, light=%.2f\n",
         latestValue[0], latestValue[1], latestValue[2], latestValue[3], latestValue[4], latestValue[5], latestValue[6]);   

  newDataAvailable = true;
}

void MqttTask(void *pvParameters) {

    for (;;) {
        // 檢查 WiFi 連線狀態
        if (!wifiConnected) {
            vTaskDelay(1000 / portTICK_PERIOD_MS);  // WiFi 未連線，等待 1 秒後重試
            continue;
        }

        // 維護 MQTT 連線
        if (!mqttClient.connected()) {
            Serial.print("Attempting MQTT connection...");
            if (mqttClient.connect(clientId, username, password)) {
                mqttClient.subscribe(subjectTopic);
                Serial.println("connected");
            } else {
                Serial.print("failed, rc=");
                Serial.print(mqttClient.state());
                Serial.println(" try again later");
                vTaskDelay(5000 / portTICK_PERIOD_MS);  // 連線失敗，等待 5 秒後重試
                continue;
            }
        }

        // 處理 MQTT 心跳與回調
        mqttClient.loop();
        
        vTaskDelay(500 / portTICK_PERIOD_MS);   // 500ms 延遲，避免佔用過多 CPU
    }
}

void drawLayout()
{
  gfx->fillScreen(RGB565_BLACK);

  // 標題（setCursor 的 y 是 u8g2 字型的基線，須預留字型完整高度才不會被裁切上緣）
  gfx->setTextColor(RGB565_YELLOW);
  gfx->setCursor(LABEL_X, HEADER_H - 8);
  gfx->print("環境監測儀表板");
  gfx->drawFastHLine(0, HEADER_H, gfx->width(), RGB565_WHITE);

  // 各欄位名稱與分隔線
  for (uint8_t i = 0; i < FIELD_COUNT; i++)
  {
    int rowY = HEADER_H + i * rowH;

    gfx->setTextColor(RGB565_WHITE);
    gfx->setCursor(LABEL_X, rowY + rowH - 8);
    gfx->print(fields[i].label);

    // 單位固定不變，這裡只畫一次；updateValues() 只重畫數字部分
    gfx->setTextColor(RGB565_CYAN);
    gfx->setCursor(unitX, rowY + rowH - 8);
    gfx->print(fields[i].unit);

    if (i > 0)
    {
      gfx->drawFastHLine(0, rowY, gfx->width(), RGB565_DARKGREY);
    }
  }
}

// 產生模擬亂數值
float randomValue(float minVal, float maxVal)
{
  long scaled = random((long)(minVal * 100), (long)(maxVal * 100) + 1);
  return scaled / 100.0;
}

void updateValues()
{
  for (uint8_t i = 0; i < FIELD_COUNT; i++)
  {
    int rowY = HEADER_H + i * rowH;

    // 只清除數字區域，避免殘影；單位不動，不需要重畫
    gfx->fillRect(valueX, rowY + 1, numberW, rowH - 2, RGB565_BLACK);

    // 顯示 MQTT 收到的最新資料（尚未收到前為初始值 0）
    char valStr[16];
    dtostrf(latestValue[i], 0, fields[i].decimals, valStr);

    gfx->setTextColor(RGB565_CYAN);
    gfx->setCursor(valueX, rowY + rowH - 8);
    gfx->print(valStr);
  }
}

void wifiTask(void *pvParameters) {
    static unsigned long lastAttempt = 0;
    const unsigned long retryInterval = 10000;  // 10 秒重試間隔
    
    for (;;) {
        if (WiFi.status() != WL_CONNECTED) {
            if (millis() - lastAttempt > retryInterval) {
                Serial.print("\n[WiFi] 連線中斷，嘗試重新連接: ");
                Serial.println(ssid);
                WiFi.disconnect();
                vTaskDelay(500 / portTICK_PERIOD_MS);
                WiFi.begin(ssid, pass);
                lastAttempt = millis();
                
                // 等待連線（最多 5 秒）
                vTaskDelay(5000 / portTICK_PERIOD_MS);
                
                if (WiFi.status() == WL_CONNECTED) {
                    Serial.println("[WiFi] 重新連線成功！");
                    Serial.print("[WiFi] IP 位址: ");
                    Serial.println(WiFi.localIP());
                    wifiConnected = true;
                } else {
                    Serial.println("[WiFi] 重新連線失敗，稍後重試");
                    wifiConnected = false;
                }
            } else {
                wifiConnected = false;
            }
        } else {
            wifiConnected = true;
        }
        
        vTaskDelay(1000 / portTICK_PERIOD_MS);  // 每秒檢查一次
    }
}

void setup(void)
{
#ifdef DEV_DEVICE_INIT
  DEV_DEVICE_INIT();
#endif

  Serial.begin(115200);
  // Serial.setDebugOutput(true);
  // while(!Serial);
  Serial.println("環境監測儀表板啟動");

  randomSeed(micros());

  // Init Display
  if (!gfx->begin())
  {
    Serial.println("gfx->begin() failed!");
  }
  gfx->fillScreen(RGB565_BLACK);
  gfx->setUTF8Print(true); // enable UTF8 support for the Arduino print() function
  gfx->setFont(u8g2_font_unifont_h_chinese);
#ifdef GFX_BL
  pinMode(GFX_BL, OUTPUT);
  digitalWrite(GFX_BL, HIGH);
#endif

  // 依實際螢幕尺寸（受 rotation 影響）計算版面，避免尺寸寫死造成超出面板範圍
  rowH = (gfx->height() - HEADER_H) / FIELD_COUNT;
  valueX = gfx->width() * 2 / 3 - 40; // 往前移約 5 個半形字元寬度（unifont 半形約 8px/字）
  numberW = (gfx->width() - valueX - LABEL_X) * 3 / 5; // 數字保留寬度，其餘留給單位
  unitX = valueX + numberW + 6;

  randomSeed(millis());
  sprintf(clientId, "d%lu", random(1000, 30000));
  Serial.print("Client ID: ");
  Serial.println(clientId);
  wifiClient.setBlockingMode();
  mqttClient.setServer(mqttServer, 1883);
  mqttClient.setCallback(onMqttMessage);  // 設定 MQTT 回呼函數
  drawLayout();
  updateValues();

      // WiFi 管理任務（優先級須 >= loop() 所在的 main_task 優先權 1，否則會被 loop() 餓死排不到）
  xTaskCreate(wifiTask, "WiFiTask", 2048, NULL, 0, NULL);
  xTaskCreate(MqttTask, "MqttTask", 4096, NULL, 1, NULL); 
  lastUpdate = millis();
}

void loop()
{
  // 收到新的 MQTT 資料時立即重繪，否則每隔 UPDATE_INTERVAL 也重繪一次（保險）
  if (newDataAvailable || millis() - lastUpdate >= UPDATE_INTERVAL)
  {
    updateValues();
    lastUpdate = millis();
    newDataAvailable = false;
  }

  // loop() 跑在優先權 1 的 main_task，若不讓出 CPU 會讓同/低優先權的任務（如 wifiTask）餓死排不到
  vTaskDelay(100 / portTICK_PERIOD_MS);
}
