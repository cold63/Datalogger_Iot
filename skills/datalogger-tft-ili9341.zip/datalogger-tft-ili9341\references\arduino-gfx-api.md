# GFX Library for Arduino（Arduino_GFX）API 參考

- 函式庫：`<Arduino 專案資料夾>/libraries/GFX_Library_for_Arduino/`（撰寫時 v1.6.5，作者 moononournation）
- 中文字型：`<Arduino 專案資料夾>/libraries/U8g2/`（撰寫時 v2.36.19）
- 原始碼：`src/Arduino_GFX.h`（繪圖、文字 API）、`src/databus/`（匯流排類別）、`src/display/Arduino_ILI9341.h`
- 官方 Wiki：https://github.com/moononournation/Arduino_GFX/wiki

## 建立物件（Datalogger IoT 擴展板固定寫法）

```cpp
#include <U8g2lib.h>              // 要用中文字型時才需要，且必須放在 Arduino_GFX_Library.h 之前
#include <Arduino_GFX_Library.h>

#define GFX_BL 9                  // 背光：HIGH 開

Arduino_DataBus *bus = new Arduino_SWSPI(5 /* DC */, 18 /* CS */, 19 /* SCK */, 17 /* MOSI */, GFX_NOT_DEFINED /* MISO */);
Arduino_GFX *gfx = new Arduino_ILI9341(bus, 14 /* RST */, 1 /* rotation */, false /* IPS */);
```

- **rotation** 在建構子設定：0 = 直向 240x320、1 = 橫向 320x240、2、3 = 翻轉；也可以之後呼叫 `gfx->setRotation(r)`。
- **匯流排**：`Arduino_HWSPI` 在這個函式庫只針對 RTL8722DM 有寫支援，Datalogger IoT 板（DataloggerIot）未驗證，所以請用已在實機驗證過的 `Arduino_SWSPI`。
- `create_default_Arduino_DataBus()` 不適用這塊板子，請直接 `new Arduino_SWSPI(...)`。

## 初始化

```cpp
if (!gfx->begin()) Serial.println("gfx->begin() failed!");
gfx->fillScreen(RGB565_BLACK);
gfx->setUTF8Print(true);                       // 讓 print() 支援 UTF-8（中文）
gfx->setFont(u8g2_font_unifont_h_chinese);     // U8g2 中文字型
pinMode(GFX_BL, OUTPUT); digitalWrite(GFX_BL, HIGH);
```

## 繪圖

| 函式 | 說明 |
|---|---|
| `fillScreen(c)` | 全螢幕填色 |
| `drawPixel(x,y,c)` | 單點 |
| `drawLine(x0,y0,x1,y1,c)` | 直線 |
| `drawFastHLine(x,y,w,c)` / `drawFastVLine(x,y,h,c)` | 水平、垂直線（較快） |
| `drawRect` / `fillRect(x,y,w,h,c)` | 矩形 |
| `drawRoundRect` / `fillRoundRect(x,y,w,h,r,c)` | 圓角矩形 |
| `drawCircle` / `fillCircle(x,y,r,c)` | 圓 |
| `drawEllipse` / `fillEllipse(x,y,rx,ry,c)` | 橢圓 |
| `drawTriangle` / `fillTriangle(x0,y0,x1,y1,x2,y2,c)` | 三角形 |
| `drawArc` / `fillArc(x,y,r1,r2,start,end,c)` | 環形弧（r1 外徑、r2 內徑、角度單位為度），適合做儀表 |
| `draw16bitRGBBitmap(x,y,bitmap,w,h)` | RGB565 點陣圖 |
| `drawBitmap(x,y,bitmap,w,h,c)` | 1-bit 單色點陣圖 |
| `width()` / `height()` | 依旋轉方向的寬、高 |
| `invertDisplay(b)` / `displayOn()` / `displayOff()` | 反相、開關顯示 |

## 文字

| 函式 | 說明 |
|---|---|
| `setFont(u8g2_font_xxx)` | U8g2 字型；`setFont()`（不帶參數）回到內建 5x7 字型 |
| `setUTF8Print(true)` | 啟用 UTF-8，中文必須開 |
| `setCursor(x,y)` | 用 U8g2 字型時 **y 是基線**；用內建字型時 y 是左上角 |
| `setTextColor(fg)` / `setTextColor(fg,bg)` | 只給 fg 時是透明背景 |
| `setTextSize(s)` / `setTextSize(sx,sy,margin)` | 放大倍率 |
| `setTextWrap(b)` | 是否自動換行 |
| `getTextBounds(str,x,y,&x1,&y1,&w,&h)` | 量測字串邊界，可用來置中或計算擦除範圍 |
| `print()` / `println()` | 繼承自 Print |

### 常用 U8g2 中文字型

| 字型 | 說明 |
|---|---|
| `u8g2_font_unifont_h_chinese` | 16px，常用中文字（範例專案使用），字形較完整 |
| `u8g2_font_wqy12_t_gb2312` / `wqy14` / `wqy16` | 文泉驛 GB2312 字集（簡體為主，部分繁體缺字） |
| `u8g2_font_unifont_t_chinese1/2/3` | 不同大小的中文子集 |

字型越大、字集越完整，Flash 用量越多。字型沒收錄的字元會直接不顯示；若有缺字，請換字型或改用點陣圖。

### 文字置中範例

```cpp
void printCenter(const char *s, int16_t cy) {
    int16_t x1, y1; uint16_t w, h;
    gfx->getTextBounds(s, 0, cy, &x1, &y1, &w, &h);
    gfx->setCursor((gfx->width() - w) / 2, cy);
    gfx->print(s);
}
```

## 顏色

常數格式是 `RGB565_<名稱>`，例如 `RGB565_BLACK`、`RGB565_WHITE`、`RGB565_RED`、`RGB565_GREEN`、`RGB565_BLUE`、`RGB565_YELLOW`、`RGB565_CYAN`、`RGB565_MAGENTA`、`RGB565_ORANGE`、`RGB565_DARKGREY`、`RGB565_LIGHTGREY`、`RGB565_NAVY`。這些是 CSS 色名，完整清單在 `Arduino_GFX.h`。
自訂顏色用 `RGB565(r, g, b)` 巨集。

## Canvas（離屏緩衝，避免閃爍）

```cpp
Arduino_Canvas *canvas = new Arduino_Canvas(320, 240, gfx);   // 全螢幕需約 150KB RAM
canvas->begin();
canvas->fillScreen(RGB565_BLACK);  /* ...在 canvas 上繪圖... */
canvas->flush();                   // 一次推到螢幕
```

全螢幕 Canvas 很吃記憶體，且透過軟體 SPI 一次推完整畫面約需數百毫秒。大部分情況改用「局部擦除重畫」即可；只有局部動畫才考慮小尺寸 Canvas。

## 函式庫內的官方範例

路徑：`<Arduino 專案資料夾>/libraries/GFX_Library_for_Arduino/examples/`

| 範例 | 用途 |
|---|---|
| `HelloWorld` | 最小範例 |
| `U8g2Font` | U8g2 字型和中文顯示 |
| `HelloWorldGfxfont` | Adafruit GFXfont 字型 |
| `PDQgraphicstest` | 各種繪圖函式示範與效能測試 |
| `Clock` | 類比時鐘（指針擦除重畫） |
| `Canvas`、`Sprite` | 離屏緩衝 |
| `SetTextBound` | 文字區域限制 |
| `AsciiTable` | 內建字元表 |
| `ImgViewer` | 圖片顯示（JPEG、PNG、BMP、GIF） |

官方範例預設使用 `create_default_Arduino_DataBus()` 和其他腳位，移植時**一定要換成上面的 bus/gfx 建立方式**。
