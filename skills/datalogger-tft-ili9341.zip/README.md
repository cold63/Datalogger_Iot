# datalogger-tft-ili9341：Claude Code Skill

這是 **Datalogger IoT 系列 TFT LCD 擴展板**（RTL8720DF + 2.4" ILI9341 240x320 + SD 卡）的 Claude Code skill。
安裝到 Arduino 專案後，Claude 寫 TFT 程式時會自動知道擴展板腳位、兩種顯示函式庫的用法與陷阱，並參考內附的範例。

## 內容

```
datalogger-tft-ili9341/
├── SKILL.md                       主說明：選擇顯示方式、環境準備、腳位、流程、注意事項
├── references/
│   ├── ameba-ili9341-api.md       AmebaILI9341（Ameba 原生，硬體 SPI）API
│   └── arduino-gfx-api.md         GFX Library for Arduino + U8g2（支援中文）API
├── assets/
│   ├── ameba_ili9341_sd_template.ino   最小範本 A：數值 + SD 記錄
│   └── gfx_sd_template.ino             最小範本 B：中文 + 數值 + SD 記錄
└── examples/
    ├── ameba_ili9341_gauge_sd/    溫溼度雙指針儀表 + 日期時間 + SD（附實機照片）
    ├── gfx_hello_chinese/         最小中文顯示
    └── gfx_dashboard_mqtt/        中文多欄位儀表板 + WiFi/MQTT + FreeRTOS（帳密為佔位字串）
```

## 安裝（Windows）

1. 解壓縮本 zip 到任意位置。
2. 執行（把路徑換成你的 Arduino 專案資料夾）：
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\install-tft-skill.ps1 -Project "D:\Arduino\my_tft_project"
   ```
   或手動複製：把 `datalogger-tft-ili9341` 資料夾整個複製到 `<專案>\.claude\skills\` 底下。
3. 在該專案重新開啟 Claude Code。

macOS 和 Linux 請手動複製到 `<專案>/.claude/skills/`。

skill 只對安裝的那個專案生效。若要所有專案都能使用，可改放到 `~/.claude/skills/`（全域）。

## 使用

在 Claude Code 中直接描述需求即可，例如：

- 「用 TFT 做一個顯示溫溼度和時間的畫面，每分鐘記錄到 SD 卡」
- 「做一個中文的空氣品質儀表板」

Claude 會先請你選擇顯示方式：

| | A. AmebaILI9341 | B. GFX Library for Arduino |
|---|---|---|
| 速度 | 快（硬體 SPI） | 較慢（軟體 SPI） |
| 中文 | 不支援 | 支援 |
| 程式大小 | 小 | 大（中文字型約佔 Flash 50%） |

## 開發環境需求

- Arduino IDE 2.x（或 VS Code + Arduino 擴充套件）
- 開發板套件：Realtek Ameba Boards (AmebaD)，板型選 **Datalogger series (RTL8720DF)**
  - 開發板管理員網址：`https://github.com/Ameba-AIoT/ameba-arduino-d/raw/master/Arduino_package/package_realtek_amebad_index.json`
- 程式庫：**SdFat**（必須把 `SdFatConfig.h` 的 `SPI_DRIVER_SELECT` 改為 2）
- 使用 B 方式時還需要：**GFX Library for Arduino**、**U8g2**

詳細設定見 `datalogger-tft-ili9341/SKILL.md` 第 1 節。
