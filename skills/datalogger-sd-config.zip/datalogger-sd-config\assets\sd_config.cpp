/********************************************************************
 * sd_config.cpp - SD 卡參數設定檔讀寫實作 (表驅動)
 *
 * 新增參數時，本檔只需要改「CFG_TABLE」一處：
 *   【新增參數步驟 3/3】在 CFG_TABLE 加一列
 *   (另外兩處在 sd_config.h：struct 欄位、DEF_ 預設值)
 ********************************************************************/

#include "sd_config.h"
#include <stddef.h>
#include <string.h>

// 參數表的一列：key 名稱、欄位在 struct 內的位移、欄位大小、預設值
struct CfgItem {
    const char *key;
    size_t      offset;
    size_t      size;
    const char *def;
};

// 取得 struct 欄位位移與大小的簡寫
#define CFG_ITEM(field, defval) \
    { #field, offsetof(AppConfig, field), sizeof(((AppConfig *)0)->field), defval }

// ---------------- 【新增參數步驟 3/3】參數表 ----------------
// key 名稱 = 欄位名稱 = config.ini 內的 key (小寫、底線)
// 例：CFG_ITEM(device_id, DEF_DEVICE_ID),
static const CfgItem CFG_TABLE[] = {
    CFG_ITEM(wifi_ssid,   DEF_WIFI_SSID),
    CFG_ITEM(wifi_pass,   DEF_WIFI_PASS),
    CFG_ITEM(mqtt_broker, DEF_MQTT_BROKER),
    CFG_ITEM(mqtt_user,   DEF_MQTT_USER),
    CFG_ITEM(mqtt_pass,   DEF_MQTT_PASS),
    CFG_ITEM(mqtt_topic,  DEF_MQTT_TOPIC),
};
static const size_t CFG_COUNT = sizeof(CFG_TABLE) / sizeof(CFG_TABLE[0]);

/**************************************************************************/
/*!
    @brief  安全字串複製 (必定以 '\0' 結尾，超長則截斷)
            (本平台沒有 strlcpy)
*/
/**************************************************************************/
static void copyStr(char *dst, const char *src, size_t size) {
    strncpy(dst, src, size - 1);
    dst[size - 1] = '\0';
}

/**************************************************************************/
/*!
    @brief  取得參數表某一列對應的 struct 欄位位址
*/
/**************************************************************************/
static char *fieldPtr(AppConfig &c, const CfgItem &it) {
    return (char *)&c + it.offset;
}

/**************************************************************************/
/*!
    @brief  將所有參數設為預設值
*/
/**************************************************************************/
void cfgLoadDefaults(AppConfig &c) {
    for (size_t i = 0; i < CFG_COUNT; i++) {
        copyStr(fieldPtr(c, CFG_TABLE[i]), CFG_TABLE[i].def, CFG_TABLE[i].size);
    }
}

/**************************************************************************/
/*!
    @brief  將參數寫入 SD 卡 config.ini (覆寫)
    @return true = 寫入成功
*/
/**************************************************************************/
bool cfgSave(SdFat &sd, const AppConfig &c) {
    File file;
    if (!file.open(CONFIG_FILE, O_WRITE | O_CREAT | O_TRUNC)) {
        Serial.println("open " CONFIG_FILE " for write failed");
        return false;
    }
    file.println("# Datalogger config (key=value)");
    for (size_t i = 0; i < CFG_COUNT; i++) {
        file.print(CFG_TABLE[i].key);
        file.print('=');
        file.println(fieldPtr((AppConfig &)c, CFG_TABLE[i]));
    }
    file.close();
    return true;
}

/**************************************************************************/
/*!
    @brief  讀取 SD 卡 config.ini 並回填到 struct
            略過空行與 # 註解；未知 key 忽略；缺少的 key 維持原值
    @return true = 開檔並讀取完成
*/
/**************************************************************************/
bool cfgLoad(SdFat &sd, AppConfig &c) {
    File file;
    if (!file.open(CONFIG_FILE, O_RDONLY)) {
        Serial.println("open " CONFIG_FILE " for read failed");
        return false;
    }

    char line[160];
    int n;
    while ((n = file.fgets(line, sizeof(line))) > 0) {
        // 去除行尾 \r \n 與空白
        while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r' || line[n - 1] == ' ')) {
            line[--n] = '\0';
        }
        // 去除行首空白
        char *key = line;
        while (*key == ' ' || *key == '\t') key++;
        if (*key == '\0' || *key == '#') continue;

        // 以第一個 '=' 分割 key / value
        char *val = strchr(key, '=');
        if (!val) continue;
        *val++ = '\0';
        char *kend = key + strlen(key);
        while (kend > key && (kend[-1] == ' ' || kend[-1] == '\t')) *--kend = '\0';
        while (*val == ' ' || *val == '\t') val++;

        // 查表回填
        for (size_t i = 0; i < CFG_COUNT; i++) {
            if (!strcmp(key, CFG_TABLE[i].key)) {
                copyStr(fieldPtr(c, CFG_TABLE[i]), val, CFG_TABLE[i].size);
                break;
            }
        }
    }
    file.close();
    return true;
}

/**************************************************************************/
/*!
    @brief  一站式初始化：載入預設 -> (有卡) 無檔則建立 / 有檔則讀取
*/
/**************************************************************************/
CfgSource cfgInit(SdFat &sd, bool sdReady, AppConfig &c) {
    cfgLoadDefaults(c);
    if (!sdReady) return CFG_FROM_DEFAULT;

    if (!sd.exists(CONFIG_FILE)) {
        return cfgSave(sd, c) ? CFG_FROM_SD_NEW : CFG_FROM_DEFAULT;
    }
    if (cfgLoad(sd, c)) return CFG_FROM_SD_LOADED;

    cfgLoadDefaults(c);     // 讀檔失敗，退回預設
    return CFG_FROM_DEFAULT;
}
