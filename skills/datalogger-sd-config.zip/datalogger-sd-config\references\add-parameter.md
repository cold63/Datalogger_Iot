# 新增參數步驟 (sd_config 模組)

參數表是「表驅動」，新增一個參數只要改 **3 處**；預設值載入、寫檔、讀檔都不用動。

| 步驟 | 檔案 | 位置 | 要做的事 |
|---|---|---|---|
| 1/3 | `sd_config.h` | `struct AppConfig` | 加一個 `char 名稱[長度+1];` 欄位 |
| 2/3 | `sd_config.h` | `DEF_xxx` 區 | 加預設值 `#define DEF_名稱 "..."` |
| 3/3 | `sd_config.cpp` | `CFG_TABLE` | 加一列 `CFG_ITEM(名稱, DEF_名稱),` |

規則：
- **欄位名稱 = config.ini 的 key**（小寫、底線，例如 `device_id`），不可有空白或 `=`。
- 陣列大小 = 最大字元數 + 1（結尾 `\0`），超過會被截斷。WiFi SSID 32、密碼 64、一般字串 16~64 即可。
- 預設值不要放真實帳密，用 `YOUR_...` 佔位字串。
- 數值也用字串存，使用時再轉型（`atoi()`、`atof()`）。

## 範例：新增 `device_id`（字串）與 `report_interval`（秒，數值）

**步驟 1/3** `sd_config.h`
```cpp
struct AppConfig {
    ...
    char device_id[17];         // 裝置代號 (最長 16)
    char report_interval[8];    // 回報間隔秒數 (以字串存)
};
```

**步驟 2/3** `sd_config.h`
```cpp
#define DEF_DEVICE_ID        "datalogger-01"
#define DEF_REPORT_INTERVAL  "10"
```

**步驟 3/3** `sd_config.cpp`
```cpp
static const CfgItem CFG_TABLE[] = {
    ...
    CFG_ITEM(device_id,       DEF_DEVICE_ID),
    CFG_ITEM(report_interval, DEF_REPORT_INTERVAL),
};
```

使用：
```cpp
String id = cfg.device_id;
int interval = atoi(cfg.report_interval);   // 轉成數值
```

## 已存在的舊 SD 卡
舊卡的 `config.ini` 沒有新 key，讀取時該欄位會保留預設值（不會出錯）。
想把新 key 補寫進舊卡，開機後呼叫一次 `cfgSave(sd, cfg)` 即可。

## 檢查清單
- [ ] 三處都改了（最常忘記的是 `CFG_TABLE` 那一列，忘了就不會寫入也不會讀取）
- [ ] `DEF_` 名稱和 `CFG_ITEM` 的第二個參數一致
- [ ] 陣列大小足夠，沒有被截斷
- [ ] key 拼寫與欄位名稱完全一致（大小寫有分）
- [ ] 編譯通過後，用電腦打開 SD 卡的 `config.ini` 確認出現新的一行
