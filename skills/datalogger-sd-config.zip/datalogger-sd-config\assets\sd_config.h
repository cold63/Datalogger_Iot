/********************************************************************
 * 模組名稱：sd_config
 * 說    明：SD 卡參數設定檔 (config.ini, key=value) 的讀寫模組
 *           - 只負責「讀寫參數」並把讀到的值回填到 AppConfig struct
 *           - 不含任何硬體腳位，也不呼叫 sd.begin()
 *             (SD 接腳請依目前使用的擴展板 skill 定義，由 sketch 先 sd.begin())
 *           - 偵測不到 SD 卡 / 沒有 config.ini 時，使用預設值
 *
 * 使用方式 (sketch)：
 *   #include "sd_config.h"
 *   SdFat sd;  AppConfig cfg;
 *   bool sd_ok = sd.begin(SD_CONFIG);              // SD_CONFIG 由擴展板定義
 *   CfgSource src = cfgInit(sd, sd_ok, cfg);       // 之後直接用 cfg.wifi_ssid ...
 *
 * ==================== 如何新增參數 (共 3 處) ====================
 *   【新增參數步驟 1/3】本檔：在 struct AppConfig 加一個 char 陣列欄位
 *   【新增參數步驟 2/3】本檔：在下方加一個 DEF_xxx 預設值
 *   【新增參數步驟 3/3】sd_config.cpp：在 CFG_TABLE 加一列
 *   其餘 (預設值載入、寫檔、讀檔) 都是走表格，不必修改。
 *   詳細範例見 references/add-parameter.md
 ********************************************************************/

#ifndef SD_CONFIG_H
#define SD_CONFIG_H

#include <Arduino.h>
#include "SdFat.h"

// 設定檔名稱 (放在 SD 卡根目錄)
#define CONFIG_FILE         "config.ini"

// ---------------- 【新增參數步驟 2/3】預設值 ----------------
// 帳密請用佔位字串，不要把真實帳密寫進程式
#define DEF_WIFI_SSID       "YOUR_WIFI_SSID"
#define DEF_WIFI_PASS       "YOUR_WIFI_PASSWORD"
#define DEF_MQTT_BROKER     "broker.emqx.io"
#define DEF_MQTT_USER       "YOUR_MQTT_ACCOUNT"
#define DEF_MQTT_PASS       "YOUR_MQTT_PASSWORD"
#define DEF_MQTT_TOPIC      "datalogger/data"
// 例：#define DEF_DEVICE_ID   "datalogger-01"

// ---------------- 【新增參數步驟 1/3】參數結構 ----------------
// 陣列大小 = 字串最大長度 + 1 (結尾 '\0')；超過會被截斷
struct AppConfig {
    char wifi_ssid[33];     // WiFi SSID (最長 32)
    char wifi_pass[65];     // WiFi 密碼 (最長 64)
    char mqtt_broker[64];   // MQTT broker 位址
    char mqtt_user[33];     // MQTT 帳號
    char mqtt_pass[33];     // MQTT 密碼
    char mqtt_topic[64];    // MQTT topic
    // 例：char device_id[17];
};

// 參數來源狀態 (供 sketch 顯示)
enum CfgSource {
    CFG_FROM_DEFAULT = 0,   // 無 SD 卡或讀檔失敗，使用預設值
    CFG_FROM_SD_NEW,        // SD 卡內原本沒有設定檔，已用預設值建立
    CFG_FROM_SD_LOADED      // 已從 SD 卡 config.ini 讀入
};

/** 將所有參數設為預設值 */
void cfgLoadDefaults(AppConfig &c);

/** 將參數寫入 SD 卡 config.ini (覆寫)；成功回傳 true */
bool cfgSave(SdFat &sd, const AppConfig &c);

/** 讀取 SD 卡 config.ini 並回填到 struct；檔案缺少的 key 維持原值。成功回傳 true */
bool cfgLoad(SdFat &sd, AppConfig &c);

/**
 * 一站式初始化：載入預設 -> (有卡) 無檔則建立 / 有檔則讀取
 * @param sd      已建立的 SdFat 物件
 * @param sdReady sd.begin() 的結果 (false 代表沒有 SD 卡)
 * @param c       參數 struct (輸出)
 * @return        參數來源，見 CfgSource
 */
CfgSource cfgInit(SdFat &sd, bool sdReady, AppConfig &c);

#endif
