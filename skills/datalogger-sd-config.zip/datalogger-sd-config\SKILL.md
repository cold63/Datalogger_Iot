---
name: datalogger-sd-config
description: Datalogger IoT 系列（RTL8720DF / AmebaD）的 SD 卡參數設定檔讀寫。把 WiFi SSID／密碼、MQTT broker／帳號／密碼／topic 等參數存成 SD 卡 config.ini（key=value），讀取後回填到 AppConfig struct；沒有 SD 卡或沒有設定檔時使用預設值。只負責參數讀寫，不定義 SD 接腳（接腳由當時使用的擴展板 skill 提供）。觸發詞：SD 卡參數、設定檔、config.ini、WiFi 設定存 SD、MQTT 參數、讀取設定、參數寫入 SD、預設值、新增參數。
---

# Datalogger IoT SD 卡參數讀寫

提供可直接複製的 `sd_config` 模組，把設定存在 SD 卡根目錄的 `config.ini`：

```ini
# Datalogger config (key=value)
wifi_ssid=YOUR_WIFI_SSID
wifi_pass=YOUR_WIFI_PASSWORD
mqtt_broker=broker.emqx.io
mqtt_user=YOUR_MQTT_ACCOUNT
mqtt_pass=YOUR_MQTT_PASSWORD
mqtt_topic=datalogger/data
```

**本 skill 只做「參數讀寫並回填 struct」**。不處理 WiFi / MQTT 連線、不畫 TFT、不定義 SD 腳位。

## 檔案

| 路徑 | 內容 |
|---|---|
| `assets/sd_config.h` | `AppConfig` struct、`DEF_` 預設值、API 宣告（內有「新增參數步驟 1/3、2/3」註解） |
| `assets/sd_config.cpp` | 表驅動讀寫實作（內有「新增參數步驟 3/3」註解） |
| `references/add-parameter.md` | 新增參數逐步指南、範例與檢查清單 |

路徑以本 skill 資料夾（`SKILL.md` 所在處）為基準。

## 工作流程

### 1. 先詢問是否新增其他參數（必做）
複製模組**之前**，一定要用 AskUserQuestion 問使用者：除了預設的 6 個參數
（`wifi_ssid`、`wifi_pass`、`mqtt_broker`、`mqtt_user`、`mqtt_pass`、`mqtt_topic`），
是否**順便新增其他參數**？
- 不新增 → 直接用預設 6 個。
- 要新增 → 請使用者提供每個參數的：key 名稱（小寫底線）、最大長度、預設值（密碼類用佔位字串）。

### 2. 複製模組並依回答修改
- 把 `assets/sd_config.h`、`assets/sd_config.cpp` 複製到使用者的 sketch 資料夾（與 `.ino` 同層）。
- 有新增參數時，照 `references/add-parameter.md` 修改 **3 處**：
  1. `sd_config.h` 的 `struct AppConfig` 加欄位
  2. `sd_config.h` 加 `DEF_xxx` 預設值
  3. `sd_config.cpp` 的 `CFG_TABLE` 加一列 `CFG_ITEM(...)`
- 檔內註解已標示步驟位置，也要把這些註解保留給使用者日後自行新增。

### 3. SD 硬體接線：呼叫當時的擴展板 skill
本 skill **不定義 SD 接腳**。請依使用者目前的擴展板，改用對應 skill 取得 SD 腳位、`SD_CONFIG` 與環境設定：
- TFT LCD 擴展板 → `datalogger-tft-ili9341`（SD 為 SdFat 軟體 SPI：CS 11、MOSI 10、MISO 15、SCK 8；需 `SdFatConfig.h` 的 `SPI_DRIVER_SELECT` 設為 2）
- 後續其他 Datalogger IoT 擴展板 → 使用該擴展板自己的 skill

### 4. 在 sketch 中使用
```cpp
#include "SdFat.h"
#include "sd_config.h"
// ... 依擴展板 skill 定義 SD_CONFIG ...
SdFat sd;
AppConfig cfg;

void setup() {
    Serial.begin(115200);
    bool sd_ok = sd.begin(SD_CONFIG);          // 失敗不要停止程式
    CfgSource src = cfgInit(sd, sd_ok, cfg);   // 讀到的值已回填進 cfg
    // CFG_FROM_DEFAULT / CFG_FROM_SD_NEW / CFG_FROM_SD_LOADED
    // 之後使用 cfg.wifi_ssid、cfg.mqtt_broker ...
}
```
需要手動寫入／重讀時：`cfgSave(sd, cfg)`、`cfgLoad(sd, cfg)`。

行為：
| 情況 | 結果 |
|---|---|
| 沒有 SD 卡 | 使用預設值（`CFG_FROM_DEFAULT`） |
| 有卡、沒有 `config.ini` | 以預設值建立檔案（`CFG_FROM_SD_NEW`） |
| 有卡、有 `config.ini` | 讀入並回填 struct（`CFG_FROM_SD_LOADED`）；缺少的 key 維持預設值 |

## 注意事項
- `config.ini` 檔名固定、放在 SD 根目錄；格式為 `key=value`，`#` 開頭為註解，空行略過，支援 `\r\n`。
- 超過欄位長度的值會被截斷（陣列大小 = 最大長度 + 1）。
- 本平台沒有 `strlcpy`，模組已自帶 `copyStr()`。
- 帳密一律用佔位字串當預設值；提醒使用者不要把含真實帳密的 `config.ini` 提交或分享。
- 模組內只有失敗時的 `Serial.println`；要顯示參數（密碼請遮蔽）由 sketch 自行處理。

## 驗證
1. 編譯：`arduino-cli compile --fqbn realtek:AmebaD:DataloggerIot <sketch資料夾>`
2. 實機三情境：無 SD 卡 → 預設值；空白 SD 卡 → 自動建立 `config.ini`；在電腦改 `config.ini` 後重開機 → 新值回填。
