---
name: datalogger-w5500
description: 協助使用者為 Datalogger IoT (RTL8720DF / AmebaD) 搭配 W5500 乙太網路擴展板建立 Arduino 基礎程式架構。會確認 DT_W5500 程式庫是否已安裝、詢問網路模式 (DHCP / Static IP / 兩者以 #define 切換)、是否使用 SD 卡 (僅腳位定義與初始化)。當使用者提到 Datalogger IoT、W5500 擴展板、DT_W5500、乙太網路擴展板、有線網路 + SD 卡、或要建立 W5500 新專案/範本時使用。
---

# Datalogger IoT + W5500 擴展板 基礎架構

背景資料：
- 主板：https://www.makdev.net/p/datalogger-iot.html （RTL8720DF，Arduino 開發板 `realtek:AmebaD:DataloggerIot`）
- W5500 擴展板：https://www.makdev.net/p/datalogger-expand-enthernet.html
- 範例程式庫：github.com/cold63/Datalogger_Iot

**範圍：只產生基礎架構**（程式庫引入、腳位定義、W5500 + 網路初始化、SD 卡初始化、`loop()` 中的 `DT_Net_Loop()`）。
不實作 SD 檔案讀寫、HTTP/MQTT/TCP 等應用功能，除非使用者另外要求。

## 腳位 (固定，勿改動)

W5500 — DT_W5500 程式庫以軟體 bit-bang SPI 驅動，SCLK~RST 預設值在 `DT_W5500/src/DT_Config.h`：

| 功能 | Pin |
|---|---|
| SCLK | 19 |
| MISO | 16 |
| MOSI | 17 |
| CS   | 18 |
| RST  | 10 |
| INT  | 11 (低電位有效) |

> RST=10、INT=11 已於 2026-10-27 以實機驗證 (見下方「腳位驗證」)，與擴展板網頁一致。
> 修正後的程式庫 `DT_Config.h` 預設 `DT_PIN_RST_DEFAULT` = 10，因此一律以 `DT_W5500_Begin(NULL)` 使用程式庫預設腳位，不在程式中重複定義 SCLK~RST。
> **舊版程式庫預設 RST=11 (錯誤)**：步驟 1 須檢查 `DT_Config.h`，範本中的 `#if DT_PIN_RST_DEFAULT != 10 / #error` 也會在編譯時擋下。
> (RST 接錯時晶片仍會因上電重置而正常運作，所以 Begin 成功不代表 RST 正確。)
> INT 腳程式庫未定義 (`DT_Pins_t` 無 INT 欄位) 且不使用；範本自行 `#define W5500_INT 11`，使用者需要中斷驅動時再用。

### 腳位驗證 (使用者懷疑腳位、W5500 not found、或換新版擴展板時)

將 [templates/w5500_pin_test_snippet.ino](templates/w5500_pin_test_snippet.ino) 的內容加入程式 (需 `#include <DT_W5500_Raw.h>`)，在 `DT_W5500_Begin(NULL)` 成功後、`DT_Net_Begin*()` 之前呼叫 `testW5500Pins()`：
- CFG：先印出 `DT_Config.h` 實際編譯進去的預設腳位，RST 應為 10 (若仍為 11 表示用到舊版程式庫)
- RST：手動拉低 RST，版本暫存器應讀不到 0x04，放開後恢復 0x04 → PASS
- INT：開 UDP socket 啟用 SEND_OK 中斷並送出廣播，INT 腳應出現下降緣，閒置與結束時為 HIGH → PASS

驗證完成後提醒使用者註解 `#define W5500_PIN_TEST` 或移除測試碼。

SD 卡 — SdFat 軟體 SPI (`SoftSpiDriver`)，與 W5500 匯流排獨立，避免搶佔：

| 功能 | Pin |
|---|---|
| SD_CS     | 5  |
| SOFT_SCK  | 8  |
| SOFT_MOSI | 14 |
| SOFT_MISO | 15 |

## 工作流程

### 步驟 1：確認程式庫

以 PowerShell 檢查 (Arduino libraries 可能在 Documents 或 OneDrive\Documents)：

```powershell
foreach ($d in @("$env:USERPROFILE\Documents\Arduino\libraries", "$env:USERPROFILE\OneDrive\Documents\Arduino\libraries")) {
  foreach ($lib in @('DT_W5500','SdFat')) { $p = Join-Path $d $lib; if (Test-Path $p) { $p } }
}
```

- 找到 `DT_W5500`：讀取其 `library.properties` 回報版本，並檢查 RST 預設值：
  ```powershell
  Select-String -Path "<DT_W5500路徑>\src\DT_Config.h" -Pattern '^#define DT_PIN_RST_DEFAULT'
  ```
  若為 11 (舊版)，告知使用者需改為 10 (此為程式庫檔案，修改前先徵得同意)。
- 找不到：告知使用者需先安裝 —— 將整個 `DT_W5500` 資料夾複製到 `Documents\Arduino\libraries\` 後重啟 Arduino IDE (取得方式請參考 makdev.net 擴展板頁面)。詢問使用者是否已安裝於其他路徑；未安裝前仍可產生程式，但要明確說明無法編譯。不要自行捏造下載網址。
- `SdFat` 只有在步驟 2 選擇使用 SD 卡時才需要確認，見步驟 3。

### 步驟 2：詢問使用者 (用 AskUserQuestion 一次問完)

1. **網路模式**：
   - DHCP
   - Static IP
   - 兩者並存，以 `#define useDHCP` 切換 (建議)
2. **是否使用 SD 卡**：是 / 否

若使用者在需求中已明確說明，就不必再問。Static IP 預設值使用範本中的 192.168.1.177 / 255.255.255.0 / 192.168.1.1 / 8.8.8.8，並提醒使用者依自己網段修改 (不必另外詢問 IP)。

### 步驟 3：使用 SD 卡時檢查 SdFat 設定

SoftSpiDriver 需要 `SdFat/src/SdFatConfig.h` 中 `SPI_DRIVER_SELECT` 為 2：

```powershell
Select-String -Path "<SdFat路徑>\src\SdFatConfig.h" -Pattern '^#define SPI_DRIVER_SELECT'
```

若不是 2，告知使用者需修改 (此為程式庫檔案，修改前先徵得同意)。範本中的 `#error` 也會在編譯時擋下。

### 步驟 4：產生程式

以 [templates/w5500_base.ino](templates/w5500_base.ino) 為基礎，依答案裁剪：

| 選擇 | 處理方式 |
|---|---|
| 兩者並存 | 保留 `//#define useDHCP` 與 `#ifdef useDHCP / #else` 區塊原樣 (預設註解 = Static IP；說明取消註解即改用 DHCP) |
| 只用 DHCP | 刪除 `useDHCP` 相關 `#define/#ifdef`、ip/sn/gw/dns 陣列，只留 `DT_Net_BeginDhcp(mac)` |
| 只用 Static IP | 刪除 `useDHCP` 相關 `#define/#ifdef`，只留陣列與 `DT_Net_BeginStatic(...)` |
| 不用 SD 卡 | 刪除所有 `SD 卡` 區段 (含 `#include "SdFat.h"`、`SPI.h`、腳位、物件、`initSdCard()`) |

規則：
- 檔名與資料夾同名 (Arduino 規定)，例如 `my_project/my_project.ino`。若使用者已開啟某個 `.ino`，詢問是否寫入該檔或另建新專案；不要覆寫既有程式邏輯 —— 若要整合到現有程式，只加入缺少的部分。
- 註解使用繁體中文，風格與範本一致 (區塊分隔線 + 行尾註解)。
- `loop()` 只放 `DT_Net_Loop();` 與「在此加入應用邏輯」註解，並提醒不要使用長時間 `delay()`。
- SD 卡只做 `sd.begin(SD_CONFIG)` 初始化並印出成功/失敗，**不**開檔、不讀寫。保留全域 `file` 物件給使用者後續使用。
- 每張板子的 MAC 必須唯一，提醒使用者同網段多台時要修改。

### 步驟 5：回報

簡短說明：產生的檔案路徑、選用的模式、如何切換 (若為並存)、需要修改的參數 (MAC、Static IP)。
接著詢問是否需要後續功能 (例如 SD 寫入 log、HTTP/MQTT 上傳、斷網暫存續傳)，但不主動實作。

## DT_W5500 API 速查 (基礎架構用)

- `int DT_W5500_Begin(const DT_Pins_t* pins)` — `NULL` 用 `DT_Config.h` 預設腳位 (RST=10)；回傳 `DT_OK` 或 `DT_ERR_CHIP`
- `DT_Net_SetEventCallback(cb)` — 狀態改變回呼，`cb(DT_NetState_t)`
- `DT_Net_BeginDhcp(mac)` / `DT_Net_BeginStatic(mac, ip, sn, gw, dns)` (dns 可為 NULL → 8.8.8.8)
- `DT_Net_Loop()` — 必須在 `loop()` 持續呼叫 (Link 偵測、DHCP、自動重連)
- `DT_Net_IsReady()`、`DT_Net_StateName(state)`、`DT_PrintNetInfo()`
- 狀態：`DT_NET_IDLE / LINK_DOWN / DHCP / READY / FAIL`
- 進階功能 (使用者要求時再看)：程式庫 `examples/` 與 `src/DT_*.h` 標頭註解；編譯期設定只能改 `src/DT_Config.h`。
