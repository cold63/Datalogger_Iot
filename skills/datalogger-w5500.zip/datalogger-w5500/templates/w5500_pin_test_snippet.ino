/* ============================================================================
 * W5500 RST / INT 腳位驗證 (程式片段，加入使用者程式用，非獨立 sketch)
 *
 * 使用方式:
 *   1. 程式庫引入區加入: #include <DT_W5500_Raw.h>
 *   2. 腳位定義區需有 W5500_INT (11)，並加入:
 *        #define W5500_RST   DT_PIN_RST_DEFAULT  // 硬體重置 (程式庫預設，應為 10)
 *        #define W5500_PIN_TEST  // 開機時驗證 RST / INT 腳位；確認無誤後可註解此行
 *   3. 將下方 #ifdef W5500_PIN_TEST ... #endif 區塊貼在 setup() 之前
 *   4. setup() 中:
 *        if (DT_W5500_Begin(NULL) != DT_OK) Serial.println("W5500 not found!");
 *      #ifdef W5500_PIN_TEST
 *        else testW5500Pins();
 *      #endif
 *        (之後才呼叫 DT_Net_BeginDhcp / DT_Net_BeginStatic)
 *
 * 實機預期輸出 (2026-10-27 驗證):
 *   [CFG] DT_Config.h 預設腳位 SCLK=19 MISO=16 MOSI=17 CS=18 RST=10  (程式內 INT=11)
 *   [RST] 正常: 0x4  重置中: 0x0  放開後: 0x4
 *   [RST] GPIO10 -> PASS
 *   [INT] 閒置電位: HIGH  送出: OK  下降緣次數: 1  結束電位: HIGH
 *   [INT] GPIO11 -> PASS
 * ============================================================================ */

#ifdef W5500_PIN_TEST
volatile uint32_t w5500IntCount = 0;  // INT 腳下降緣計數

void onW5500Int()
{
    w5500IntCount++;
}

/* ============================================================================
 * 函式: testW5500Pins()
 * 功能: 驗證擴展板 RST / INT 腳位
 * 說明:
 *   - RST: 手動拉低 RST，若腳位正確晶片會進入重置，版本暫存器讀不到 0x04
 *   - INT: 開 UDP socket 並開啟 SEND_OK 中斷，送出一個廣播封包，
 *          若腳位正確 INT 會出現下降緣 (低電位有效)
 *   - 呼叫前須已執行 DT_W5500_Begin()；RST 測試會清除晶片設定，
 *     因此函式內會重新呼叫 DT_W5500_Begin()
 * ============================================================================ */
void testW5500Pins()
{
    Serial.println("===== W5500 腳位驗證 =====");
    Serial.print("[CFG] DT_Config.h 預設腳位 SCLK="); Serial.print(DT_PIN_SCLK_DEFAULT);
    Serial.print(" MISO="); Serial.print(DT_PIN_MISO_DEFAULT);
    Serial.print(" MOSI="); Serial.print(DT_PIN_MOSI_DEFAULT);
    Serial.print(" CS=");   Serial.print(DT_PIN_CS_DEFAULT);
    Serial.print(" RST=");  Serial.print(DT_PIN_RST_DEFAULT);
    Serial.print("  (程式內 INT="); Serial.print(W5500_INT); Serial.println(")");

    // ---- RST 測試 ----
    uint8_t verNormal = DT_W5500_GetVersion();
    digitalWrite(W5500_RST, LOW);       // 保持重置
    delay(5);
    uint8_t verInReset = DT_W5500_GetVersion();
    digitalWrite(W5500_RST, HIGH);
    delay(200);                         // 等待 PLL 穩定
    DT_W5500_Begin(NULL);               // 重置後重新初始化 (程式庫預設腳位)
    uint8_t verAfter = DT_W5500_GetVersion();

    Serial.print("[RST] 正常: 0x");   Serial.print(verNormal, HEX);
    Serial.print("  重置中: 0x");     Serial.print(verInReset, HEX);
    Serial.print("  放開後: 0x");     Serial.println(verAfter, HEX);
    bool rstOk = (verNormal == 0x04) && (verInReset != 0x04) && (verAfter == 0x04);
    Serial.print("[RST] GPIO");
    Serial.print(W5500_RST);
    Serial.println(rstOk ? " -> PASS" : " -> FAIL (重置中仍可讀到 0x04，RST 不在此腳)");

    // ---- INT 測試 ----
    pinMode(W5500_INT, INPUT_PULLUP);
    setSIMR(0);                         // 先關閉所有 socket 中斷
    int idleLevel = digitalRead(W5500_INT);

    w5500IntCount = 0;
    attachInterrupt(W5500_INT, onW5500Int, FALLING);

    int sn = DT_Socket_Alloc();
    bool sent = false;
    if (sn >= 0) {
        uint8_t bcast[4] = {255, 255, 255, 255};
        socket(sn, Sn_MR_UDP, DT_Socket_LocalPort(), 0);
        setSn_IMR(sn, Sn_IR_SENDOK);
        setSIMR(1 << sn);               // 開啟此 socket 中斷
        sent = sendto(sn, (uint8_t*)"INT", 3, bcast, 9) > 0;  // 廣播到 discard port
        delay(10);
        setSIMR(0);                     // 測試完關閉中斷
        DT_Socket_Free(sn);
    }
    detachInterrupt(W5500_INT);
    int endLevel = digitalRead(W5500_INT);

    Serial.print("[INT] 閒置電位: "); Serial.print(idleLevel ? "HIGH" : "LOW");
    Serial.print("  送出: ");         Serial.print(sent ? "OK" : "失敗");
    Serial.print("  下降緣次數: ");   Serial.print(w5500IntCount);
    Serial.print("  結束電位: ");     Serial.println(endLevel ? "HIGH" : "LOW");
    bool intOk = sent && idleLevel == HIGH && w5500IntCount > 0 && endLevel == HIGH;
    Serial.print("[INT] GPIO");
    Serial.print(W5500_INT);
    Serial.println(intOk ? " -> PASS" : " -> FAIL");
    Serial.println("==========================");
}
#endif
