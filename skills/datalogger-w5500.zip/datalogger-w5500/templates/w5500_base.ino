/*
 * ============================================================================
 * 專案名稱: Datalogger IoT + W5500 乙太網路擴展板 基礎架構
 * 目標平台: RTL8720DF (Realtek Ameba) - Datalogger IoT
 * ============================================================================
 *
 * 執行這個範例前先安裝以下程式庫:
 *   DT_W5500 (W5500 乙太網路程式庫)
 *   SdFat    (SD 卡程式庫，SdFatConfig.h 中 SPI_DRIVER_SELECT 須設為 2)
 *
 * 功能說明:
 *   1. 初始化 W5500 並以 DHCP 或靜態 IP 設定網路 (由 useDHCP 決定)
 *   2. 初始化 SD 卡 (軟體 SPI，僅初始化，不做檔案存取)
 *
 * 通訊架構:
 *   RTL8720DF <--Bit-bang SPI--> W5500 <--Ethernet--> 區域網路
 *   RTL8720DF <--Soft SPI--> MicroSD (與 W5500 匯流排獨立)
 * ============================================================================
 */

/* ============================================================================
 * 程式庫引入區
 * ============================================================================ */
#include <DT_W5500.h>       // W5500 乙太網路程式庫
#include "SPI.h"            // [SD 卡] SPI 程式庫
#include "SdFat.h"          // [SD 卡] SdFat 程式庫

/* ============================================================================
 * W5500 腳位定義
 *   SCLK=19 MISO=16 MOSI=17 CS=18 RST=10 使用 DT_Config.h 預設值
 *   (DT_W5500_Begin(NULL))；INT 程式庫未定義，於此自行定義
 * ============================================================================ */
#if DT_PIN_RST_DEFAULT != 10
#error DT_W5500/src/DT_Config.h 的 DT_PIN_RST_DEFAULT 須為 10 (舊版程式庫為 11)
#endif

#define W5500_INT   11  // 中斷輸出 (W5500 INTn，低電位有效；DT_W5500 本身不使用)

/* ============================================================================
 * W5500 乙太網路設定 (DHCP / 靜態 IP)
 * ============================================================================ */
//#define useDHCP   // 使用 DHCP；註解此行改用下方靜態 IP 設定

uint8_t mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0x01}; // W5500 MAC 位址 (每台需唯一)

#ifndef useDHCP
uint8_t ip[4]  = {192, 168, 1, 177};  // 靜態 IP 位址
uint8_t sn[4]  = {255, 255, 255, 0};  // 子網路遮罩
uint8_t gw[4]  = {192, 168, 1, 1};    // 預設閘道
uint8_t dns[4] = {8, 8, 8, 8};        // DNS 伺服器
#endif

/* ============================================================================
 * [SD 卡] 腳位定義與物件宣告 (軟體 SPI)
 * ============================================================================ */
#if SPI_DRIVER_SELECT == 2  // 須在 SdFat/SdFatConfig.h 設定

// SD_FAT_TYPE = 0: SdFat/File, 1: FAT16/FAT32, 2: exFAT, 3: FAT16/FAT32 與 exFAT
#define SD_FAT_TYPE 0

const uint8_t SD_CS_PIN     = 5;   // SD 卡晶片選擇
const uint8_t SOFT_MISO_PIN = 15;  // 軟體 SPI MISO
const uint8_t SOFT_MOSI_PIN = 14;  // 軟體 SPI MOSI
const uint8_t SOFT_SCK_PIN  = 8;   // 軟體 SPI 時脈

SoftSpiDriver<SOFT_MISO_PIN, SOFT_MOSI_PIN, SOFT_SCK_PIN> softSpi; // SdFat 軟體 SPI
// 軟體 SPI 會忽略速度參數
#if ENABLE_DEDICATED_SPI
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, DEDICATED_SPI, SD_SCK_MHZ(0), &softSpi)
#else
#define SD_CONFIG SdSpiConfig(SD_CS_PIN, SHARED_SPI, SD_SCK_MHZ(0), &softSpi)
#endif

#if SD_FAT_TYPE == 0
SdFat sd;
File file;
#elif SD_FAT_TYPE == 1
SdFat32 sd;
File32 file;
#elif SD_FAT_TYPE == 2
SdExFat sd;
ExFile file;
#elif SD_FAT_TYPE == 3
SdFs sd;
FsFile file;
#else
#error Invalid SD_FAT_TYPE
#endif

#else
#error SPI_DRIVER_SELECT must be two in SdFat/SdFatConfig.h
#endif

bool sdReady = false;  // [SD 卡] 初始化結果

/* ============================================================================
 * 函式: onNetEvent()
 * 功能: 網路狀態事件回呼
 * 說明:
 *   - 網路狀態改變時印出狀態名稱
 *   - 取得 IP (READY) 時印出網路資訊
 *   - 斷線重連與 DHCP 租約更新由 DT_Net_Loop() 自動處理
 * ============================================================================ */
void onNetEvent(DT_NetState_t state)
{
    Serial.print("[NET] ");
    Serial.println(DT_Net_StateName(state));
    if (state == DT_NET_READY) DT_PrintNetInfo();
}

/* ============================================================================
 * 函式: initSdCard()
 * 功能: [SD 卡] 初始化 SD 卡 (不做檔案存取)
 * ============================================================================ */
void initSdCard()
{
    sdReady = sd.begin(SD_CONFIG);
    Serial.println(sdReady ? "[SD] 初始化成功" : "[SD] 初始化失敗，請確認 SD 卡");
}

/* ============================================================================
 * 函式: setup()
 * 功能: 系統初始化設定
 * 說明:
 *   1. 初始化除錯序列埠 (115200 bps)
 *   2. 初始化 W5500 並以 DHCP 或靜態 IP 設定網路 (由 useDHCP 決定)
 *   3. 初始化 SD 卡
 * ============================================================================ */
void setup() {
  Serial.begin(115200);     // 初始化除錯序列埠 (115200 bps)

  // 初始化 W5500 並設定網路
  if (DT_W5500_Begin(NULL) != DT_OK) Serial.println("W5500 not found!");  // NULL = DT_Config.h 預設腳位
  DT_Net_SetEventCallback(onNetEvent);
#ifdef useDHCP
  DT_Net_BeginDhcp(mac);                    // DHCP 自動取得 IP
#else
  DT_Net_BeginStatic(mac, ip, sn, gw, dns); // 使用靜態 IP
#endif

  initSdCard();             // [SD 卡] 初始化
}

/* ============================================================================
 * 函式: loop()
 * 功能: 主程式迴圈
 * ============================================================================ */
void loop() {
  DT_Net_Loop();  // 非阻塞：處理 Link 偵測、DHCP 與租約更新

  // 在此加入應用邏輯 (不要使用長時間 delay)
}
